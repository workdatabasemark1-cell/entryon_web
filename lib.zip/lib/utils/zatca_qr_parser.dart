import 'dart:convert';

/// Parses ZATCA (Saudi Arabia) e-invoice QR codes.
/// The QR payload is Base64-encoded TLV (Tag-Length-Value) data.
class ZatcaQrParser {
  /// Returns null if the string is not a valid ZATCA QR code.
  static ZatcaQrData? parse(String raw) {
    try {
      // The payload may already be Base64, or it may be raw TLV bytes
      // represented as a Base64 string.
      final bytes = _decodeBase64(raw);
      if (bytes == null) return null;
      return _parseTlv(bytes);
    } catch (_) {
      return null;
    }
  }

  static List<int>? _decodeBase64(String input) {
    try {
      // Normalize padding
      String s = input.trim();
      while (s.length % 4 != 0) {
        s += '=';
      }
      return base64Decode(s);
    } catch (_) {
      return null;
    }
  }

  static ZatcaQrData _parseTlv(List<int> bytes) {
    String sellerName    = '';
    String vatNumber     = '';
    String invoiceDate   = '';
    String totalIncVat   = '';
    String vatAmount     = '';

    int i = 0;
    while (i < bytes.length) {
      final tag    = bytes[i];
      final length = bytes[i + 1];
      i += 2;
      final value = _decodeValue(bytes.sublist(i, i + length));
      i += length;

      switch (tag) {
        case 1: sellerName  = value; break;
        case 2: vatNumber   = value; break;
        case 3: invoiceDate = value; break;
        case 4: totalIncVat = value; break;
        case 5: vatAmount   = value; break;
      }
    }

    return ZatcaQrData(
      sellerName:  sellerName,
      vatNumber:   vatNumber,
      invoiceDate: invoiceDate,
      totalIncVat: totalIncVat,
      vatAmount:   vatAmount,
    );
  }
}

String _decodeValue(List<int> bytes) {
  try {
    return utf8.decode(bytes, allowMalformed: true);
  } catch (_) {
    return String.fromCharCodes(bytes);
  }
}

class ZatcaQrData {
  final String sellerName;
  final String vatNumber;
  final String invoiceDate;   // ISO-8601 string e.g. "2024-01-15T10:00:00Z"
  final String totalIncVat;
  final String vatAmount;

  const ZatcaQrData({
    required this.sellerName,
    required this.vatNumber,
    required this.invoiceDate,
    required this.totalIncVat,
    required this.vatAmount,
  });

  @override
  String toString() =>
      'ZatcaQrData(seller: $sellerName, vat: $vatNumber, '
      'date: $invoiceDate, total: $totalIncVat, vatAmt: $vatAmount)';
}