import 'package:entryon/models/transaction_model.dart';
import 'package:entryon/providers/transaction_provider.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:provider/provider.dart';

double _resolveTxnBalanceAmount(TransactionModel txn) {
  final modelBalance = txn.balanceAmount;
  if (modelBalance != 0.0) {
    return modelBalance;
  }

  return (txn.paymentDetails?['balanceAmount'] as num?)?.toDouble() ?? 0.0;
}

List<TransactionModel> _latestTransactionsPerService(List<TransactionModel> transactions) {
  final latestByService = <String, TransactionModel>{};

  for (final txn in transactions) {
    final key = txn.serviceId.trim().toLowerCase();
    final existing = latestByService[key];

    if (existing == null || txn.createdAt.isAfter(existing.createdAt)) {
      latestByService[key] = txn;
    }
  }

  return latestByService.values.toList();
}

class CustomerTransactionsListScreen extends StatelessWidget {
  final String customerName;
  final String? customerId;

  const CustomerTransactionsListScreen({super.key, required this.customerName, this.customerId});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey.shade100,
      appBar: AppBar(
        title: Text('Transactions ', style: const TextStyle(fontWeight: FontWeight.w600)),
        backgroundColor: Colors.white,
        elevation: 0,
        scrolledUnderElevation: 0,
      ),
      body: Consumer<TransactionProvider>(
        builder: (context, provider, _) {
          if (provider.isLoading && provider.transactions.isEmpty) {
            return const Center(child: CircularProgressIndicator(color: Colors.teal));
          }

          final transactions = provider.transactions
              .where((txn) {
                final matchesById = customerId != null && txn.customerId != null && txn.customerId == customerId;
                final matchesByName = customerId == null
                    ? txn.customerName.toLowerCase() == customerName.toLowerCase()
                    : txn.customerId == null && txn.customerName.toLowerCase() == customerName.toLowerCase();
                return matchesById || matchesByName;
              })
              .toList()
            ..sort((a, b) => b.createdAt.compareTo(a.createdAt));

          if (transactions.isEmpty) {
            return Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(Icons.receipt_long_outlined, size: 70, color: Colors.grey.shade400),
                  const SizedBox(height: 12),
                  Text('No transactions found for this customer', style: TextStyle(color: Colors.grey.shade600, fontSize: 16)),
                ],
              ),
            );
          }

          final latestTransactions = _latestTransactionsPerService(transactions);
          final totalPaidAmount = transactions.fold<double>(0.0, (sum, txn) => sum + txn.amount);
          final totalBalanceAmount = latestTransactions.fold<double>(0.0, (sum, txn) => sum + _resolveTxnBalanceAmount(txn));
          final totalAmount = totalPaidAmount + totalBalanceAmount;
          return Column(
            children: [
              Expanded(
                child: ListView.builder(
                  padding: const EdgeInsets.all(12),
                  itemCount: transactions.length,
                  itemBuilder: (context, index) {
                    final txn = transactions[index];

                    return Container(
                      margin: const EdgeInsets.only(bottom: 10),
                      padding: const EdgeInsets.all(10),
                      decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(10),
                        boxShadow: [
                          BoxShadow(
                            color: Colors.black.withOpacity(0.04),
                            blurRadius: 8,
                            offset: const Offset(0, 3),
                          ),
                        ],
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            children: [
                              Expanded(
                                child: Text(
                                  txn.customerName,
                                  style: const TextStyle(
                                    fontSize: 15,
                                    fontWeight: FontWeight.bold,
                                  ),
                                  maxLines: 1,
                                  overflow: TextOverflow.ellipsis,
                                ),
                              ),
                              Container(
                                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                                decoration: BoxDecoration(
                                  color: Colors.teal.withOpacity(0.12),
                                  borderRadius: BorderRadius.circular(20),
                                ),
                                child: Text(
                                  txn.paymentType,
                                  style: const TextStyle(
                                    color: Colors.teal,
                                    fontWeight: FontWeight.w600,
                                  ),
                                ),
                              ),
                            ],
                          ),
                          const SizedBox(height: 2),
                          Text(
                            'Service: ${txn.serviceId}',
                            style: TextStyle(color: Colors.grey.shade600),
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                          ),
                          const SizedBox(height: 2),
                          Row(
                            children: [
                              Expanded(
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(
                                      'Amount: ${txn.amount.toStringAsFixed(2)}',
                                      style: const TextStyle(fontWeight: FontWeight.w600),
                                    ),
                                    const SizedBox(height: 2),
                                    Text(
                                      'Balance: ${_resolveTxnBalanceAmount(txn).toStringAsFixed(2)}',
                                      style: TextStyle(fontSize: 12, color: Colors.grey.shade700),
                                    ),
                                  ],
                                ),
                              ),
                              Text(
                                DateFormat('dd MMM yyyy • HH:mm').format(txn.createdAt),
                                style: TextStyle(fontSize: 12, color: Colors.grey.shade500),
                              ),
                            ],
                          ),
                        ],
                      ),
                    );
                  },
                ),
              ),
              Container(
                width: double.infinity,
                padding: const EdgeInsets.fromLTRB(12, 10, 12, 12),
                decoration: BoxDecoration(
                  color: Colors.white,
                  border: Border(top: BorderSide(color: Colors.grey.shade200)),
                ),
                child: Row(
                  children: [
                    Expanded(
                      child: Text(
                        'Total Amount: ${totalAmount.toStringAsFixed(2)}',
                        style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 14),
                      ),
                    ),
                    Expanded(
                      child: Text(
                        'Total Paid: ${totalPaidAmount.toStringAsFixed(2)}',
                        style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 14),
                      ),
                    ),
                    Expanded(
                      child: Text(
                        'Total Balance: ${totalBalanceAmount.toStringAsFixed(2)}',
                        style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 14),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          );
        },
      ),
    );
  }
}
