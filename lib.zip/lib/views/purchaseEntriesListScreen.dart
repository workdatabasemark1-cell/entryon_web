
import 'package:entryon/views/editPurchaseEntryScreen.dart';
import 'package:entryon/views/purchaseEntryDetailsScreen.dart';
import 'package:entryon/views/purchaseEntryScreen.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:lucide_icons_flutter/lucide_icons.dart';
import 'package:printing/printing.dart';
import 'package:provider/provider.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:flutter/services.dart';
// PDF packages
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import '../utils/pdf_download.dart';
import '../utils/file_name_utils.dart';

// File handling
import 'dart:io';
import 'package:excel/excel.dart' hide Border;
import 'package:path_provider/path_provider.dart';
import 'package:open_file/open_file.dart';
import '../models/purchase_entry_model.dart';

import '../providers/customer_provider.dart';
import '../providers/supplier_provider.dart';

class PurchaseEntriesListScreen extends StatefulWidget {
  const PurchaseEntriesListScreen({super.key});

  @override
  State<PurchaseEntriesListScreen> createState() =>
      _PurchaseEntriesListScreenState();
}

class _PurchaseEntriesListScreenState extends State<PurchaseEntriesListScreen> {
  final _searchController = TextEditingController();
  List<PurchaseInvoice> _allInvoices = [];
  List<PurchaseInvoice> _filteredInvoices = [];
  bool _isLoading = false;

  // Period sections
  List<Map<String, String>> _periods = [];
  bool _periodsLoading = true;
  Set<String> _selectedPeriodIds = {}; // empty = all

  // ── Filter state ──────────────────────────────────────────────────────────
  String _filterType = 'all'; // all | today | week | month | custom
  DateTime? _customFrom;
  DateTime? _customTo;

  @override
  void initState() {
    super.initState();
    _fetchPeriods();
    _loadInvoices();
  }

  Future<void> _fetchPeriods() async {
    setState(() => _periodsLoading = true);
    try {
      final snap = await FirebaseFirestore.instance
          .collection('period_sections')
          .orderBy('sectionNumber')
          .get();
      _periods = snap.docs.map((d) {
        final data = d.data();
        return {
          'id': d.id,
          'name': (data['name'] ?? '').toString(),
        };
      }).toList();
    } catch (e) {
      print('Error fetching periods: $e');
      _periods = [];
    } finally {
      setState(() => _periodsLoading = false);
    }
  }

  // ── Data loading ──────────────────────────────────────────────────────────
  Future<void> _loadInvoices() async {
    setState(() => _isLoading = true);
    try {
      final invoices = await _fetchAllInvoices();
      setState(() {
        _allInvoices = invoices;
        _filteredInvoices = invoices;
      });
      if (invoices.isEmpty) _showMsg('No invoices found', Colors.orange);
    } catch (e) {
      _showMsg('Error loading invoices: $e', Colors.red);
    } finally {
      setState(() => _isLoading = false);
    }
  }

  Future<List<PurchaseInvoice>> _fetchAllInvoices() async {
    final db = FirebaseFirestore.instance;
    final snapshot = await db.collection('purchase_invoices').get();

    List<PurchaseInvoice> invoices = [];
    for (var doc in snapshot.docs) {
      try {
        final itemsSnapshot = await doc.reference.collection('items').get();
        final items = itemsSnapshot.docs
            .map((d) => PurchaseItem.fromMap(d.data()))
            .toList();
        final invoice = PurchaseInvoice.fromMap(doc.data(), items);
        invoices.add(PurchaseInvoice(
          id: doc.id,
          customerId: invoice.customerId,
          customerName: invoice.customerName,
          customerVatNumber: invoice.customerVatNumber,
          supplierId: invoice.supplierId,
          supplierName: invoice.supplierName,
          invoiceNo: invoice.invoiceNo,
          invoiceDate: invoice.invoiceDate,
          items: items,
          createdAt: invoice.createdAt,
          periodSectionId: invoice.periodSectionId,
          periodSectionName: invoice.periodSectionName,
        ));
      } catch (e) {
        print('Error parsing invoice ${doc.id}: $e');
      }
    }
    invoices.sort((a, b) => b.createdAt.compareTo(a.createdAt));
    return invoices;
  }

  // ── Filtering logic ───────────────────────────────────────────────────────
  void _applyFilters({String? query}) {
    final q = query ?? _searchController.text;
    final now = DateTime.now();
    final today = DateTime(now.year, now.month, now.day);

    setState(() {
      _filteredInvoices = _allInvoices.where((inv) {
        // Search match
        final matchesSearch = q.isEmpty ||
            inv.customerName.toLowerCase().contains(q.toLowerCase()) ||
            inv.supplierName.toLowerCase().contains(q.toLowerCase()) ||
            inv.invoiceNo.contains(q);

        if (!matchesSearch) return false;

        // Date match against createdAt
        final invDate = DateTime(
            inv.createdAt.year, inv.createdAt.month, inv.createdAt.day);

        bool matchesDate = false;
        switch (_filterType) {
          case 'today':
            matchesDate = invDate.isAtSameMomentAs(today);
            break;
          case 'week':
            matchesDate = !invDate
                .isBefore(today.subtract(const Duration(days: 7)));
            break;
          case 'month':
            matchesDate = !invDate
                .isBefore(today.subtract(const Duration(days: 30)));
            break;
          case 'custom':
            if (_customFrom == null && _customTo == null) {
              matchesDate = true;
            } else {
              final from = _customFrom != null
                  ? DateTime(_customFrom!.year, _customFrom!.month,
                      _customFrom!.day)
                  : null;
              final to = _customTo != null
                  ? DateTime(
                      _customTo!.year, _customTo!.month, _customTo!.day)
                  : null;
              final afterFrom = from == null ||
                  !invDate.isBefore(from);
              final beforeTo = to == null ||
                  !invDate.isAfter(to);
              matchesDate = afterFrom && beforeTo;
            }
            break;
          default: // 'all'
            matchesDate = true;
            break;
        }

        if (!matchesDate) return false;

        // Period section filter: if periods selected, require match
        if (_selectedPeriodIds.isNotEmpty) {
          if (!_selectedPeriodIds.contains(inv.periodSectionId)) return false;
        }
        return true;
      }).toList();
    });
  }

  // ── Date range picker ─────────────────────────────────────────────────────
  Future<void> _pickDateRange() async {
    final now = DateTime.now();
    final picked = await showDateRangePicker(
      context: context,
      firstDate: DateTime(2020),
      lastDate: now,
      initialDateRange: (_customFrom != null && _customTo != null)
          ? DateTimeRange(start: _customFrom!, end: _customTo!)
          : DateTimeRange(
              start: now.subtract(const Duration(days: 30)), end: now),
      builder: (context, child) => Theme(
        data: Theme.of(context).copyWith(
          colorScheme: ColorScheme.light(
            primary: Colors.blue.shade700,
            onPrimary: Colors.white,
            surface: Colors.white,
          ),
        ),
        child: child!,
      ),
    );

    if (picked != null) {
      setState(() {
        _customFrom = picked.start;
        _customTo = picked.end;
        _filterType = 'custom';
      });
      _applyFilters();
    }
  }

  void _clearDateRange() {
    setState(() {
      _customFrom = null;
      _customTo = null;
      _filterType = 'all';
    });
    _applyFilters();
  }

  // ── Show period selection dialog ──────────────────────────────────────────
  Future<void> _showPeriodSelectDialog() async {
    final selectedCopy = Set<String>.from(_selectedPeriodIds);

    showDialog(
      context: context,
      builder: (ctx) => StatefulBuilder(
        builder: (context, setDialogState) => AlertDialog(
          title: const Text('Filter by Period Sections'),
          content: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                // Select All checkbox
                CheckboxListTile(
                  value: selectedCopy.length == _periods.length && _periods.isNotEmpty,
                  onChanged: (val) {
                    setDialogState(() {
                      if (val == true) {
                        selectedCopy.addAll(_periods.map((p) => p['id']!));
                      } else {
                        selectedCopy.clear();
                      }
                    });
                  },
                  title: const Text('All Periods'),
                  dense: true,
                ),
                const Divider(),
                // Individual period checkboxes
                ..._periods.map((period) {
                  final id = period['id']!;
                  final name = period['name']!;
                  return CheckboxListTile(
                    value: selectedCopy.contains(id),
                    onChanged: (val) {
                      setDialogState(() {
                        if (val == true) {
                          selectedCopy.add(id);
                        } else {
                          selectedCopy.remove(id);
                        }
                      });
                    },
                    title: Text(name),
                    dense: true,
                  );
                }),
              ],
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(ctx),
              child: const Text('Cancel'),
            ),
            ElevatedButton(
              onPressed: () {
                setState(() => _selectedPeriodIds = selectedCopy);
                _applyFilters();
                Navigator.pop(ctx);
              },
              child: const Text('Apply'),
            ),
          ],
        ),
      ),
    );
  }

  // ── Delete ────────────────────────────────────────────────────────────────
  Future<void> _deleteInvoice(String invoiceId) async {
    final confirm = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Delete Invoice'),
        content: const Text('Are you sure you want to delete this invoice?'),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(ctx, false),
              child: const Text('Cancel')),
          TextButton(
              onPressed: () => Navigator.pop(ctx, true),
              child:
                  const Text('Delete', style: TextStyle(color: Colors.red))),
        ],
      ),
    );
    if (confirm == true) {
      try {
        await FirebaseFirestore.instance
            .collection('purchase_invoices')
            .doc(invoiceId)
            .delete();
        _showMsg('Invoice deleted', Colors.green);
        _loadInvoices();
      } catch (e) {
        _showMsg('Error deleting: $e', Colors.red);
      }
    }
  }
  Future<void> _exportToPdf(
    PurchaseInvoice invoice, [
    List<PurchaseItem>? filteredItems,
  ]) async {
    final itemsToExport = filteredItems ?? invoice.items;
    try {
      final customerProvider = context.read<CustomerProvider>();
      final customer = await customerProvider.getCustomerById(
        invoice.customerId,
      );

      Future<pw.Font> loadFont(String assetPath) async {
        final fontData = await rootBundle.load(assetPath);
        return pw.Font.ttf(fontData);
      }

      final arabicRegular = await loadFont(
        'assets/fonts/NotoSansArabic-Regular.ttf',
      );
      final arabicBold = arabicRegular;
      final latinRegular = pw.Font.courier();
      final latinBold = pw.Font.courierBold();

      const blue = PdfColor.fromInt(0xFF4F8EF7);
      const blueLight = PdfColor.fromInt(0xFFF0F4FF);
      const blueBorder = PdfColor.fromInt(0xFFBDD3FC);
      const surface = PdfColor.fromInt(0xFFF5F6FA);
      const cardBorder = PdfColor.fromInt(0xFFE5E7EB);
      const textPrimary = PdfColor.fromInt(0xFF111827);
      const textMuted = PdfColor.fromInt(0xFF9CA3AF);
      const textSecondary = PdfColor.fromInt(0xFF6B7280);

      final pdf = pw.Document(
        theme: pw.ThemeData.withFont(
          base: latinRegular,
          bold: latinBold,
          fontFallback: [arabicRegular, arabicBold],
        ),
      );

      pw.Widget buildLocalizedText(
        String text, {
        bool isBold = false,
        double fontSize = 10,
      }) {
        final isArabic = RegExp(r'[\u0600-\u06FF\u0750-\u077F]').hasMatch(text);
        final font = isArabic ? arabicRegular : latinRegular;
        final boldFont = isArabic ? arabicRegular : latinBold;

        return pw.Directionality(
          textDirection: isArabic ? pw.TextDirection.rtl : pw.TextDirection.ltr,
          child: pw.Text(
            text,
            style: pw.TextStyle(
              font: isBold ? boldFont : font,
              fontSize: fontSize,
              fontWeight: isBold ? pw.FontWeight.bold : null,
            ),
            textAlign: isArabic ? pw.TextAlign.right : pw.TextAlign.left,
          ),
        );
      }

      pw.Widget buildTableCell(String text, {bool isHeader = false}) {
        return pw.Padding(
          padding: const pw.EdgeInsets.all(4),
          child: buildLocalizedText(
            text,
            isBold: isHeader,
            fontSize: isHeader ? 9 : 8,
          ),
        );
      }

      pdf.addPage(
        pw.MultiPage(
          pageFormat: PdfPageFormat.a4,
          margin: const pw.EdgeInsets.all(24),
          build: (context) => [
            buildLocalizedText(
              'Purchase Invoice Summary',
              isBold: true,
              fontSize: 18,
            ),
            pw.SizedBox(height: 8),
            buildLocalizedText('Invoice No: ${invoice.invoiceNo}'),
            buildLocalizedText('Customer: ${customer?.name ?? invoice.customerName}'),
            buildLocalizedText(
              'Date: ${DateFormat('dd/MM/yyyy').format(invoice.invoiceDate)}',
            ),
            pw.SizedBox(height: 12),
            buildLocalizedText(
              'Filtered line items',
              isBold: true,
            ),
            pw.SizedBox(height: 6),
            if (itemsToExport.isEmpty)
              buildLocalizedText('No line items available for this export.')
            else
          pw.Table(
  border: pw.TableBorder.all(width: 0.5),
  columnWidths: {
    0: const pw.FixedColumnWidth(48),  // Date
    1: const pw.FixedColumnWidth(150),  // Supplier
    2: const pw.FixedColumnWidth(68),  // VAT No
    3: const pw.FixedColumnWidth(72),  // Invoice No
    4: const pw.FixedColumnWidth(40),  // Amount
    5: const pw.FixedColumnWidth(40),  // VAT
    6: const pw.FixedColumnWidth(40),  // Total
  },
  children: [
    pw.TableRow(
      decoration: const pw.BoxDecoration(color: PdfColors.grey100),
      children: [
        buildTableCell('Date', isHeader: true),
        buildTableCell('Supplier', isHeader: true),
        buildTableCell('VAT No', isHeader: true),
        buildTableCell('Invoice No', isHeader: true),
        buildTableCell('Amount', isHeader: true),
        buildTableCell('VAT', isHeader: true),
        buildTableCell('Total', isHeader: true),
      ],
    ),
    ...itemsToExport.map((item) {
      return pw.TableRow(
        children: [
          buildTableCell(DateFormat('dd/MM/yyyy').format(item.date)),
          buildTableCell(item.supplierName),
          buildTableCell(item.vatNumber),
          buildTableCell(item.invoiceNo),
          buildTableCell(item.amountExVat.toStringAsFixed(2)),
          buildTableCell(item.vatAmount.toStringAsFixed(2)),
          buildTableCell(item.totalIncVat.toStringAsFixed(2)),
        ],
      );
    }),
  ],
)
          ],
        ),
      );

      final bytes = await pdf.save();
      final safeFileName = buildSafeExportFileName(invoice.invoiceNo, extension: 'pdf');
      await downloadPdf(bytes, safeFileName);
      if (mounted) _showMsg('PDF exported successfully!', Colors.green);
    } catch (e) {
      if (mounted) _showMsg('Error exporting PDF: $e', Colors.red);
    }
  }

  Future<void> _exportToExcel(
    PurchaseInvoice invoice, [
    List<PurchaseItem>? filteredItems,
  ]) async {
    final itemsToExport = filteredItems ?? invoice.items;
    try {
      final customerProvider = context.read<CustomerProvider>();
      final customer = await customerProvider.getCustomerById(
        invoice.customerId,
      );

      final excel = Excel.createExcel();
      final sheet = excel['Invoice'];

      sheet.appendRow(['Purchase Invoice']);
      sheet.appendRow(['Invoice No', invoice.invoiceNo]);
      sheet.appendRow(['Customer', customer?.name ?? invoice.customerName]);
      sheet.appendRow([
        'Date',
        DateFormat('dd/MM/yyyy').format(invoice.invoiceDate),
      ]);
      sheet.appendRow([]);

      sheet.appendRow([
        'SL',
        'Invoice Date',
        'Invoice No',
        'Supplier',
        'VAT No',
        'Amount (Excl VAT)',
        'VAT',
        'Total (Incl VAT)',
      ]);

      for (var i = 0; i < itemsToExport.length; i++) {
        final it = itemsToExport[i];
        sheet.appendRow([
          (i + 1).toString(),
          DateFormat('dd/MM/yyyy').format(it.date),
          it.invoiceNo,
          it.supplierName,
          it.vatNumber,
          it.amountExVat.toStringAsFixed(2),
          it.vatAmount.toStringAsFixed(2),
          it.totalIncVat.toStringAsFixed(2),
        ]);
      }

      final bytes = excel.encode();
      if (bytes == null) throw 'Failed to generate Excel';
      final dir = await getTemporaryDirectory();
      final safeFileName = buildSafeExportFileName(invoice.invoiceNo);
      final file = File('${dir.path}/$safeFileName');
      await file.writeAsBytes(bytes, flush: true);
      await OpenFile.open(file.path);
      if (mounted) _showMsg('Excel exported successfully!', Colors.green);
    } catch (e) {
      if (mounted) {
        print('Error exporting Excel: $e');
        _showMsg('Error exporting Excel: $e', Colors.red);}
    }
  }

  // ── PDF Export ────────────────────────────────────────────────────────────
// Future<void> _exportToPdf(PurchaseInvoice invoice) async {
//   try {
//     final customerProvider = context.read<CustomerProvider>();
//     final customer = await customerProvider.getCustomerById(invoice.customerId);

//     // Debug: confirm item count is what you expect
//     // print('Items count: ${invoice.items.length}');

//     // ── Load fonts from local assets so PDF export works reliably ────────
//     Future<pw.Font> loadFont(String assetPath) async {
//       final fontData = await rootBundle.load(assetPath);
//       return pw.Font.ttf(fontData);
//     }

//     final arabicRegular = await loadFont('assets/fonts/NotoSansArabic-Regular.ttf');
//     final arabicBold = arabicRegular;
//     final latinRegular = pw.Font.courier();
//     final latinBold = pw.Font.courierBold();

//     const blue       = PdfColor.fromInt(0xFF4F8EF7);
//     const blueLight  = PdfColor.fromInt(0xFFF0F4FF);
//     const blueBorder = PdfColor.fromInt(0xFFBDD3FC);
//     const surface    = PdfColor.fromInt(0xFFF5F6FA);
//     const cardBorder = PdfColor.fromInt(0xFFE5E7EB);
//     const textPrimary   = PdfColor.fromInt(0xFF111827);
//     const textMuted     = PdfColor.fromInt(0xFF9CA3AF);
//     const textSecondary = PdfColor.fromInt(0xFF6B7280);

//     final pdf = pw.Document(
//       theme: pw.ThemeData.withFont(
//         base: latinRegular,
//         bold: latinBold,
//         fontFallback: [arabicRegular, arabicBold],
//       ),
//     );

//     // ── Helpers ───────────────────────────────────────────────────────────

//     bool _isArabic(String text) {
//       final arabicRegex = RegExp(r'[\u0600-\u06FF\u0750-\u077F]');
//       return arabicRegex.hasMatch(text);
//     }

//     pw.Widget sectionHeader(String label) => pw.Row(children: [
//           pw.Container(
//             width: 6, height: 6,
//             decoration: const pw.BoxDecoration(
//                 color: blue, shape: pw.BoxShape.circle),
//           ),
//           pw.SizedBox(width: 6),
//           pw.Text(label,
//               style: pw.TextStyle(
//                   fontSize: 11,
//                   fontWeight: pw.FontWeight.bold,
//                   color: textSecondary)),
//         ]);

//     pw.Widget infoTile(String label, String value) {
//       final valueIsArabic = _isArabic(value);
//       return pw.Padding(
//         padding: const pw.EdgeInsets.symmetric(vertical: 3),
//         child: pw.Row(
//           mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
//           children: [
//             pw.Text(label,
//                 style: const pw.TextStyle(fontSize: 10, color: textMuted)),
//             pw.Expanded(
//               child: pw.Directionality(
//                 textDirection: valueIsArabic
//                     ? pw.TextDirection.rtl
//                     : pw.TextDirection.ltr,
//                 child: pw.Text(
//                   value,
//                   textAlign:
//                       valueIsArabic ? pw.TextAlign.right : pw.TextAlign.left,
//                   style: pw.TextStyle(
//                       fontSize: 10,
//                       fontWeight: pw.FontWeight.bold,
//                       color: textPrimary),
//                 ),
//               ),
//             ),
//           ],
//         ),
//       );
//     }

//     pw.Widget card({required pw.Widget child}) => pw.Container(
//           padding: const pw.EdgeInsets.all(14),
//           decoration: pw.BoxDecoration(
//             color: PdfColors.white,
//             borderRadius: pw.BorderRadius.circular(12),
//             border: pw.Border.all(color: cardBorder, width: 0.5),
//           ),
//           child: child,
//         );

//     // ── Page ──────────────────────────────────────────────────────────────

//     pdf.addPage(pw.MultiPage(
//       maxPages: 1000, // raised further to safely handle very large invoices
//       pageTheme: pw.PageTheme(
//         pageFormat: PdfPageFormat.a4,
//         margin: const pw.EdgeInsets.all(0),
//         buildBackground: (ctx) => pw.Container(color: surface),
//       ),
//       header: (ctx) => ctx.pageNumber == 1
//           ? pw.Container(
//               color: PdfColors.white,
//               padding:
//                   const pw.EdgeInsets.symmetric(horizontal: 20, vertical: 14),
//               child: pw.Row(children: [
//                 pw.Text('Purchase Details',
//                     style: pw.TextStyle(
//                         fontSize: 16,
//                         fontWeight: pw.FontWeight.bold,
//                         color: textPrimary)),
//               ]),
//             )
//           : pw.SizedBox(),
//       footer: (ctx) => pw.Container(
//         alignment: pw.Alignment.center,
//         padding: const pw.EdgeInsets.only(bottom: 8),
//         child: pw.Text(
//           'Page ${ctx.pageNumber} of ${ctx.pagesCount}',
//           style: const pw.TextStyle(fontSize: 8, color: PdfColors.grey500),
//         ),
//       ),
//       build: (ctx) => [
//         pw.Padding(
//           padding: const pw.EdgeInsets.all(16),
//           child: pw.Column(
//             crossAxisAlignment: pw.CrossAxisAlignment.start,
//             children: [

//               // ── Info + Totals row (3:2) ──────────────────────────────
//               pw.Row(
//                 crossAxisAlignment: pw.CrossAxisAlignment.start,
//                 children: [

//                   // Invoice Info card
//                   pw.Expanded(
//                     flex: 3,
//                     child: card(
//                       child: pw.Column(
//                         crossAxisAlignment: pw.CrossAxisAlignment.start,
//                         children: [
//                           sectionHeader('Invoice Info'),
//                           pw.SizedBox(height: 5),
//                           infoTile('Customer', invoice.customerName),
//                           if (invoice.customerVatNumber.isNotEmpty)
//                             infoTile('VAT Number', invoice.customerVatNumber),
//                           if (invoice.periodSectionName.isNotEmpty)
//                             infoTile('Period Section', invoice.periodSectionName),
//                           if (customer != null) ...[
//                             if (customer.phone.isNotEmpty)
//                               infoTile('Phone', customer.phone),
//                             if (customer.address.isNotEmpty)
//                               infoTile('Address', customer.address),
//                           ],
//                         ],
//                       ),
//                     ),
//                   ),

//                   pw.SizedBox(width: 12),

//                   // Totals card
//                   pw.Expanded(
//                     flex: 2,
//                     child: card(
//                       child: pw.Column(
//                         crossAxisAlignment: pw.CrossAxisAlignment.start,
//                         children: [
//                           sectionHeader('Totals'),
//                           pw.SizedBox(height: 10),

//                           pw.Row(
//                             mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
//                             children: [
//                               pw.Text('Excl. VAT',
//                                   style: const pw.TextStyle(
//                                       fontSize: 10, color: textMuted)),
//                               pw.Text(invoice.totalAmountExVat.toStringAsFixed(2),
//                                   style: pw.TextStyle(
//                                       fontSize: 10,
//                                       fontWeight: pw.FontWeight.bold,
//                                       color: textPrimary)),
//                             ],
//                           ),
//                           pw.Divider(color: cardBorder, height: 14),

//                           pw.Row(
//                             mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
//                             children: [
//                               pw.Text('VAT',
//                                   style: const pw.TextStyle(
//                                       fontSize: 10, color: textMuted)),
//                               pw.Text(invoice.totalVatAmount.toStringAsFixed(2),
//                                   style: pw.TextStyle(
//                                       fontSize: 10,
//                                       fontWeight: pw.FontWeight.bold,
//                                       color: textPrimary)),
//                             ],
//                           ),
//                           pw.Divider(color: cardBorder, height: 14),

//                           pw.Container(
//                             padding: const pw.EdgeInsets.symmetric(
//                                 horizontal: 12, vertical: 10),
//                             decoration: pw.BoxDecoration(
//                               color: blueLight,
//                               borderRadius: pw.BorderRadius.circular(10),
//                               border: pw.Border.all(color: blueBorder, width: 0.5),
//                             ),
//                             child: pw.Row(
//                               mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
//                               children: [
//                                 pw.Text('Grand Total',
//                                     style: pw.TextStyle(
//                                         fontSize: 11,
//                                         fontWeight: pw.FontWeight.bold,
//                                         color: blue)),
//                                 pw.Text(invoice.totalAmountIncVat.toStringAsFixed(2),
//                                     style: pw.TextStyle(
//                                         fontSize: 12,
//                                         fontWeight: pw.FontWeight.bold,
//                                         color: blue)),
//                               ],
//                             ),
//                           ),
//                         ],
//                       ),
//                     ),
//                   ),
//                 ],
//               ),

//               pw.SizedBox(height: 16),

//               // ── Line Items header ─────────────────────────────────────
//               pw.Row(children: [
//                 sectionHeader('Line Items'),
//                 pw.Spacer(),
//                 pw.Container(
//                   padding: const pw.EdgeInsets.symmetric(
//                       horizontal: 10, vertical: 4),
//                   decoration: pw.BoxDecoration(
//                     color: const PdfColor.fromInt(0xFFF0F1F5),
//                     borderRadius: pw.BorderRadius.circular(20),
//                   ),
//                   child: pw.Text('${invoice.items.length} items',
//                       style: pw.TextStyle(
//                           fontSize: 11,
//                           fontWeight: pw.FontWeight.bold,
//                           color: blue)),
//                 ),
//               ]),

//               pw.SizedBox(height: 12),

//               // ── Line Items table ──────────────────────────────────────
//               pw.TableHelper.fromTextArray(
//                 headers: [
//                   'SL',
//                   'Invoice Date',
//                   'Supplier',
//                   'VAT No',
//                   'Invoice No',
//                   'Amount',
//                   'VAT',
//                   'Total',
//                   'Created Date',
//                 ],
//                 headerStyle: pw.TextStyle(
//                     fontWeight: pw.FontWeight.bold,
//                     fontSize: 9,
//                     color: textPrimary),
//                 headerDecoration: const pw.BoxDecoration(color: surface),
//                 cellStyle: const pw.TextStyle(fontSize: 9, color: textPrimary),
//                 cellAlignments: {
//                   0: pw.Alignment.center,
//                   1: pw.Alignment.center,
//                   2: pw.Alignment.centerLeft,
//                   3: pw.Alignment.center,
//                   4: pw.Alignment.center,
//                   5: pw.Alignment.center,
//                   6: pw.Alignment.center,
//                   7: pw.Alignment.center,
//                   8: pw.Alignment.center,
//                 },
//                 columnWidths: {
//                   0: const pw.FlexColumnWidth(0.6),
//                   1: const pw.FlexColumnWidth(1.4),
//                   2: const pw.FlexColumnWidth(3.0),
//                   3: const pw.FlexColumnWidth(2.0),
//                   4: const pw.FlexColumnWidth(1.8),
//                   5: const pw.FlexColumnWidth(1.1),
//                   6: const pw.FlexColumnWidth(0.9),
//                   7: const pw.FlexColumnWidth(1.4),
//                   8: const pw.FlexColumnWidth(1.6),
//                 },
//                 border: pw.TableBorder.all(color: cardBorder, width: 0.5),
//                 cellPadding: const pw.EdgeInsets.symmetric(
//                     horizontal: 4, vertical: 6),
//                 data: List.generate(invoice.items.length, (i) {
//                   final item = invoice.items[i];
//                   return [
//                     '${i + 1}',
//                     DateFormat('dd/MM/yyyy').format(item.date),
//                     item.supplierName,
//                     item.vatNumber,
//                     item.invoiceNo,
//                     item.amountExVat.toStringAsFixed(2),
//                     item.vatAmount.toStringAsFixed(2),
//                     item.totalIncVat.toStringAsFixed(2),
//                     DateFormat('dd/MM/yyyy HH:mm:ss').format(item.createdAt),
//                   ];
//                 }),
//               ),

//               pw.SizedBox(height: 10),

//               // ── Footer note ────────────────────────────────────────────
//               pw.Center(
//                 child: pw.Column(
//                   children: [
//                     pw.Text(
//                       'Generated on ${DateFormat('dd/MM/yyyy HH:mm:ss').format(DateTime.now())}',
//                       style: const pw.TextStyle(
//                           fontSize: 9, color: PdfColors.grey600),
//                     ),
//                     pw.SizedBox(height: 4),
//                     pw.Text(
//                       'This is an automatically generated document',
//                       style: const pw.TextStyle(
//                           fontSize: 8, color: PdfColors.grey500),
//                     ),
//                   ],
//                 ),
//               ),
//             ],
//           ),
//         ),
//       ],
//     ));

//     final bytes = await pdf.save();
//     await downloadPdf(bytes, 'invoice_${invoice.invoiceNo}.pdf');
//     if (mounted) _showMsg('PDF exported successfully!', Colors.green);
//   } catch (e) {
//     _showMsg('Error exporting PDF: $e', Colors.red);
//   }
// }

// Future<void> _exportToExcel(PurchaseInvoice invoice) async {
//   try {
//     final customerProvider = context.read<CustomerProvider>();
//     final customer = await customerProvider.getCustomerById(invoice.customerId);

//     final excel = Excel.createExcel();
//     final sheetName = 'Invoice';
//     final sheet = excel[sheetName];

//     sheet.appendRow(['Purchase Invoice']);
//     sheet.appendRow(['Invoice No', invoice.invoiceNo]);
//     sheet.appendRow(['Customer', customer?.name ?? invoice.customerName]);
//     sheet.appendRow(['Date', DateFormat('dd/MM/yyyy').format(invoice.invoiceDate)]);
//     sheet.appendRow([]);

//     sheet.appendRow([
//       'SL',
//       'Invoice Date',
//       'Invoice No',
//       'Supplier',
//       'VAT No',
//       'Amount (Excl VAT)',
//       'VAT',
//       'Total (Incl VAT)'
//     ]);

//     for (var i = 0; i < invoice.items.length; i++) {
//       final it = invoice.items[i];
//       sheet.appendRow([
//         (i + 1).toString(),
//         DateFormat('dd/MM/yyyy').format(it.date),
//         it.invoiceNo,
//         it.supplierName,
//         it.vatNumber,
//         it.amountExVat.toStringAsFixed(2),
//         it.vatAmount.toStringAsFixed(2),
//         it.totalIncVat.toStringAsFixed(2),
//       ]);
//     }

//     final bytes = excel.encode();
//     if (bytes == null) throw 'Failed to generate Excel bytes';

//     final dir = await getTemporaryDirectory();
//     final file = File('${dir.path}/invoice_${invoice.invoiceNo}.xlsx');
//     await file.writeAsBytes(bytes, flush: true);

//     await OpenFile.open(file.path);
//     if (mounted) _showMsg('Excel exported successfully!', Colors.green);
//   } catch (e) {
//     if (mounted) _showMsg('Error exporting Excel: $e', Colors.red);
//   }
// }

// void _showInvoiceDetails(PurchaseInvoice invoice) {
//   DateTime? _itemFilterFrom;
//   DateTime? _itemFilterTo;
//   List<PurchaseItem> _filteredInvoiceItems = List.from(invoice.items);

//   void _applyInvoiceItemDateFilter() {
//     if (_itemFilterFrom == null && _itemFilterTo == null) {
//       _filteredInvoiceItems = List.from(invoice.items);
//       return;
//     }

//     _filteredInvoiceItems = invoice.items.where((item) {
//       final itemDate = DateTime(item.date.year, item.date.month, item.date.day);
//       final fromDate = _itemFilterFrom != null
//           ? DateTime(_itemFilterFrom!.year, _itemFilterFrom!.month, _itemFilterFrom!.day)
//           : null;
//       final toDate = _itemFilterTo != null
//           ? DateTime(_itemFilterTo!.year, _itemFilterTo!.month, _itemFilterTo!.day)
//           : null;
//       final afterFrom = fromDate == null || !itemDate.isBefore(fromDate);
//       final beforeTo = toDate == null || !itemDate.isAfter(toDate);
//       return afterFrom && beforeTo;
//     }).toList();
//   }

//   showDialog(
//     context: context,
//     barrierDismissible: true,
//     builder: (ctx) => StatefulBuilder(
//       builder: (context, setDialogState) {
//         return Dialog(
//           insetPadding: const EdgeInsets.all(16),
//           backgroundColor: Colors.transparent,
//           child: Container(
//             height: MediaQuery.of(context).size.height * 0.88,
//             width: 1050,
//             decoration: BoxDecoration(
//               color: const Color(0xFFF5F6FA),
//               borderRadius: BorderRadius.circular(20),
//             ),
//             child: ClipRRect(
//               borderRadius: BorderRadius.circular(20),
//               child: Column(
//                 children: [
//                 // ── Top bar ───────────────────────────────────────────────
//                 Container(
//                   padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 14),
//                   decoration: const BoxDecoration(color: Colors.white),
//                   child: Row(
//                     children: [
//                       Container(
//                         padding: const EdgeInsets.all(8),
//                         decoration: BoxDecoration(
//                           color: const Color(0xFFF0F1F5),
//                           borderRadius: BorderRadius.circular(10),
//                         ),
//                         child: const Icon(Icons.receipt_long_outlined,
//                             size: 20, color: Color(0xFF4F8EF7)),
//                       ),
//                       const SizedBox(width: 12),
//                       const Text(
//                         'Invoice Details',
//                         style: TextStyle(
//                             fontSize: 18, fontWeight: FontWeight.w700),
//                       ),
//                       const Spacer(),
//                       IconButton(
//                         onPressed: () => Navigator.pop(ctx),
//                         icon: const Icon(Icons.close_rounded),
//                         style: IconButton.styleFrom(
//                           backgroundColor: const Color(0xFFF0F1F5),
//                           shape: RoundedRectangleBorder(
//                               borderRadius: BorderRadius.circular(10)),
//                         ),
//                       ),
//                     ],
//                   ),
//                 ),

//                 // ── Scrollable body ───────────────────────────────────────
//                 Expanded(
//                   child: Padding(
//                     padding: const EdgeInsets.all(16),
//                     child: Column(
//                       crossAxisAlignment: CrossAxisAlignment.start,
//                       children: [
//                         // ── Info + Totals row ─────────────────────────────
//                         Row(
//                           crossAxisAlignment: CrossAxisAlignment.start,
//                           children: [
//                             // Invoice info card
//                             Expanded(
//                               flex: 3,
//                               child: _InfoCard(
//                                 title: 'Invoice Info',
//                                 icon: Icons.info_outline_rounded,
//                                 children: [
//                                   _InfoTile(
//                                       label: 'Customer',
//                                       value: invoice.customerName),
//                                   if (invoice.customerVatNumber.isNotEmpty)
//                                     _InfoTile(
//                                         label: 'VAT Number',
//                                         value: invoice.customerVatNumber),
//                                   _InfoTile(
//                                       label: 'Created Date',
//                                       value: DateFormat('dd MMM yyyy')
//                                           .format(invoice.createdAt)),
//                                   if (invoice.periodSectionName.isNotEmpty)
//                                     _InfoTile(
//                                         label: 'Period Section',
//                                         value: invoice.periodSectionName),
//                                 ],
//                               ),
//                             ),
//                             const SizedBox(width: 12),
//                             // Totals card
//                             Expanded(
//                               flex: 2,
//                               child: Container(
//                                 padding: const EdgeInsets.all(16),
//                                 decoration: BoxDecoration(
//                                   color: Colors.white,
//                                   borderRadius: BorderRadius.circular(14),
//                                   border: Border.all(
//                                       color: Colors.grey.shade200),
//                                 ),
//                                 child: Column(
//                                   crossAxisAlignment:
//                                       CrossAxisAlignment.start,
//                                   children: [
//                                     Row(children: [
//                                       const Icon(
//                                           Icons.calculate_outlined,
//                                           size: 16,
//                                           color: Color(0xFF4F8EF7)),
//                                       const SizedBox(width: 6),
//                                       Text('Totals',
//                                           style: TextStyle(
//                                               fontWeight: FontWeight.w700,
//                                               fontSize: 13,
//                                               color: Colors.grey.shade700)),
//                                     ]),
//                                     const SizedBox(height: 12),
//                                     _TotalRow(
//                                         label: 'Excl. VAT',
//                                         value: invoice.totalAmountExVat
//                                             .toStringAsFixed(2)),
//                                     const Divider(height: 16),
//                                     _TotalRow(
//                                         label: 'VAT',
//                                         value: invoice.totalVatAmount
//                                             .toStringAsFixed(2)),
//                                     const Divider(height: 16),
//                                     Container(
//                                       padding: const EdgeInsets.symmetric(
//                                           horizontal: 12, vertical: 10),
//                                       decoration: BoxDecoration(
//                                         color: const Color(0xFF4F8EF7)
//                                             .withOpacity(0.08),
//                                         borderRadius:
//                                             BorderRadius.circular(10),
//                                         border: Border.all(
//                                             color: const Color(0xFF4F8EF7)
//                                                 .withOpacity(0.25)),
//                                       ),
//                                       child: Row(
//                                         mainAxisAlignment:
//                                             MainAxisAlignment.spaceBetween,
//                                         children: [
//                                           const Text('Grand Total',
//                                               style: TextStyle(
//                                                   fontWeight: FontWeight.w700,
//                                                   fontSize: 14,
//                                                   color:
//                                                       Color(0xFF4F8EF7))),
//                                           Row(
//                                     children: [
// // Icon(
// //   LucideIcons.saudiRiyal, // or LucideIcons.saudi_riyal depending on version
// //   size: 16,fontWeight: FontWeight.w600,
// // ),
// //                                                const SizedBox(width: 2),
//                                               Text(
//                                                "${ invoice.totalAmountIncVat
//                                                     .toStringAsFixed(2)}",
//                                                 style: const TextStyle(
//                                                     fontWeight: FontWeight.w800,
//                                                     fontSize: 16,
//                                                     color: Color(0xFF4F8EF7)),
//                                               ),
//                                             ],
//                                           ),
//                                         ],
//                                       ),
//                                     ),
//                                   ],
//                                 ),
//                               ),
//                             ),
//                           ],
//                         ),
                    
//                         const SizedBox(height: 16),
                    
//                         // ── Line items ────────────────────────────────────
//                         Expanded(
//                           child: Container(
//                             width: double.infinity,
//                             padding: const EdgeInsets.all(16),
//                             decoration: BoxDecoration(
//                               color: Colors.white,
//                               borderRadius: BorderRadius.circular(14),
//                               border:
//                                   Border.all(color: Colors.grey.shade200),
//                             ),
//                             child: Column(
//                               crossAxisAlignment: CrossAxisAlignment.start,
//                               children: [
//                                 Row(children: [
//                                   const Icon(Icons.list_alt_outlined,
//                                       size: 16, color: Color(0xFF4F8EF7)),
//                                   const SizedBox(width: 6),
//                                   Text('Line Items',
//                                       style: TextStyle(
//                                           fontWeight: FontWeight.w700,
//                                           fontSize: 13,
//                                           color: Colors.grey.shade700)),
//                                   const Spacer(),
//                                   Container(
//                                     padding: const EdgeInsets.symmetric(
//                                         horizontal: 10, vertical: 4),
//                                     decoration: BoxDecoration(
//                                       color:
//                                           const Color(0xFFF0F1F5),
//                                       borderRadius:
//                                           BorderRadius.circular(20),
//                                     ),
//                                     child: Text(
//                                       '${_filteredInvoiceItems.length} items',
//                                       style: const TextStyle(
//                                           fontSize: 12,
//                                           fontWeight: FontWeight.w600,
//                                           color: Color(0xFF4F8EF7)),
//                                     ),
//                                   ),
//                                 ]),
//                                 const SizedBox(height: 12),
//                                 Row(
//                                   children: [
//                                     const Icon(Icons.filter_alt_outlined,
//                                         size: 16, color: Color(0xFF4F8EF7)),
//                                     const SizedBox(width: 6),
//                                     const Text('Item date filter',
//                                         style: TextStyle(
//                                             fontWeight: FontWeight.w700,
//                                             fontSize: 13,
//                                             color: Color(0xFF4F8EF7))),
//                                     const Spacer(),
//                                     if (_itemFilterFrom != null ||
//                                         _itemFilterTo != null)
//                                       Expanded(
//                                         child: Text(
//                                           '${_itemFilterFrom != null ? DateFormat('dd MMM yyyy').format(_itemFilterFrom!) : '—'}'
//                                           '  →  '
//                                           '${_itemFilterTo != null ? DateFormat('dd MMM yyyy').format(_itemFilterTo!) : '—'}',
//                                           style: const TextStyle(
//                                               fontSize: 12,
//                                               color: Colors.black87),
//                                           textAlign: TextAlign.right,
//                                         ),
//                                       ),
//                                     TextButton.icon(
//                                       onPressed: () async {
//                                         final now = DateTime.now();
//                                         final picked = await showDateRangePicker(
//                                           context: context,
//                                           firstDate: DateTime(2020),
//                                           lastDate: now,
//                                           initialDateRange: _itemFilterFrom != null &&
//                                                   _itemFilterTo != null
//                                               ? DateTimeRange(
//                                                   start: _itemFilterFrom!,
//                                                   end: _itemFilterTo!)
//                                               : DateTimeRange(
//                                                   start: now.subtract(
//                                                       const Duration(days: 30)),
//                                                   end: now),
//                                         );
//                                         if (picked != null) {
//                                           setDialogState(() {
//                                             _itemFilterFrom = picked.start;
//                                             _itemFilterTo = picked.end;
//                                             _applyInvoiceItemDateFilter();
//                                           });
//                                         }
//                                       },
//                                       icon: const Icon(Icons.date_range,
//                                           size: 18),
//                                       label: const Text('Date range'),
//                                     ),
//                                     if (_itemFilterFrom != null ||
//                                         _itemFilterTo != null)
//                                       TextButton(
//                                         onPressed: () {
//                                           setDialogState(() {
//                                             _itemFilterFrom = null;
//                                             _itemFilterTo = null;
//                                             _applyInvoiceItemDateFilter();
//                                           });
//                                         },
//                                         child: const Text('Clear'),
//                                       ),
//                                   ],
//                                 ),
//                                 const SizedBox(height: 12),
//                                 Expanded(
//                                   child: SingleChildScrollView(
//                                     scrollDirection: Axis.vertical,
//                                     child: DataTable(
//                                       dataRowHeight: 42,
//                                       headingRowHeight: 42,
//                                       columnSpacing: 12,
//                                       border: TableBorder.all(
//                                           color: Colors.grey.shade200,
//                                           borderRadius:
//                                               BorderRadius.circular(10)),
//                                       headingRowColor:
//                                           WidgetStateProperty.all(
//                                               const Color(0xFFF5F6FA)),
//                                       columns: const [
//                                         DataColumn(label: Expanded(child: Text('SL No.',       textAlign: TextAlign.center, style: TextStyle(fontWeight: FontWeight.w700, fontSize: 13)))),
//                                         DataColumn(label: Expanded(child: Text('Created Date', textAlign: TextAlign.center, style: TextStyle(fontWeight: FontWeight.w700, fontSize: 13)))),
//                                         DataColumn(label: Expanded(child: Text('Invoice Date', textAlign: TextAlign.center, style: TextStyle(fontWeight: FontWeight.w700, fontSize: 13)))),
//                                         DataColumn(label: Expanded(child: Text('Supplier',     textAlign: TextAlign.left,   style: TextStyle(fontWeight: FontWeight.w700, fontSize: 13)))),
//                                         DataColumn(label: Expanded(child: Text('VAT No',       textAlign: TextAlign.center, style: TextStyle(fontWeight: FontWeight.w700, fontSize: 13)))),
//                                         DataColumn(label: Expanded(child: Text('Invoice No',   textAlign: TextAlign.center, style: TextStyle(fontWeight: FontWeight.w700, fontSize: 13)))),
//                                         DataColumn(label: Expanded(child: Text('Excl. Amount', textAlign: TextAlign.center, style: TextStyle(fontWeight: FontWeight.w700, fontSize: 13)))),
//                                         DataColumn(label: Expanded(child: Text('VAT',          textAlign: TextAlign.center, style: TextStyle(fontWeight: FontWeight.w700, fontSize: 13)))),
//                                         DataColumn(label: Expanded(child: Text('Total',        textAlign: TextAlign.center, style: TextStyle(fontWeight: FontWeight.w700, fontSize: 13)))),
//                                       ],
//                                       rows: List.generate(_filteredInvoiceItems.length, (i) {
//                                         final item = _filteredInvoiceItems[i];
//                                         return DataRow(
//                                           color: WidgetStateProperty.all(
//                                               i.isEven
//                                                   ? const Color(0xFFF9FAFB)
//                                                   : Colors.white),
//                                           cells: [
//                                             DataCell(Center(child: Text('${i + 1}', style: const TextStyle(fontSize: 13)))),
//                                             DataCell(Center(child: Text(DateFormat('dd/MM/yyyy HH:mm:ss').format(item.createdAt), style: const TextStyle(fontSize: 13)))),
//                                             DataCell(Center(child: Text(DateFormat('dd/MM/yyyy').format(item.date), style: const TextStyle(fontSize: 13)))),
//                                             DataCell(SizedBox(width: 220, child: Text(item.supplierName, overflow: TextOverflow.ellipsis, maxLines: 2, style: const TextStyle(fontSize: 13)))),
//                                             DataCell(Center(child: Text(item.vatNumber, style: const TextStyle(fontSize: 13)))),
//                                             DataCell(SizedBox(width: 100, child: Text(item.invoiceNo, textAlign: TextAlign.center, style: const TextStyle(fontSize: 13)))),
//                                             DataCell(SizedBox(width: 80,  child: Text(item.amountExVat.toStringAsFixed(2), textAlign: TextAlign.right, style: const TextStyle(fontSize: 13)))),
//                                             DataCell(SizedBox(width: 70,  child: Text(item.vatAmount.toStringAsFixed(2),   textAlign: TextAlign.right, style: const TextStyle(fontSize: 13)))),
//                                             DataCell(SizedBox(width: 90,  child: Text(item.totalIncVat.toStringAsFixed(2), textAlign: TextAlign.right, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 13, color: Color(0xFF4F8EF7))))),
//                                           ],
//                                         );
//                                       }),
//                                     ),
//                                   ),
//                                 ),
//                               ],
//                             ),
//                           ),
//                         ),
                    
//                         const SizedBox(height: 16),
                    
//                         // ── Export buttons ────────────────────────────────
//                         Row(mainAxisAlignment: MainAxisAlignment.spaceBetween,
//                           children: [
//                             Row(children: [
//                               Container(width: 120,
//                                 child:
                                
//                                 ElevatedButton.icon(
//                           onPressed:() async {
//                                     Navigator.pop(ctx);
//                                     await _exportToPdf(invoice);
//                                   },
//                           icon: FaIcon(FontAwesomeIcons.solidFilePdf,color: Colors.red),
//                           label: Text('Export PDF'),
//                           style: ElevatedButton.styleFrom(
//                             backgroundColor: Colors.white,
//                             foregroundColor: Colors.red,
//                             elevation: 0,
//                             padding: const EdgeInsets.symmetric(vertical: 13),
//                             shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(30)),
//                             textStyle: const TextStyle(fontWeight: FontWeight.w600, fontSize: 14),
//                           ),
//                         )
//                                 //  _ActionBtn(
//                                 //   label: 'Export PDF',
//                                 //   icon: const Icon(Icons.picture_as_pdf_outlined, size: 18, color: Colors.white),
//                                 //   color: Colors.red.shade600,
//                                 //   onTap: () async {
//                                 //     Navigator.pop(ctx);
//                                 //     await _exportToPdf(invoice);
//                                 //   },
//                                 // ),
//                               ),
//                               const SizedBox(width: 10),
//                                 Container(width: 120,child:
//                                 ElevatedButton.icon(
//                               onPressed: () async {
//                                   Navigator.pop(ctx);
//                                   await _exportToExcel(invoice);
//                                   },
//                               icon: FaIcon(FontAwesomeIcons.solidFileExcel, color: Colors.green.shade700),
//                               label: Text('Export Excel'),
//                           style: ElevatedButton.styleFrom(
//                             foregroundColor: Colors.green.shade700,
//                             backgroundColor: Colors.white,
//                             elevation: 0,
//                             padding: const EdgeInsets.symmetric(vertical: 13),
//                             shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(30)),
//                             textStyle: const TextStyle(fontWeight: FontWeight.w600, fontSize: 14),
//                           ),
//                         )
                    
                    
//                                 // child: 
//                                 // _ActionBtn(
//                                 //   label: 'Export Excel',
//                                 //   icon:FontAwesomeIcons.fileExcel,
//                                 //   color: Colors.green.shade700,
//                                 //   onTap: () {},
//                                 // ),
//                               ),
//                             ]),
                            
                                 
                            
//                             // ── Delete + Edit buttons ─────────────────────────
//                             Row(children: [
//                               Container(width: 130,
//                                 child: _OutlineBtn(
//                                   label: 'Delete Invoice',
//                                   icon: Icons.delete_outline_rounded,
//                                   color: Colors.red.shade600,
//                                   onTap: () {
//                                     Navigator.pop(ctx);
//                                     _deleteInvoice(invoice.id);
//                                   },
//                                 ),
//                               ),
//                               const SizedBox(width: 10),
//                               Container(width: 120,
//                                 child: _OutlineBtn(
//                                   label: 'Edit Invoice',
//                                   icon: Icons.edit_outlined,
//                                   color: const Color(0xFF4F8EF7),
//                                   onTap: () {
//                                     Navigator.pop(ctx);
//                                     Navigator.push(
//                                       context,
//                                       MaterialPageRoute(
//                                         builder: (_) =>
//                                             PurchaseEntryScreen(invoice: invoice),
//                                       ),
//                                     );
//                                   },
//                                 ),
//                               ),
//                             ]),
//                           ],
//                         ),
                    
                    
//                       ],
//                     ),
//                   ),
//                 ),
//               ],
//             ),
//           ),
//         ),
//       );
//     },)
//   );
// }

  // ── Helpers ───────────────────────────────────────────────────────────────
  Widget _buildTotalColumn(String label, String value, Color color) =>
      Row(mainAxisAlignment:MainAxisAlignment.spaceBetween, children: [
        Text(label, style: const TextStyle(fontSize: 12)),
        Text(value,
            style: TextStyle(
                fontSize: 16, fontWeight: FontWeight.bold, color: color)),
      ]);

  Widget _buildDetailRow(String label, String value) => Padding(
        padding: const EdgeInsets.symmetric(vertical: 6),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text(label,
                style: TextStyle(
                    color: Colors.grey.shade700,
                    fontWeight: FontWeight.w600,
                    fontSize: 14)),
            Text(value,
                style: const TextStyle(
                    fontWeight: FontWeight.w600, fontSize: 13)),
          ],
        ),
      );

  void _showMsg(String msg, Color color) =>
      ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text(msg), backgroundColor: color));

  // ── Build ─────────────────────────────────────────────────────────────────
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey.shade50,
      appBar: AppBar(
        centerTitle: true,
        title: const Text('Purchase Entries'),
        toolbarHeight: 50,
        backgroundColor: Colors.white,
        scrolledUnderElevation: 0,
        elevation: 0,
        actions: [
          GestureDetector(
              onTap: () => Navigator.push(
                context,
                MaterialPageRoute(builder: (_) => PurchaseEntryScreen()),
              ),
              child: Container(
                margin: const EdgeInsets.only(right: 12, ),
                padding: const EdgeInsets.symmetric(
                    vertical: 8, horizontal: 18),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(10),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.grey.withOpacity(0.2),
                      blurRadius: 8,
                      offset: const Offset(0, 0),
                    ),
                  ],
                ),
                child: const Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Icon(Icons.add, color: Colors.black),
                    SizedBox(width: 8),
                    Text('Create Purchase Entry',
                        style: TextStyle(
                            color: Colors.black,
                            fontSize: 15,
                            fontWeight: FontWeight.w600)),
                  ],
                ),
              ),
            ),
        ],
      ),
      body: Column(
        children: [
          // ── Search bar ────────────────────────────────────────────────
          

          // ── Quick filter chips + Date Range button ─────────────────────
          Padding(
            padding: const EdgeInsets.fromLTRB(8, 8, 8, 4),
            child: Row(
              children: [
                Expanded(
                  child: SingleChildScrollView(
                    scrollDirection: Axis.horizontal,
                    child: Row(children: [
                      _buildFilterChip('All', 'all'),
                      _buildFilterChip('Today', 'today'),
                      _buildFilterChip('This Week', 'week'),
                      _buildFilterChip('This Month', 'month'),
                       GestureDetector(
                      onTap: _pickDateRange,
                      child: AnimatedContainer(
                        duration: const Duration(milliseconds: 180),
                        margin: const EdgeInsets.only(left: 6),
                        padding: const EdgeInsets.symmetric(
                            horizontal: 10, vertical: 7),
                        decoration: BoxDecoration(
                          color: _filterType == 'custom'
                              ? Colors.blue.shade700
                              : Colors.grey.shade200,
                          borderRadius: BorderRadius.circular(20),
                        ),
                        child: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Icon(Icons.date_range,
                                size: 15,
                                color: _filterType == 'custom'
                                    ? Colors.white
                                    : Colors.black87),
                            const SizedBox(width: 4),
                            Text(
                              'Date Range',
                              style: TextStyle(
                                fontSize: 12,
                                fontWeight: _filterType == 'custom'
                                    ? FontWeight.w600
                                    : FontWeight.normal,
                                color: _filterType == 'custom'
                                    ? Colors.white
                                    : Colors.black87,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                    if (_filterType == 'custom' &&
              (_customFrom != null || _customTo != null))
            Container(width: 280,
              margin: const EdgeInsets.fromLTRB(8, 0, 8, 0),
              padding:
                  const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
              decoration: BoxDecoration(
                color: Colors.blue.shade50,
                borderRadius: BorderRadius.circular(8),
                border: Border.all(color: Colors.blue.shade200),
              ),
              child: Row(
                children: [
                  Icon(Icons.filter_alt_outlined,
                      size: 15, color: Colors.blue.shade700),
                  const SizedBox(width: 6),
                  Expanded(
                    child: Text(
                      '${_customFrom != null ? DateFormat('dd MMM yyyy').format(_customFrom!) : '—'}'
                      '  →  '
                      '${_customTo != null ? DateFormat('dd MMM yyyy').format(_customTo!) : '—'}',
                      style: TextStyle(
                        fontSize: 12,
                        fontWeight: FontWeight.w600,
                        color: Colors.blue.shade800,
                      ),
                    ),
                  ),
                  // Edit date range
                  GestureDetector(
                    onTap: _pickDateRange,
                    child: Icon(Icons.edit_calendar_outlined,
                        size: 16, color: Colors.blue.shade700),
                  ),
                  const SizedBox(width: 12),
                  // Clear
                  GestureDetector(
                    onTap: _clearDateRange,
                    child: Icon(Icons.close,
                        size: 16, color: Colors.blue.shade700),
                  ),
                ],
              ),
            ),
                    ]),
                  ),
                ),

                // ── Date Range picker button ───────────────────────────
                Row(
                  children: [
                   
                    Padding(
            padding: const EdgeInsets.fromLTRB(8, 0, 8, 0),
            child: SizedBox(width: 280,height: 32,
              child: TextField(
                controller: _searchController,
                onChanged: (q) => _applyFilters(query: q),
                decoration: InputDecoration(
                  filled: true,
                  fillColor: Colors.grey[200],
                  hintText:
                      'Search by customer, supplier, or invoice #...',
                  prefixIcon: Icon(LucideIcons.search),
                  border: OutlineInputBorder(borderRadius: BorderRadius.circular(8)),
                  enabledBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(8),
                    borderSide: BorderSide(color: Colors.grey.shade400),
                  ),
                  focusedBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(8),
                    borderSide: BorderSide(color: Colors.grey.shade400, width: 1.0),
                  ),
                  isDense: true,
                  contentPadding:
                      EdgeInsets.symmetric(horizontal: 5, vertical: 0),
                ),
              ),
            ),
          ),
          // ── Period section multi-select button ────────────────────
          Padding(
            padding: const EdgeInsets.fromLTRB(8, 0, 8, 0),
            child: Container(
              width: 220,
              height: 36,
              decoration: BoxDecoration(
                color: Colors.white,
                border: Border.all(color: Colors.grey.shade300),
                borderRadius: BorderRadius.circular(8),
              ),
              child: _periodsLoading
                  ? const Center(child: SizedBox(width: 16, height: 16, child: CircularProgressIndicator(strokeWidth: 2)))
                  : Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 8),
                      child: DropdownButtonHideUnderline(
                        child: DropdownButton<String>(
                          value: _selectedPeriodIds.isEmpty
                              ? 'all'
                              : (_selectedPeriodIds.length == 1
                                  ? _selectedPeriodIds.first
                                  : 'multi'),
                          isExpanded: true,
                          icon: Icon(Icons.expand_more, size: 20, color: Colors.grey.shade600),
                          items: [
                            DropdownMenuItem(
                              value: 'all',
                              child: Text('All Periods', style: const TextStyle(fontSize: 13, color: Colors.black87)),
                            ),
                            // individual periods
                            ..._periods.map((p) => DropdownMenuItem(
                                  value: p['id'],
                                  child: Text(p['name']!, style: const TextStyle(fontSize: 13, color: Colors.black87)),
                                )),
                            // multi-select entry
                            DropdownMenuItem(
                              value: 'multi',
                              child: Text('Select multiple...', style: const TextStyle(fontSize: 13, color: Colors.black87)),
                            ),
                          ],
                          onChanged: (val) {
                            if (val == null) return;
                            if (val == 'all') {
                              setState(() => _selectedPeriodIds.clear());
                              _applyFilters();
                              return;
                            }
                            if (val == 'multi') {
                              _showPeriodSelectDialog();
                              return;
                            }
                            // single period selected -> apply as a single-item set
                            setState(() {
                              _selectedPeriodIds = {val};
                            });
                            _applyFilters();
                          },
                        ),
                      ),
                    ),
            ),
          ),
          IconButton(
            onPressed: _loadInvoices,
            icon: const Icon(Icons.refresh, color: Colors.blueGrey),
          ),
                  ],
                ),
              ],
            ),
          ),

          // ── Active date range banner ───────────────────────────────────
          // if (_filterType == 'custom' &&
          //     (_customFrom != null || _customTo != null))
          //   Container(
          //     margin: const EdgeInsets.fromLTRB(8, 0, 8, 6),
          //     padding:
          //         const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
          //     decoration: BoxDecoration(
          //       color: Colors.blue.shade50,
          //       borderRadius: BorderRadius.circular(8),
          //       border: Border.all(color: Colors.blue.shade200),
          //     ),
          //     child: Row(
          //       children: [
          //         Icon(Icons.filter_alt_outlined,
          //             size: 15, color: Colors.blue.shade700),
          //         const SizedBox(width: 6),
          //         Expanded(
          //           child: Text(
          //             '${_customFrom != null ? DateFormat('dd MMM yyyy').format(_customFrom!) : '—'}'
          //             '  →  '
          //             '${_customTo != null ? DateFormat('dd MMM yyyy').format(_customTo!) : '—'}',
          //             style: TextStyle(
          //               fontSize: 12,
          //               fontWeight: FontWeight.w600,
          //               color: Colors.blue.shade800,
          //             ),
          //           ),
          //         ),
          //         // Edit date range
          //         GestureDetector(
          //           onTap: _pickDateRange,
          //           child: Icon(Icons.edit_calendar_outlined,
          //               size: 16, color: Colors.blue.shade700),
          //         ),
          //         const SizedBox(width: 12),
          //         // Clear
          //         GestureDetector(
          //           onTap: _clearDateRange,
          //           child: Icon(Icons.close,
          //               size: 16, color: Colors.blue.shade700),
          //         ),
          //       ],
          //     ),
          //   ),

          // ── Results summary row ────────────────────────────────────────
          Padding(
            padding: const EdgeInsets.fromLTRB(12, 0, 12, 6),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  '${_filteredInvoices.length} invoice${_filteredInvoices.length == 1 ? '' : 's'}',
                  style: TextStyle(
                      fontSize: 12, color: Colors.grey.shade600),
                ),
                if (_filteredInvoices.isNotEmpty)
                  Text(
                    'Total: ${_filteredInvoices.fold<double>(0, (s, inv) => s + inv.totalAmountIncVat).toStringAsFixed(2)}',
                    style: TextStyle(
                        fontSize: 12,
                        fontWeight: FontWeight.w600,
                        color: Colors.purple.shade700),
                  ),
              ],
            ),
          ),

          // ── Data table ────────────────────────────────────────────────
          Expanded(
            child: _isLoading
                ? const Center(child: CircularProgressIndicator())
                : _filteredInvoices.isEmpty
                    ? Center(
                        child: Column(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Icon(Icons.receipt_long_outlined,
                                size: 52, color: Colors.grey.shade400),
                            const SizedBox(height: 10),
                            Text('No invoices found',
                                style: TextStyle(
                                    color: Colors.grey.shade600,
                                    fontSize: 15)),
                            if (_filterType != 'all')
                              TextButton(
                                onPressed: _clearDateRange,
                                child: const Text('Clear filters'),
                              ),
                          ],
                        ),
                      )
                    : SingleChildScrollView(
                        padding:
                            const EdgeInsets.symmetric(horizontal: 8),
                        scrollDirection: Axis.horizontal,
                        child: DataTable(
  border: TableBorder.all(color: Colors.grey.shade300,borderRadius: BorderRadius.circular(10)),
  columnSpacing: 16,
  showCheckboxColumn: false,decoration: BoxDecoration(borderRadius: BorderRadius.circular(10)),dataRowHeight: 40,
  headingRowColor: WidgetStateProperty.all(Colors.white),headingRowHeight: 40,
  columns:  [
    DataColumn(label: Expanded(child: Text('SL NO',    textAlign: TextAlign.center, style: TextStyle(fontWeight: FontWeight.bold)))),
    DataColumn(label: Expanded(child: Text('Period Section', textAlign: TextAlign.center, style: TextStyle(fontWeight: FontWeight.bold)))),
    DataColumn(label: Expanded(child: Text('Created Date',   textAlign: TextAlign.center, style: TextStyle(fontWeight: FontWeight.bold)))),
    DataColumn(label: Expanded(child: Text('Customer',       textAlign: TextAlign.left, style: TextStyle(fontWeight: FontWeight.bold)))),
    DataColumn(label: Expanded(child: Text('VAT Number',     textAlign: TextAlign.center, style: TextStyle(fontWeight: FontWeight.bold)))),
    DataColumn(label: Expanded(child: Text('Amount',         textAlign: TextAlign.center, style: TextStyle(fontWeight: FontWeight.bold)))),
    DataColumn(label: Expanded(child: Text('VAT',            textAlign: TextAlign.center, style: TextStyle(fontWeight: FontWeight.bold))), numeric: true),
    DataColumn(label: Expanded(child: Text('Total',          textAlign: TextAlign.center, style: TextStyle(fontWeight: FontWeight.bold))), numeric: true),
    DataColumn(label: Expanded(child: Text('Action',         textAlign: TextAlign.center, style: TextStyle(fontWeight: FontWeight.bold)))),
  ],
  rows: List.generate(_filteredInvoices.length, (index) {
    final invoice = _filteredInvoices[index];
    return DataRow(
      color: WidgetStateProperty.all(
          index.isEven ? Colors.grey.shade200 : Colors.white),
      onSelectChanged: (_) => Navigator.push(
        context,
        MaterialPageRoute(
          builder: (_) => PurchaseEntryDetailsScreen(                                           invoice: invoice,
                        onDelete: () => _deleteInvoice(invoice.id),
                        onExportPdf: (items) => _exportToPdf(invoice, items),
                        onExportExcel: (items) => _exportToExcel(invoice, items),
                        onEdit: () => Navigator.push(
                          context,
                          MaterialPageRoute(builder: (_) => EditPurchaseEntryScreen(invoiceId: invoice.id)),
                        ),),
        ),
      ),
      // _showInvoiceDetails(invoice),
      cells: [
        DataCell(SizedBox(width: 20, child: Text('${index + 1}', style: const TextStyle(fontWeight: FontWeight.w600)))),
        DataCell(Text(invoice.periodSectionName, style: const TextStyle(fontWeight: FontWeight.w600))),
        DataCell(Text(DateFormat('dd/MM/yyyy').format(invoice.createdAt))),
        DataCell(SizedBox(width: 250, child: Text(invoice.customerName, overflow: TextOverflow.ellipsis, maxLines: 2))),
        DataCell(Text(invoice.customerVatNumber, style: const TextStyle(fontWeight: FontWeight.w600))),
        DataCell(SizedBox(width: 70, child: Align(alignment: Alignment.center, child: Text(invoice.totalAmountExVat.toStringAsFixed(2))))),
        DataCell(Align(alignment: Alignment.centerRight, child: Text(invoice.totalVatAmount.toStringAsFixed(2)))),
        DataCell(SizedBox(width: 80, child: Align(alignment: Alignment.center, child: Text(invoice.totalAmountIncVat.toStringAsFixed(2), style: const TextStyle(fontWeight: FontWeight.bold, color: Colors.purple))))),
        DataCell(PopupMenuButton(
          color: Colors.white,
          itemBuilder: (ctx) => [
            PopupMenuItem(
              onTap: () => 
              Navigator.push(
        context,
        MaterialPageRoute(
          builder: (_) => PurchaseEntryDetailsScreen(                                           invoice: invoice,
                        onDelete: () => _deleteInvoice(invoice.id),
                        onExportPdf: (items) => _exportToPdf(invoice, items),
                        onExportExcel: (items) => _exportToExcel(invoice, items),
                        onEdit: () => Navigator.push(
                          context,
                          MaterialPageRoute(builder: (_) => EditPurchaseEntryScreen(invoiceId: invoice.id)),
                        ),),
        ),
      ),
      // _showInvoiceDetails(invoice),
              child: const Row(children: [Icon(Icons.visibility, size: 20), SizedBox(width: 8), Text('View')]),
            ),
            PopupMenuItem(
              onTap: () => Navigator.push(context, MaterialPageRoute(builder: (context) => EditPurchaseEntryScreen(invoiceId: invoice.id  ))),
              child: Row(children: [Icon(Icons.edit, size: 20, color: Colors.blue[900]), const SizedBox(width: 8), Text('Edit', style: TextStyle(color: Colors.blue[900]))]),
            ),
            PopupMenuItem(
              onTap: () => _exportToPdf(invoice),
              child: const Row(children: [Icon(Icons.picture_as_pdf, size: 20, color: Colors.red), SizedBox(width: 8), Text('Export PDF', style: TextStyle(color: Colors.red))]),
            ),
            PopupMenuItem(
              onTap: () => _deleteInvoice(invoice.id),
              child: const Row(children: [Icon(Icons.delete, size: 20, color: Colors.red), SizedBox(width: 8), Text('Delete', style: TextStyle(color: Colors.red))]),
            ),
          ],
        )),
      ],
    );
  }),
),),
          ),

          // ── Bottom CTA ────────────────────────────────────────────────
          // SafeArea(
          //   child: GestureDetector(
          //     onTap: () => Navigator.push(
          //       context,
          //       MaterialPageRoute(builder: (_) => PurchaseEntryScreen()),
          //     ),
          //     child: Container(
          //       margin: const EdgeInsets.all(10),
          //       padding: const EdgeInsets.symmetric(
          //           vertical: 12, horizontal: 18),
          //       decoration: BoxDecoration(
          //         color: Colors.white,
          //         borderRadius: BorderRadius.circular(30),
          //         boxShadow: [
          //           BoxShadow(
          //             color: Colors.grey.withOpacity(0.9),
          //             blurRadius: 8,
          //             offset: const Offset(0, 0),
          //           ),
          //         ],
          //       ),
          //       child: const Row(
          //         mainAxisAlignment: MainAxisAlignment.center,
          //         children: [
          //           Icon(Icons.add, color: Colors.black),
          //           SizedBox(width: 8),
          //           Text('Create Purchase Entry',
          //               style: TextStyle(
          //                   color: Colors.black,
          //                   fontSize: 15,
          //                   fontWeight: FontWeight.w600)),
          //         ],
          //       ),
          //     ),
          //   ),
          // ),
        ],
      ),
    );
  }

  // ── Filter chip ───────────────────────────────────────────────────────────
  Widget _buildFilterChip(String label, String type) {
    final isActive = _filterType == type;
    return Padding(
      padding: const EdgeInsets.only(right: 8),
      child: GestureDetector(
        onTap: () {
          setState(() {
            _filterType = type;
            if (type != 'custom') {
              _customFrom = null;
              _customTo = null;
            }
          });
          _applyFilters();
        },
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 180),
          padding:
              const EdgeInsets.symmetric(horizontal: 14, vertical: 7),
          decoration: BoxDecoration(
            color: isActive ? Colors.blue.shade700 : Colors.grey.shade200,
            borderRadius: BorderRadius.circular(20),
          ),
          child: Text(
            label,
            style: TextStyle(
              fontSize: 12,
              color: isActive ? Colors.white : Colors.black87,
              fontWeight:
                  isActive ? FontWeight.w600 : FontWeight.normal,
            ),
          ),
        ),
      ),
    );
  }

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }
}



// ── Helper widgets ────────────────────────────────────────────────────────────

class _InfoCard extends StatelessWidget {
  const _InfoCard({required this.title, required this.icon, required this.children});
  final String title;
  final IconData icon;
  final List<Widget> children;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: Colors.grey.shade200),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(children: [
            Icon(icon, size: 16, color: const Color(0xFF4F8EF7)),
            const SizedBox(width: 6),
            Text(title,
                style: TextStyle(
                    fontWeight: FontWeight.w700,
                    fontSize: 13,
                    color: Colors.grey.shade700)),
          ]),
          const SizedBox(height: 12),
          ...children,
        ],
      ),
    );
  }
}

class _InfoTile extends StatelessWidget {
  const _InfoTile({required this.label, required this.value});
  final String label;
  final String value;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 8),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SizedBox(
            width: 120,
            child: Text(label,
                style: TextStyle(
                    fontSize: 13,
                    color: Colors.grey.shade500,
                    fontWeight: FontWeight.w500)),
          ),
          Expanded(
            child: Text(value,
                style: const TextStyle(
                    fontSize: 13, fontWeight: FontWeight.w600)),
          ),
        ],
      ),
    );
  }
}

class _TotalRow extends StatelessWidget {
  const _TotalRow({required this.label, required this.value});
  final String label;
  final String value;

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Text(label,
            style: TextStyle(fontSize: 13, color: Colors.grey.shade600)),
        Text(value,
            style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w600)),
      ],
    );
  }
}

class _ActionBtn extends StatelessWidget {
  const _ActionBtn({required this.label, required this.icon, required this.color, required this.onTap});
  final String label;
  final IconData icon;
  final Color color;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return ElevatedButton.icon(
      onPressed: onTap,
      icon: Icon(icon, size: 18, color: Colors.white),
      label: Text(label),
      style: ElevatedButton.styleFrom(
        backgroundColor: color,
        foregroundColor: Colors.white,
        elevation: 0,
        padding: const EdgeInsets.symmetric(vertical: 13),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(30)),
        textStyle: const TextStyle(fontWeight: FontWeight.w600, fontSize: 14),
      ),
    );
  }
}

class _OutlineBtn extends StatelessWidget {
  const _OutlineBtn({required this.label, required this.icon, required this.color, required this.onTap});
  final String label;
  final IconData icon;
  final Color color;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return OutlinedButton.icon(
      onPressed: onTap,
      icon: Icon(icon, size: 18, color: color),
      label: Text(label),
      style: OutlinedButton.styleFrom(
        foregroundColor: color,
        side: BorderSide(color: color.withOpacity(0.4)),
        padding: const EdgeInsets.symmetric(vertical: 13),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(30)),
        textStyle: const TextStyle(fontWeight: FontWeight.w600, fontSize: 14),
      ),
    );
  }
}








// import 'package:entryon/purchaseEntryScreen.dart';
// import 'package:flutter/material.dart';
// import 'package:intl/intl.dart';
// import 'package:cloud_firestore/cloud_firestore.dart';
// import 'package:lucide_icons_flutter/lucide_icons.dart';
// import 'package:printing/printing.dart';
// import 'package:provider/provider.dart';
// import 'package:font_awesome_flutter/font_awesome_flutter.dart';
// import 'package:flutter/services.dart';
// // PDF packages
// import 'package:pdf/pdf.dart';
// import 'package:pdf/widgets.dart' as pw;
// import 'utils/pdf_download.dart';

// // File handling
// import 'dart:io';
// import 'package:excel/excel.dart' hide Border;
// import 'package:path_provider/path_provider.dart';
// import 'package:open_file/open_file.dart';
// import 'models/purchase_entry_model.dart';

// import 'providers/customer_provider.dart';
// import 'providers/supplier_provider.dart';

// class PurchaseEntriesListScreen extends StatefulWidget {
//   const PurchaseEntriesListScreen({super.key});

//   @override
//   State<PurchaseEntriesListScreen> createState() =>
//       _PurchaseEntriesListScreenState();
// }

// class _PurchaseEntriesListScreenState extends State<PurchaseEntriesListScreen> {
//   final _searchController = TextEditingController();
//   List<PurchaseInvoice> _allInvoices = [];
//   List<PurchaseInvoice> _filteredInvoices = [];
//   bool _isLoading = false;

//   // Period sections
//   List<Map<String, String>> _periods = [];
//   bool _periodsLoading = true;
//   Set<String> _selectedPeriodIds = {}; // empty = all

//   // Filter state
//   String _filterType = 'all';
//   DateTime? _customFrom;
//   DateTime? _customTo;

//   @override
//   void initState() {
//     super.initState();
//     _fetchPeriods();
//     _loadInvoices();
//   }

//   Future<void> _fetchPeriods() async {
//     setState(() => _periodsLoading = true);
//     try {
//       final snap = await FirebaseFirestore.instance
//           .collection('period_sections')
//           .orderBy('sectionNumber')
//           .get();
//       _periods = snap.docs.map((d) {
//         final data = d.data();
//         return {'id': d.id, 'name': (data['name'] ?? '').toString()};
//       }).toList();
//     } catch (e) {
//       print('Error fetching periods: $e');
//       _periods = [];
//     } finally {
//       setState(() => _periodsLoading = false);
//     }
//   }

//   Future<void> _loadInvoices() async {
//     setState(() => _isLoading = true);
//     try {
//       final invoices = await _fetchAllInvoices();
//       setState(() {
//         _allInvoices = invoices;
//         _filteredInvoices = invoices;
//       });
//       if (invoices.isEmpty) _showMsg('No invoices found', Colors.orange);
//     } catch (e) {
//       _showMsg('Error loading invoices: $e', Colors.red);
//     } finally {
//       setState(() => _isLoading = false);
//     }
//   }

//   Future<List<PurchaseInvoice>> _fetchAllInvoices() async {
//     final db = FirebaseFirestore.instance;
//     final snapshot = await db.collection('purchase_invoices').get();

//     List<PurchaseInvoice> invoices = [];
//     for (var doc in snapshot.docs) {
//       try {
//         final itemsSnapshot = await doc.reference.collection('items').get();
//         final items = itemsSnapshot.docs
//             .map((d) => PurchaseItem.fromMap(d.data()))
//             .toList();
//         final invoice = PurchaseInvoice.fromMap(doc.data(), items);
//         invoices.add(
//           PurchaseInvoice(
//             id: doc.id,
//             customerId: invoice.customerId,
//             customerName: invoice.customerName,
//             customerVatNumber: invoice.customerVatNumber,
//             supplierId: invoice.supplierId,
//             supplierName: invoice.supplierName,
//             invoiceNo: invoice.invoiceNo,
//             invoiceDate: invoice.invoiceDate,
//             items: items,
//             createdAt: invoice.createdAt,
//             periodSectionId: invoice.periodSectionId,
//             periodSectionName: invoice.periodSectionName,
//           ),
//         );
//       } catch (e) {
//         print('Error parsing invoice ${doc.id}: $e');
//       }
//     }
//     invoices.sort((a, b) => b.createdAt.compareTo(a.createdAt));
//     return invoices;
//   }

//   void _applyFilters({String? query}) {
//     final q = query ?? _searchController.text;
//     final now = DateTime.now();
//     final today = DateTime(now.year, now.month, now.day);

//     setState(() {
//       _filteredInvoices = _allInvoices.where((inv) {
//         final matchesSearch =
//             q.isEmpty ||
//             inv.customerName.toLowerCase().contains(q.toLowerCase()) ||
//             inv.supplierName.toLowerCase().contains(q.toLowerCase()) ||
//             inv.invoiceNo.contains(q);

//         if (!matchesSearch) return false;

//         final invDate = DateTime(
//           inv.createdAt.year,
//           inv.createdAt.month,
//           inv.createdAt.day,
//         );

//         bool matchesDate = false;
//         switch (_filterType) {
//           case 'today':
//             matchesDate = invDate.isAtSameMomentAs(today);
//             break;
//           case 'week':
//             matchesDate = !invDate.isBefore(
//               today.subtract(const Duration(days: 7)),
//             );
//             break;
//           case 'month':
//             matchesDate = !invDate.isBefore(
//               today.subtract(const Duration(days: 30)),
//             );
//             break;
//           case 'custom':
//             if (_customFrom == null && _customTo == null) {
//               matchesDate = true;
//             } else {
//               final from = _customFrom != null
//                   ? DateTime(
//                       _customFrom!.year,
//                       _customFrom!.month,
//                       _customFrom!.day,
//                     )
//                   : null;
//               final to = _customTo != null
//                   ? DateTime(_customTo!.year, _customTo!.month, _customTo!.day)
//                   : null;
//               final afterFrom = from == null || !invDate.isBefore(from);
//               final beforeTo = to == null || !invDate.isAfter(to);
//               matchesDate = afterFrom && beforeTo;
//             }
//             break;
//           default:
//             matchesDate = true;
//         }

//         if (!matchesDate) return false;

//         if (_selectedPeriodIds.isNotEmpty) {
//           if (!_selectedPeriodIds.contains(inv.periodSectionId)) return false;
//         }
//         return true;
//       }).toList();
//     });
//   }

//   Future<void> _pickDateRange() async {
//     final now = DateTime.now();
//     final picked = await showDateRangePicker(
//       context: context,
//       firstDate: DateTime(2020),
//       lastDate: now,
//       initialDateRange: (_customFrom != null && _customTo != null)
//           ? DateTimeRange(start: _customFrom!, end: _customTo!)
//           : DateTimeRange(
//               start: now.subtract(const Duration(days: 30)),
//               end: now,
//             ),
//     );

//     if (picked != null) {
//       setState(() {
//         _customFrom = picked.start;
//         _customTo = picked.end;
//         _filterType = 'custom';
//       });
//       _applyFilters();
//     }
//   }

//   void _clearDateRange() {
//     setState(() {
//       _customFrom = null;
//       _customTo = null;
//       _filterType = 'all';
//     });
//     _applyFilters();
//   }

//   Future<void> _showPeriodSelectDialog() async {
//     final selectedCopy = Set<String>.from(_selectedPeriodIds);
//     showDialog(
//       context: context,
//       builder: (ctx) => StatefulBuilder(
//         builder: (context, setDialogState) => AlertDialog(
//           title: const Text('Filter by Period Sections'),
//           content: SingleChildScrollView(
//             child: Column(
//               mainAxisSize: MainAxisSize.min,
//               children: [
//                 CheckboxListTile(
//                   value:
//                       selectedCopy.length == _periods.length &&
//                       _periods.isNotEmpty,
//                   onChanged: (val) {
//                     setDialogState(() {
//                       if (val == true) {
//                         selectedCopy.addAll(_periods.map((p) => p['id']!));
//                       } else {
//                         selectedCopy.clear();
//                       }
//                     });
//                   },
//                   title: const Text('All Periods'),
//                 ),
//                 const Divider(),
//                 ..._periods.map((period) {
//                   final id = period['id']!;
//                   final name = period['name']!;
//                   return CheckboxListTile(
//                     value: selectedCopy.contains(id),
//                     onChanged: (val) {
//                       setDialogState(() {
//                         if (val == true)
//                           selectedCopy.add(id);
//                         else
//                           selectedCopy.remove(id);
//                       });
//                     },
//                     title: Text(name),
//                   );
//                 }),
//               ],
//             ),
//           ),
//           actions: [
//             TextButton(
//               onPressed: () => Navigator.pop(ctx),
//               child: const Text('Cancel'),
//             ),
//             ElevatedButton(
//               onPressed: () {
//                 setState(() => _selectedPeriodIds = selectedCopy);
//                 _applyFilters();
//                 Navigator.pop(ctx);
//               },
//               child: const Text('Apply'),
//             ),
//           ],
//         ),
//       ),
//     );
//   }

//   Future<void> _deleteInvoice(String invoiceId) async {
//     final confirm = await showDialog<bool>(
//       context: context,
//       builder: (ctx) => AlertDialog(
//         title: const Text('Delete Invoice'),
//         content: const Text('Are you sure you want to delete this invoice?'),
//         actions: [
//           TextButton(
//             onPressed: () => Navigator.pop(ctx, false),
//             child: const Text('Cancel'),
//           ),
//           TextButton(
//             onPressed: () => Navigator.pop(ctx, true),
//             child: const Text('Delete', style: TextStyle(color: Colors.red)),
//           ),
//         ],
//       ),
//     );
//     if (confirm == true) {
//       try {
//         await FirebaseFirestore.instance
//             .collection('purchase_invoices')
//             .doc(invoiceId)
//             .delete();
//         _showMsg('Invoice deleted', Colors.green);
//         _loadInvoices();
//       } catch (e) {
//         _showMsg('Error deleting: $e', Colors.red);
//       }
//     }
//   }

//   // === PDF Export ===
//   Future<void> _exportToPdf(
//     PurchaseInvoice invoice, [
//     List<PurchaseItem>? filteredItems,
//   ]) async {
//     final itemsToExport = filteredItems ?? invoice.items;
//     try {
//       final customerProvider = context.read<CustomerProvider>();
//       final customer = await customerProvider.getCustomerById(
//         invoice.customerId,
//       );

//       Future<pw.Font> loadFont(String assetPath) async {
//         final fontData = await rootBundle.load(assetPath);
//         return pw.Font.ttf(fontData);
//       }

//       final arabicRegular = await loadFont(
//         'assets/fonts/NotoSansArabic-Regular.ttf',
//       );
//       final arabicBold = arabicRegular;
//       final latinRegular = pw.Font.courier();
//       final latinBold = pw.Font.courierBold();

//       const blue = PdfColor.fromInt(0xFF4F8EF7);
//       const blueLight = PdfColor.fromInt(0xFFF0F4FF);
//       const blueBorder = PdfColor.fromInt(0xFFBDD3FC);
//       const surface = PdfColor.fromInt(0xFFF5F6FA);
//       const cardBorder = PdfColor.fromInt(0xFFE5E7EB);
//       const textPrimary = PdfColor.fromInt(0xFF111827);
//       const textMuted = PdfColor.fromInt(0xFF9CA3AF);
//       const textSecondary = PdfColor.fromInt(0xFF6B7280);

//       final pdf = pw.Document(
//         theme: pw.ThemeData.withFont(
//           base: latinRegular,
//           bold: latinBold,
//           fontFallback: [arabicRegular, arabicBold],
//         ),
//       );

//       pdf.addPage(
//         pw.Page(
//           build: (context) => pw.Column(
//             crossAxisAlignment: pw.CrossAxisAlignment.start,
//             children: [
//               pw.Text(
//                 'Filtered line items',
//                 style: pw.TextStyle(fontWeight: pw.FontWeight.bold),
//               ),
//               pw.SizedBox(height: 8),
//               pw.Table.fromTextArray(
//                 headers: [
//                   'Date',
//                   'Supplier',
//                   'Invoice No',
//                   'Amount',
//                   'VAT',
//                   'Total',
//                 ],
//                 data: itemsToExport.map((item) => [
//                   DateFormat('dd/MM/yyyy').format(item.date),
//                   item.supplierName,
//                   item.invoiceNo,
//                   item.amountExVat.toStringAsFixed(2),
//                   item.vatAmount.toStringAsFixed(2),
//                   item.totalIncVat.toStringAsFixed(2),
//                 ]).toList(),
//               ),
//             ],
//           ),
//         ),
//       );

//       final bytes = await pdf.save();
//       await downloadPdf(bytes, 'invoice_${invoice.invoiceNo}.pdf');
//       if (mounted) _showMsg('PDF exported successfully!', Colors.green);
//     } catch (e) {
//       if (mounted) _showMsg('Error exporting PDF: $e', Colors.red);
//     }
//   }

//   Future<void> _exportToExcel(
//     PurchaseInvoice invoice, [
//     List<PurchaseItem>? filteredItems,
//   ]) async {
//     final itemsToExport = filteredItems ?? invoice.items;
//     try {
//       final customerProvider = context.read<CustomerProvider>();
//       final customer = await customerProvider.getCustomerById(
//         invoice.customerId,
//       );

//       final excel = Excel.createExcel();
//       final sheet = excel['Invoice'];

//       sheet.appendRow(['Purchase Invoice']);
//       sheet.appendRow(['Invoice No', invoice.invoiceNo]);
//       sheet.appendRow(['Customer', customer?.name ?? invoice.customerName]);
//       sheet.appendRow([
//         'Date',
//         DateFormat('dd/MM/yyyy').format(invoice.invoiceDate),
//       ]);
//       sheet.appendRow([]);

//       sheet.appendRow([
//         'SL',
//         'Invoice Date',
//         'Invoice No',
//         'Supplier',
//         'VAT No',
//         'Amount (Excl VAT)',
//         'VAT',
//         'Total (Incl VAT)',
//       ]);

//       for (var i = 0; i < itemsToExport.length; i++) {
//         final it = itemsToExport[i];
//         sheet.appendRow([
//           (i + 1).toString(),
//           DateFormat('dd/MM/yyyy').format(it.date),
//           it.invoiceNo,
//           it.supplierName,
//           it.vatNumber,
//           it.amountExVat.toStringAsFixed(2),
//           it.vatAmount.toStringAsFixed(2),
//           it.totalIncVat.toStringAsFixed(2),
//         ]);
//       }

//       final bytes = excel.encode();
//       if (bytes == null) throw 'Failed to generate Excel';
//       final dir = await getTemporaryDirectory();
//       final file = File('${dir.path}/invoice_${invoice.invoiceNo}.xlsx');
//       await file.writeAsBytes(bytes, flush: true);
//       await OpenFile.open(file.path);
//       if (mounted) _showMsg('Excel exported successfully!', Colors.green);
//     } catch (e) {
//       if (mounted) _showMsg('Error exporting Excel: $e', Colors.red);
//     }
//   }

//   void _showMsg(String msg, Color color) => ScaffoldMessenger.of(
//     context,
//   ).showSnackBar(SnackBar(content: Text(msg), backgroundColor: color));

//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       backgroundColor: Colors.grey.shade50,
//       appBar: AppBar(
//         centerTitle: true,
//         title: const Text('Purchase Entries'),
//         toolbarHeight: 50,
//         backgroundColor: Colors.white,
//         elevation: 0,
//         actions: [
//           GestureDetector(
//             onTap: () => Navigator.push(
//               context,
//               MaterialPageRoute(builder: (_) => PurchaseEntryScreen()),
//             ),
//             child: Container(
//               margin: const EdgeInsets.only(right: 12),
//               padding: const EdgeInsets.symmetric(vertical: 8, horizontal: 18),
//               decoration: BoxDecoration(
//                 color: Colors.white,
//                 borderRadius: BorderRadius.circular(10),
//                 boxShadow: [
//                   BoxShadow(color: Colors.grey.withOpacity(0.2), blurRadius: 8),
//                 ],
//               ),
//               child: const Row(
//                 children: [
//                   Icon(Icons.add, color: Colors.black),
//                   SizedBox(width: 8),
//                   Text(
//                     'Create Purchase Entry',
//                     style: TextStyle(
//                       color: Colors.black,
//                       fontSize: 15,
//                       fontWeight: FontWeight.w600,
//                     ),
//                   ),
//                 ],
//               ),
//             ),
//           ),
//         ],
//       ),
//       body: Column(
//         children: [
//           // Your existing filter chips, search, period dropdown, etc.
//           // (I kept the structure - replace with your full filter UI if needed)
//           Padding(
//             padding: const EdgeInsets.fromLTRB(12, 0, 12, 6),
//             child: Row(
//               mainAxisAlignment: MainAxisAlignment.spaceBetween,
//               children: [
//                 Text(
//                   '${_filteredInvoices.length} invoice${_filteredInvoices.length == 1 ? '' : 's'}',
//                   style: TextStyle(fontSize: 12, color: Colors.grey.shade600),
//                 ),
//                 if (_filteredInvoices.isNotEmpty)
//                   Text(
//                     'Total: ${_filteredInvoices.fold<double>(0, (s, inv) => s + inv.totalAmountIncVat).toStringAsFixed(2)}',
//                     style: TextStyle(
//                       fontSize: 12,
//                       fontWeight: FontWeight.w600,
//                       color: Colors.purple.shade700,
//                     ),
//                   ),
//               ],
//             ),
//           ),

//           Expanded(
//             child: _isLoading
//                 ? const Center(child: CircularProgressIndicator())
//                 : _filteredInvoices.isEmpty
//                 ? Center(
//                     child: Column(
//                       mainAxisSize: MainAxisSize.min,
//                       children: [
//                         Icon(
//                           Icons.receipt_long_outlined,
//                           size: 52,
//                           color: Colors.grey.shade400,
//                         ),
//                         const Text('No invoices found'),
//                       ],
//                     ),
//                   )
//                 : SingleChildScrollView(
//                     padding: const EdgeInsets.symmetric(horizontal: 8),
//                     scrollDirection: Axis.horizontal,
//                     child: DataTable(
//                       border: TableBorder.all(
//                         color: Colors.grey.shade300,
//                         borderRadius: BorderRadius.circular(10),
//                       ),
//                       columnSpacing: 16,
//                       headingRowColor: WidgetStateProperty.all(Colors.white),
//                       columns: const [
//                         DataColumn(
//                           label: Text(
//                             'SL NO',
//                             style: TextStyle(fontWeight: FontWeight.bold),
//                           ),
//                         ),
//                         DataColumn(
//                           label: Text(
//                             'Period Section',
//                             style: TextStyle(fontWeight: FontWeight.bold),
//                           ),
//                         ),
//                         DataColumn(
//                           label: Text(
//                             'Created Date',
//                             style: TextStyle(fontWeight: FontWeight.bold),
//                           ),
//                         ),
//                         DataColumn(
//                           label: Text(
//                             'Customer',
//                             style: TextStyle(fontWeight: FontWeight.bold),
//                           ),
//                         ),
//                         DataColumn(
//                           label: Text(
//                             'VAT Number',
//                             style: TextStyle(fontWeight: FontWeight.bold),
//                           ),
//                         ),
//                         DataColumn(
//                           label: Text(
//                             'Amount',
//                             style: TextStyle(fontWeight: FontWeight.bold),
//                           ),
//                         ),
//                         DataColumn(
//                           label: Text(
//                             'VAT',
//                             style: TextStyle(fontWeight: FontWeight.bold),
//                           ),
//                         ),
//                         DataColumn(
//                           label: Text(
//                             'Total',
//                             style: TextStyle(fontWeight: FontWeight.bold),
//                           ),
//                         ),
//                         DataColumn(
//                           label: Text(
//                             'Action',
//                             style: TextStyle(fontWeight: FontWeight.bold),
//                           ),
//                         ),
//                       ],
//                       rows: List.generate(_filteredInvoices.length, (index) {
//                         final invoice = _filteredInvoices[index];
//                         return DataRow( onSelectChanged: (_) {Navigator.push(
//                                       context,
//                                       MaterialPageRoute(
//                                         builder: (_) => InvoiceDetailsScreen(
//                                           invoice: invoice,
//                         onDelete: () => _deleteInvoice(invoice.id),
//                         onExportPdf: (items) => _exportToPdf(invoice, items),
//                         onExportExcel: (items) => _exportToExcel(invoice, items),
//                         onEdit: () => Navigator.push(
//                           context,
//                           MaterialPageRoute(builder: (_) => PurchaseEntryScreen(invoice: invoice)),
//                         ),
//                                         ),
//                                       ),
//                                     );},


//                           color: WidgetStateProperty.all(
//                             index.isEven ? Colors.grey.shade200 : Colors.white,
//                           ),
//                           cells: [
//                             DataCell(Text('${index + 1}')),
//                             DataCell(Text(invoice.periodSectionName)),
//                             DataCell(
//                               Text(
//                                 DateFormat(
//                                   'dd/MM/yyyy',
//                                 ).format(invoice.createdAt),
//                               ),
//                             ),
//                             DataCell(Text(invoice.customerName)),
//                             DataCell(Text(invoice.customerVatNumber)),
//                             DataCell(
//                               Text(invoice.totalAmountExVat.toStringAsFixed(2)),
//                             ),
//                             DataCell(
//                               Text(invoice.totalVatAmount.toStringAsFixed(2)),
//                             ),
//                             DataCell(
//                               Text(
//                                 invoice.totalAmountIncVat.toStringAsFixed(2),
//                                 style: const TextStyle(
//                                   fontWeight: FontWeight.bold,
//                                   color: Colors.purple,
//                                 ),
//                               ),
//                             ),
//                             DataCell(
//                               PopupMenuButton(
//                                 itemBuilder: (ctx) => [
//                                   PopupMenuItem(
//                                     onTap: () => Navigator.push(
//                                       context,
//                                       MaterialPageRoute(
//                                         builder: (_) => InvoiceDetailsScreen(
//                                           invoice: invoice,
//                         onDelete: () => _deleteInvoice(invoice.id),
//                         onExportPdf: (items) => _exportToPdf(invoice, items),
//                         onExportExcel: (items) => _exportToExcel(invoice, items),
//                         onEdit: () => Navigator.push(
//                           context,
//                           MaterialPageRoute(builder: (_) => PurchaseEntryScreen(invoice: invoice)),
//                         ),
//                                         ),
//                                       ),
//                                     ),
//                                     child: const Row(
//                                       children: [
//                                         Icon(Icons.visibility, size: 20),
//                                         SizedBox(width: 8),
//                                         Text('View'),
//                                       ],
//                                     ),
//                                   ),
//                                   PopupMenuItem(
//                                     onTap: () => Navigator.push(
//                                       context,
//                                       MaterialPageRoute(
//                                         builder: (_) => PurchaseEntryScreen(
//                                           invoice: invoice,
//                                         ),
//                                       ),
//                                     ),
//                                     child: const Row(
//                                       children: [
//                                         Icon(Icons.edit, size: 20),
//                                         SizedBox(width: 8),
//                                         Text('Edit'),
//                                       ],
//                                     ),
//                                   ),
//                                   PopupMenuItem(
//                                     onTap: () => _exportToPdf(invoice),
//                                     child: const Row(
//                                       children: [
//                                         Icon(
//                                           Icons.picture_as_pdf,
//                                           color: Colors.red,
//                                         ),
//                                         SizedBox(width: 8),
//                                         Text(
//                                           'Export PDF',
//                                           style: TextStyle(color: Colors.red),
//                                         ),
//                                       ],
//                                     ),
//                                   ),
//                                   PopupMenuItem(
//                                     onTap: () => _deleteInvoice(invoice.id),
//                                     child: const Row(
//                                       children: [
//                                         Icon(Icons.delete, color: Colors.red),
//                                         SizedBox(width: 8),
//                                         Text(
//                                           'Delete',
//                                           style: TextStyle(color: Colors.red),
//                                         ),
//                                       ],
//                                     ),
//                                   ),
//                                 ],
//                               ),
//                             ),
//                           ],
//                         );
//                       }),
//                     ),
//                   ),
//           ),
//         ],
//       ),
//     );
//   }

//   Widget _buildFilterChip(String label, String type) {
//     final isActive = _filterType == type;
//     return Padding(
//       padding: const EdgeInsets.only(right: 8),
//       child: GestureDetector(
//         onTap: () {
//           setState(() {
//             _filterType = type;
//             if (type != 'custom') {
//               _customFrom = null;
//               _customTo = null;
//             }
//           });
//           _applyFilters();
//         },
//         child: AnimatedContainer(
//           duration: const Duration(milliseconds: 180),
//           padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 7),
//           decoration: BoxDecoration(
//             color: isActive ? Colors.blue.shade700 : Colors.grey.shade200,
//             borderRadius: BorderRadius.circular(20),
//           ),
//           child: Text(
//             label,
//             style: TextStyle(
//               fontSize: 12,
//               color: isActive ? Colors.white : Colors.black87,
//               fontWeight: isActive ? FontWeight.w600 : FontWeight.normal,
//             ),
//           ),
//         ),
//       ),
//     );
//   }

//   @override
//   void dispose() {
//     _searchController.dispose();
//     super.dispose();
//   }
// }

// // ==================== INVOICE DETAILS SCREEN ====================

// class InvoiceDetailsScreen extends StatefulWidget {
//   final PurchaseInvoice invoice;
//   final VoidCallback? onDelete;
//   final void Function(List<PurchaseItem>)? onExportPdf;
//   final void Function(List<PurchaseItem>)? onExportExcel;
//   final VoidCallback? onEdit;

//   const InvoiceDetailsScreen({
//     super.key,
//     required this.invoice,
//     this.onDelete,
//     this.onExportPdf,
//     this.onExportExcel,
//     this.onEdit,
//   });

//   @override
//   State<InvoiceDetailsScreen> createState() => _InvoiceDetailsScreenState();
// }

// class _InvoiceDetailsScreenState extends State<InvoiceDetailsScreen> {
//   DateTime? _itemFilterFrom;
//   DateTime? _itemFilterTo;
//   String _supplierFilter = '';
//   late final TextEditingController _supplierController;
//   late List<PurchaseItem> _filteredInvoiceItems;

//   @override
//   void initState() {
//     super.initState();
//     _supplierController = TextEditingController();
//     _filteredInvoiceItems = List.from(widget.invoice.items);
//   }

//   @override
//   void dispose() {
//     _supplierController.dispose();
//     super.dispose();
//   }

//   void _applyInvoiceItemFilters() {
//     final supplierQuery = _supplierFilter.trim().toLowerCase();
//     if (_itemFilterFrom == null &&
//         _itemFilterTo == null &&
//         supplierQuery.isEmpty) {
//       _filteredInvoiceItems = List.from(widget.invoice.items);
//       return;
//     }

//     _filteredInvoiceItems = widget.invoice.items.where((item) {
//       final matchesSupplier =
//           supplierQuery.isEmpty ||
//           item.supplierName.toLowerCase().contains(supplierQuery);
//       final itemDate = DateTime(item.date.year, item.date.month, item.date.day);
//       final fromDate = _itemFilterFrom != null
//           ? DateTime(
//               _itemFilterFrom!.year,
//               _itemFilterFrom!.month,
//               _itemFilterFrom!.day,
//             )
//           : null;
//       final toDate = _itemFilterTo != null
//           ? DateTime(
//               _itemFilterTo!.year,
//               _itemFilterTo!.month,
//               _itemFilterTo!.day,
//             )
//           : null;

//       final afterFrom = fromDate == null || !itemDate.isBefore(fromDate);
//       final beforeTo = toDate == null || !itemDate.isAfter(toDate);

//       return matchesSupplier && afterFrom && beforeTo;
//     }).toList();
//   }

//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       backgroundColor: const Color(0xFFF5F6FA),
//       // appBar: AppBar(
//       //   title: const Text('Invoice Details'),
//       //   backgroundColor: Colors.white,
//       //   elevation: 0,
//       //   leading: Row(
//       //     children: [_buildFilters(),
//       //       IconButton(
//       //         icon: const Icon(Icons.arrow_back),
//       //         onPressed: () => Navigator.pop(context),
//       //       ),
//       //     ],
//       //   ),
//       // ),
//       body: Padding(
//         padding: const EdgeInsets.all(16),
//         child: Column(
//           crossAxisAlignment: CrossAxisAlignment.start,
//           children: [
//             Row(mainAxisAlignment: MainAxisAlignment.spaceBetween,
//               children: [
//                 Row(
//                   children: [
//                     IconButton(
//                       icon: const Icon(Icons.arrow_back),
//                       onPressed: () => Navigator.pop(context),
//                     ),
//                     const SizedBox(width: 8),
//                     const Text(
//                       'Invoice Details',
//                       style: TextStyle(
//                         fontSize: 20,
//                         fontWeight: FontWeight.bold,
//                       ),
//                     ),
//                   ],
//                 ),
               
//               ],
//             ),
//             SizedBox(height: 8),
//             // Info + Totals Row (same as before)
//             Row(
//               crossAxisAlignment: CrossAxisAlignment.start,
//               children: [
//                 Expanded(
//                   flex: 3,
//                   child: _InfoCard(
//                     title: 'Invoice Info',
//                     icon: Icons.info_outline_rounded,
//                     children: [
//                       Row(
//                         children: [
//                           Expanded(
//                             child: Column(children:[ _InfoTile(
//                               label: 'Customer',
//                               value: widget.invoice.customerName,
//                             ),
//                             if (widget.invoice.customerVatNumber.isNotEmpty)
//                               _InfoTile(
//                                 label: 'VAT Number',
//                                 value: widget.invoice.customerVatNumber,
//                               ),]),
//                           ),
//                                                Expanded(
//                                                  child: Column(children:[ _InfoTile(
//                                                                              label: 'Created Date',
//                                                                              value: DateFormat(
//                                                                                'dd MMM yyyy',
//                                                                              ).format(widget.invoice.createdAt),
//                                                                            ),
//                                                                            if (widget.invoice.periodSectionName.isNotEmpty)
//                                                                              _InfoTile(
//                                                                                label: 'Period Section',
//                                                                                value: widget.invoice.periodSectionName,
//                                                                              ),]),
//                                                ),
//                         ],
//                       )
                     
//                     ],
//                   ),
//                 ),
//                 const SizedBox(width: 12),
//                 Expanded(
//                   flex: 2,
//                   child: Container(
//                     padding: const EdgeInsets.all(16),
//                     decoration: BoxDecoration(
//                       color: Colors.white,
//                       borderRadius: BorderRadius.circular(14),
//                       border: Border.all(color: Colors.grey.shade200),
//                     ),
//                     child:    Column(
//                       children: [
//                         _buildFilters(),SizedBox(height: 12),
//                         Row(
//                                       mainAxisAlignment: MainAxisAlignment.spaceBetween,
//                                       children: [
//                                         Row(
//                                           children: [
//                         SizedBox(
//                           width: 135,
//                           child:InkWell(
//   onTap: () => widget.onExportPdf?.call(_filteredInvoiceItems),
//   borderRadius: BorderRadius.circular(30),
//   child: Container(
//     padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 5),
//     decoration: BoxDecoration(
//       color: Colors.white,
//       borderRadius: BorderRadius.circular(30),
//       border: Border.all(color: Colors.red),
//       boxShadow: [
//         BoxShadow(
//           color: Colors.black.withOpacity(0.05),
//           blurRadius: 4,
//           offset: const Offset(0, 2),
//         ),
//       ],
//     ),
//     child: Row(
//       mainAxisSize: MainAxisSize.min,
//       children: const [
//         FaIcon(
//           FontAwesomeIcons.solidFilePdf,
//           color: Colors.red,
//           size: 18,
//         ),
//         SizedBox(width: 8),
//         Text(
//           'Export PDF',
//           style: TextStyle(
//             color: Colors.red,
//             fontWeight: FontWeight.w600,
//             fontSize: 14,
//           ),
//         ),
//       ],
//     ),
//   ),
// )

//                         ),
//                         const SizedBox(width: 12),
//                         SizedBox(
//                           width: 135,
//                           child:InkWell(
//   onTap: () => widget.onExportExcel?.call(_filteredInvoiceItems),
//   borderRadius: BorderRadius.circular(30),
//   child: Container(
//     padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 5),
//     decoration: BoxDecoration(
//       color: Colors.white,
//       borderRadius: BorderRadius.circular(30),
//       border: Border.all(color: Colors.green.shade700),
//       boxShadow: [
//         BoxShadow(
//           color: Colors.black.withOpacity(0.05),
//           blurRadius: 4,
//           offset: const Offset(0, 2),
//         ),
//       ],
//     ),
//     child: Row(
//       mainAxisSize: MainAxisSize.min,
//       children: [
//         FaIcon(
//           FontAwesomeIcons.solidFileExcel,
//           color: Colors.green.shade700,
//           size: 18,
//         ),
//         const SizedBox(width: 8),
//         Text(
//           'Export Excel',
//           style: TextStyle(
//             color: Colors.green.shade700,
//             fontWeight: FontWeight.w600,
//             fontSize: 14,
//           ),
//         ),
//       ],
//     ),
//   ),
// )
// ,
//                         ),
//                                           ],
//                                         ),
//                                         Row(
//                                           children: [
//                         _OutlineBtn(
//                           label: 'Delete Invoice',
//                           icon: Icons.delete_outline_rounded,
//                           color: Colors.red.shade600,
//                           onTap: widget.onDelete ?? () {},
//                         ),
//                         const SizedBox(width: 10),
//                         _OutlineBtn(
//                           label: 'Edit Invoice',
//                           icon: Icons.edit_outlined,
//                           color: const Color(0xFF4F8EF7),
//                           onTap: widget.onEdit ?? () {},
//                         ),
//                                           ],
//                                         ),
//                                       ],
//                                     ),
//                       ],
//                     ),
//            ),
//                 ),
//               ],
//             ),

//             const SizedBox(height: 16),

//             // Line Items Section
//             Expanded(
//               child: Container(
//                 padding: const EdgeInsets.all(16),
//                 decoration: BoxDecoration(
//                   color: Colors.white,
//                   borderRadius: BorderRadius.circular(14),
//                   border: Border.all(color: Colors.grey.shade200),
//                 ),
//                 child: Column(
//                   crossAxisAlignment: CrossAxisAlignment.start,
//                   children: [
//                     Row(
//                       children: [
//                         const Icon(
//                           Icons.list_alt_outlined,
//                           size: 16,
//                           color: Color(0xFF4F8EF7),
//                         ),
//                         const SizedBox(width: 6),
//                         Text(
//                           'Line Items',
//                           style: TextStyle(
//                             fontWeight: FontWeight.w700,
//                             fontSize: 13,
//                             color: Colors.grey.shade700,
//                           ),
//                         ),
//                         const Spacer(),
//                         // _buildFilters(),
//                         Container(
//                           padding: const EdgeInsets.symmetric(
//                             horizontal: 10,
//                             vertical: 4,
//                           ),
//                           decoration: BoxDecoration(
//                             color: const Color(0xFFF0F1F5),
//                             borderRadius: BorderRadius.circular(20),
//                           ),
//                           child: Text(
//                             '${_filteredInvoiceItems.length} items',
//                             style: const TextStyle(
//                               fontSize: 12,
//                               fontWeight: FontWeight.w600,
//                               color: Color(0xFF4F8EF7),
//                             ),
//                           ),
//                         ),
//                       ],
//                     ),
//                     // const SizedBox(height: 12),
//                     // // Filters (Date + Supplier)
//                     // _buildFilters(),
//                     const SizedBox(height: 12),
//                     Expanded(child: _buildDataTableWithTotals()),
//                   ],
//                 ),
//               ),
//             ),
//             const SizedBox(height: 8),
//       //  Container(height:50,

//       //                          padding: const EdgeInsets.all(16),
//       //                          decoration: BoxDecoration(
//       //                            color: Colors.white,
//       //                            borderRadius: BorderRadius.circular(14),
//       //                            border: Border.all(color: Colors.grey.shade200),
//       //                          ),
//       //                          child: 
                               
                               
//       //                          Row(mainAxisAlignment: MainAxisAlignment.end,
//       //                            crossAxisAlignment: CrossAxisAlignment.start,
//       //                            children: [
//       //                              Row(
//       //                                children: [
//       //                                  const Icon(
//       //                                    Icons.calculate_outlined,
//       //                                    size: 16,
//       //                                    color: Color(0xFF4F8EF7),
//       //                                  ),
//       //                                  const SizedBox(width: 6),
//       //                                  Text(
//       //                                    'Totals',
//       //                                    style: TextStyle(
//       //                                      fontWeight: FontWeight.w700,
//       //                                      fontSize: 13,
//       //                                      color: Colors.grey.shade700,
//       //                                    ),
//       //                                  ),
//       //                                ],
//       //                              ),
//       //                              const SizedBox(height: 12),
//       //                             Row(
//       //                                mainAxisAlignment: MainAxisAlignment.spaceBetween,
//       //                                children: [
//       //                                  const Text(
//       //                                    'Excl VAT : ',
//       //                                    style: TextStyle(
//       //                                      fontWeight: FontWeight.w700,
//       //                                      fontSize: 14,
//       //                                      color: Colors.black,
//       //                                    ),
//       //                                  ),
//       //                                  Text(
//       //                                    widget.invoice.totalAmountExVat
//       //                                        .toStringAsFixed(2),
//       //                                    style: const TextStyle(
//       //                                      fontWeight: FontWeight.w800,
//       //                                      fontSize: 16,
//       //                                      color: Colors.black,
//       //                                    ),
//       //                                  ),
//       //                                ],
//       //                              ),
//       //                              SizedBox(width: 12),
//       //                              const Divider(height: 16),
//       //                            Row(
//       //                                mainAxisAlignment: MainAxisAlignment.spaceBetween,
//       //                                children: [
//       //                                  const Text(
//       //                                    '',
//       //                                    style: TextStyle(
//       //                                      fontWeight: FontWeight.w700,
//       //                                      fontSize: 14,
//       //                                      color: Colors.black,
//       //                                    ),
//       //                                  ),
//       //                                  Text(
//       //                                    widget.invoice.totalVatAmount
//       //                                        .toStringAsFixed(2),
//       //                                    style: const TextStyle(
//       //                                      fontWeight: FontWeight.w800,
//       //                                      fontSize: 16,
//       //                                      color: Colors.black,
//       //                                    ),
//       //                                  ),
//       //                                ],
//       //                              ),
//       //                              SizedBox(width: 12),
//       //                              const Divider(height: 16),
//       //                              Row(
//       //                                mainAxisAlignment: MainAxisAlignment.spaceBetween,
//       //                                children: [
//       //                                  const Text(
//       //                                    ' ',
//       //                                    style: TextStyle(
//       //                                      fontWeight: FontWeight.w700,
//       //                                      fontSize: 14,
//       //                                      color: Color(0xFF4F8EF7),
//       //                                    ),
//       //                                  ),
//       //                                  Text(
//       //                                    widget.invoice.totalAmountIncVat
//       //                                        .toStringAsFixed(2),
//       //                                    style: const TextStyle(
//       //                                      fontWeight: FontWeight.w800,
//       //                                      fontSize: 16,
//       //                                      color: Color(0xFF4F8EF7),
//       //                                    ),
//       //                                  ),
//       //                                ],
//       //                              ),
//       //                            ],
//       //                          ),
                            
//       //                        ),
      
//             // Action Buttons
//          ],
//         ),
//       ),
//     );
//   }

//   Widget _buildFilters() {
//     return Row(mainAxisAlignment: MainAxisAlignment.end,
//       crossAxisAlignment: CrossAxisAlignment.center,
//       children: [
//         // Row(
//         //   children: [
//         //     // const Icon(
//         //     //   Icons.filter_alt_outlined,
//         //     //   size: 16,
//         //     //   color: Color(0xFF4F8EF7),
//         //     // ),
//         //     // const SizedBox(width: 6),
//         //     // const Text(
//         //     //   'Invoice date & supplier filter',
//         //     //   style: TextStyle(
//         //     //     fontWeight: FontWeight.w700,
//         //     //     fontSize: 13,
//         //     //     color: Color(0xFF4F8EF7),
//         //     //   ),
//         //     // ),
//         //     // const Spacer(),
//         //     if (_itemFilterFrom != null ||
//         //         _itemFilterTo != null ||
//         //         _supplierFilter.isNotEmpty)
//         //       TextButton(
//         //         onPressed: () {
//         //           setState(() {
//         //             _itemFilterFrom = null;
//         //             _itemFilterTo = null;
//         //             _supplierFilter = '';
//         //             _supplierController.clear();
//         //             _applyInvoiceItemFilters();
//         //           });
//         //         },
//         //         child: const Text('Clear'),
//         //       ),
//         //   ],
//         // ),
        
//         SizedBox(
//           width: 150,height: 35,
//           child: DateField(
//             label: 'From date',
//             selectedDate: _itemFilterFrom,
//             onTap: () async {
//               final picked = await showDatePicker(
//                 context: context,
//                 initialDate: _itemFilterFrom ?? DateTime.now(),
//                 firstDate: DateTime(2020),
//                 lastDate: DateTime.now(),
//               );
//               if (picked != null) {
//                 setState(() {
//                   _itemFilterFrom = picked;
//                   _applyInvoiceItemFilters();
//                 });
//               }
//             },
//           ),
//         ),
//         const SizedBox(width: 8),
//         SizedBox(
//           width: 150,height: 35,
//           child: DateField(
//             label: 'To date',
//             selectedDate: _itemFilterTo,
//             onTap: () async {
//               final picked = await showDatePicker(
//                 context: context,
//                 initialDate: _itemFilterTo ?? DateTime.now(),
//                 firstDate: DateTime(2020),
//                 lastDate: DateTime.now(),
//               );
//               if (picked != null) {
//                 setState(() {
//                   _itemFilterTo = picked;
//                   _applyInvoiceItemFilters();
//                 });
//               }
//             },
//           ),
//         ),
//         const SizedBox(width: 8),
//         Spacer(),
//         SizedBox(
//           width: 250,
//           height: 35,
//           child: TextField(
//             controller: _supplierController,
//             decoration: InputDecoration(
//               hintText: 'Search supplier name',
//               prefixIcon: const Icon(Icons.search, size: 18),
//               border: OutlineInputBorder(
//                 borderRadius: BorderRadius.circular(10),
//               ),
//               isDense: true,
//             ),
//             onChanged: (value) {
//               setState(() {
//                 _supplierFilter = value;
//                 _applyInvoiceItemFilters();
//               });
//             },
//           ),
//         ),
     
//       Container(height: 35, decoration: BoxDecoration(
//         color: Colors.grey.shade200,
//         borderRadius: BorderRadius.circular(10),border: Border.all(color: Colors.grey.shade300),
//       ),

//         margin: const EdgeInsets.only(left: 8),
//         child: TextButton(
//           onPressed: () {
//             setState(() {
//               _itemFilterFrom = null;
//               _itemFilterTo = null;
//               _supplierFilter = '';
//               _supplierController.clear();
//               _applyInvoiceItemFilters();
//             });
//           },
//           child: const Text('Clear', style: TextStyle(color: Colors.black87, fontWeight: FontWeight.w600)),
//         ),
//       ),
//       ],
//     );
//   }
// Widget _buildDataTableWithTotals() {
//   final totalExcl = _filteredInvoiceItems.fold<double>(
//       0, (sum, item) => sum + item.amountExVat);
//   final totalVat = _filteredInvoiceItems.fold<double>(
//       0, (sum, item) => sum + item.vatAmount);
//   final totalInc = _filteredInvoiceItems.fold<double>(
//       0, (sum, item) => sum + item.totalIncVat);

//   return Column(mainAxisAlignment: MainAxisAlignment.spaceBetween,
//     children: [
//       Expanded(
//         child: Row(crossAxisAlignment: CrossAxisAlignment.start,
//           children: [
//             Expanded(
//               child: SingleChildScrollView(
//                 scrollDirection: Axis.vertical,
//                 child: _buildDataTable(),
//               ),
//             ),
//           ],
//         ),
//       ),

//       // FIXED TOTAL ROW
//       Container(
//         height: 42,
//         decoration: BoxDecoration(
//           color: const Color(0xFFF5F6FA),
//           border: Border.all(color: Colors.grey.shade300),
//           borderRadius:BorderRadius.only(bottomLeft: Radius.circular(10),bottomRight: Radius.circular(10))
//         ),
//         child: Row(
//           children: [
//             _cell('Total', flex: 3, bold: true),
//             _cell('', flex: 6),
//             _cell('', flex: 6),
//             _cell('', flex: 6),
//             _cell('', flex: 6),
//             _cell('', flex: 10),
//             _cell(totalExcl.toStringAsFixed(2), flex: 3,bold: true),
//             //  SizedBox(width: 8),
//             _cell(totalVat.toStringAsFixed(2), flex: 2,bold: true),
         
//             _cell(
//               totalInc.toStringAsFixed(2),
//               flex: 3,
//               bold: true,
//               color: const Color(0xFF4F8EF7),
//             ),
            
//           ],
//         ),
//       ),
//     ],
//   );
// }

// Widget _cell(String text,
//     {int flex = 1, bool bold = false, Color? color}) {
//   return Expanded(
//     flex: flex,
//     child: Padding(
//       padding: const EdgeInsets.symmetric(horizontal: 8),
//       child: Text(
//         text,
//         style: TextStyle(
//           fontWeight: bold ? FontWeight.bold : FontWeight.normal,
//           fontSize: 13,
//           color: color,
//         ),
//       ),
//     ),
//   );
// }

//   Widget _buildDataTable() {
//     return DataTable(
//       dataRowHeight: 42,
//       headingRowHeight: 42,
//       columnSpacing: 12,
//       border: TableBorder.all(
//         color: Colors.grey.shade200,
//         borderRadius: BorderRadius.circular(10),
//       ),
//       headingRowColor: WidgetStateProperty.all(const Color(0xFFF5F6FA)),
//       columns: const [
//         DataColumn(
//           label: Text(
//             'SL No.',
//             style: TextStyle(fontWeight: FontWeight.w700, fontSize: 13),
//           ),
//         ),
//         DataColumn(
//           label: Text(
//             'Created Date',
//             style: TextStyle(fontWeight: FontWeight.w700, fontSize: 13),
//           ),
//         ),
//         DataColumn(
//           label: Text(
//             'Invoice Date',
//             style: TextStyle(fontWeight: FontWeight.w700, fontSize: 13),
//           ),
//         ),
//         DataColumn(
//           label: Text(
//             'Supplier',
//             style: TextStyle(fontWeight: FontWeight.w700, fontSize: 13),
//           ),
//         ),
//         DataColumn(
//           label: Text(
//             'VAT No',
//             style: TextStyle(fontWeight: FontWeight.w700, fontSize: 13),
//           ),
//         ),
//         DataColumn(
//           label: Text(
//             'Invoice No',
//             style: TextStyle(fontWeight: FontWeight.w700, fontSize: 13),
//           ),
//         ),
//         DataColumn(
//           label: Text(
//             'Excl. Amount',
//             style: TextStyle(fontWeight: FontWeight.w700, fontSize: 13),
//           ),
//         ),
//         DataColumn(
//           label: Text(
//             'VAT',
//             style: TextStyle(fontWeight: FontWeight.w700, fontSize: 13),
//           ),
//         ),
//         DataColumn(
//           label: Text(
//             'Total',
//             style: TextStyle(fontWeight: FontWeight.w700, fontSize: 13),
//           ),
//         ),
//       ],
//       rows: List.generate(_filteredInvoiceItems.length, (i) {
//         final item = _filteredInvoiceItems[i];
//         return DataRow(
//           color: WidgetStateProperty.all(
//             i.isEven ? const Color(0xFFF9FAFB) : Colors.white,
//           ),
//           cells: [
//             DataCell(Text('${i + 1}')),
//             DataCell(
//               Text(DateFormat('dd/MM/yyyy HH:mm:ss').format(item.createdAt)),
//             ),
//             DataCell(Text(DateFormat('dd/MM/yyyy').format(item.date))),
//             DataCell(
//               Text(
//                 item.supplierName,
//                 overflow: TextOverflow.ellipsis,
//                 maxLines: 2,
//               ),
//             ),
//             DataCell(Text(item.vatNumber)),
//             DataCell(Text(item.invoiceNo)),
//             DataCell(Text(item.amountExVat.toStringAsFixed(2))),
//             DataCell(Text(item.vatAmount.toStringAsFixed(2))),
//             DataCell(
//               Text(
//                 item.totalIncVat.toStringAsFixed(2),
//                 style: const TextStyle(
//                   fontWeight: FontWeight.bold,
//                   color: Color(0xFF4F8EF7),
//                 ),
//               ),
//             ),
//           ],
//         );
//       }),
//     );
//   }
// } // ── Helper widgets ────────────────────────────────────────────────────────────

// class _InfoCard extends StatelessWidget {
//   const _InfoCard({
//     required this.title,
//     required this.icon,
//     required this.children,
//   });
//   final String title;
//   final IconData icon;
//   final List<Widget> children;

//   @override
//   Widget build(BuildContext context) {
//     return Container(
//       padding: const EdgeInsets.all(16),
//       decoration: BoxDecoration(
//         color: Colors.white,
//         borderRadius: BorderRadius.circular(14),
//         border: Border.all(color: Colors.grey.shade200),
//       ),
//       child: Column(
//         crossAxisAlignment: CrossAxisAlignment.start,
//         children: [
//           Row(
//             children: [
//               Icon(icon, size: 16, color: const Color(0xFF4F8EF7)),
//               const SizedBox(width: 6),
//               Text(
//                 title,
//                 style: TextStyle(
//                   fontWeight: FontWeight.w700,
//                   fontSize: 13,
//                   color: Colors.grey.shade700,
//                 ),
//               ),
//             ],
//           ),
//           const SizedBox(height: 12),
//           ...children,
//         ],
//       ),
//     );
//   }
// }

// class _InfoTile extends StatelessWidget {
//   const _InfoTile({required this.label, required this.value});
//   final String label;
//   final String value;

//   @override
//   Widget build(BuildContext context) {
//     return Padding(
//       padding: const EdgeInsets.only(bottom: 8),
//       child: Row(
//         crossAxisAlignment: CrossAxisAlignment.start,
//         children: [
//           SizedBox(
//             width: 120,
//             child: Text(
//               label,
//               style: TextStyle(
//                 fontSize: 13,
//                 color: Colors.grey.shade500,
//                 fontWeight: FontWeight.w500,
//               ),
//             ),
//           ),
//           Expanded(
//             child: Text(
//               value,
//               style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w600),
//             ),
//           ),
//         ],
//       ),
//     );
//   }
// }

// class _TotalRow extends StatelessWidget {
//   const _TotalRow({required this.label, required this.value});
//   final String label;
//   final String value;

//   @override
//   Widget build(BuildContext context) {
//     return Row(
//       mainAxisAlignment: MainAxisAlignment.spaceBetween,
//       children: [
//         Text(
//           label,
//           style: TextStyle(fontSize: 13, color: Colors.grey.shade600),
//         ),
//         Text(
//           value,
//           style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w600),
//         ),
//       ],
//     );
//   }
// }

// class _ActionBtn extends StatelessWidget {
//   const _ActionBtn({
//     required this.label,
//     required this.icon,
//     required this.color,
//     required this.onTap,
//   });
//   final String label;
//   final IconData icon;
//   final Color color;
//   final VoidCallback onTap;

//   @override
//   Widget build(BuildContext context) {
//     return ElevatedButton.icon(
//       onPressed: onTap,
//       icon: Icon(icon, size: 18, color: Colors.white),
//       label: Text(label),
//       style: ElevatedButton.styleFrom(
//         backgroundColor: color,
//         foregroundColor: Colors.white,
//         elevation: 0,
//         padding: const EdgeInsets.symmetric(vertical: 13),
//         shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(30)),
//         textStyle: const TextStyle(fontWeight: FontWeight.w600, fontSize: 14),
//       ),
//     );
//   }
// }

// class _OutlineBtn extends StatelessWidget {
//   const _OutlineBtn({
//     required this.label,
//     required this.icon,
//     required this.color,
//     required this.onTap,
//   });
//   final String label;
//   final IconData icon;
//   final Color color;
//   final VoidCallback onTap;

//   @override
//   Widget build(BuildContext context) {
//     return OutlinedButton.icon(
//       onPressed: onTap,
//       icon: Icon(icon, size: 18, color: color),
//       label: Text(label),
//       style: OutlinedButton.styleFrom(
//         foregroundColor: color,
//         side: BorderSide(color: color.withOpacity(0.4)),
//         padding: const EdgeInsets.symmetric(vertical: 13,horizontal: 10),
//         shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(30)),
//         textStyle: const TextStyle(fontWeight: FontWeight.w600, fontSize: 14),
//       ),
//     );
//   }
// }

// class DateField extends StatelessWidget {
//   final String label;
//   final DateTime? selectedDate;
//   final VoidCallback onTap;

//   const DateField({
//     super.key,
//     required this.label,
//     required this.selectedDate,
//     required this.onTap,
//   });

//   @override
//   Widget build(BuildContext context) {
//     return InkWell(
//       onTap: onTap,
//       child: Container(
//         padding: const EdgeInsets.symmetric(horizontal: 12, ),
//         decoration: BoxDecoration(
//           color: Colors.white,
//           borderRadius: BorderRadius.circular(8),
//           border: Border.all(color: Colors.grey.shade300),
//         ),
//         child: Center(
//           child: Row(
//             mainAxisAlignment: MainAxisAlignment.spaceBetween,
//             children: [
//               Text(
//                 selectedDate != null
//                     ? "${selectedDate!.day.toString().padLeft(2, '0')}-"
//                           "${selectedDate!.month.toString().padLeft(2, '0')}-"
//                           "${selectedDate!.year}"
//                     : label,
//                 style: TextStyle(
//                   fontSize: 15,
//                   color: selectedDate != null ? Colors.black : Colors.grey,
//                 ),
//               ),
//               const Icon(Icons.calendar_today, size: 18, color: Colors.grey),
//             ],
//           ),
//         ),
//       ),
//     );
//   }
// }


