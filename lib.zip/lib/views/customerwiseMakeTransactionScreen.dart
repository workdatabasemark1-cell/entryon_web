import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../models/customer_model.dart';
import '../models/service_model.dart';
import '../models/transaction_model.dart';
import '../providers/service_entry_provider.dart';
import '../providers/transaction_provider.dart';

class CustomerwiseMakeTransactionScreen extends StatefulWidget {
  final Customer customer;

  const CustomerwiseMakeTransactionScreen({super.key, required this.customer});

  @override
  State<CustomerwiseMakeTransactionScreen> createState() =>
      _CustomerwiseMakeTransactionScreenState();
}

class _CustomerwiseMakeTransactionScreenState
    extends State<CustomerwiseMakeTransactionScreen> {
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      context.read<ServiceEntryProvider>().fetchServices();
      context.read<TransactionProvider>().fetchTransactions();
    });
  }

  Future<void> _showPaymentDialog(BuildContext context, ServiceEntry service) async {
    final amountController =
        TextEditingController(text: service.balanceAmount.toStringAsFixed(2));
    String paymentType = 'Cash';
    final cardNumberController = TextEditingController();
    final formKey = GlobalKey<FormState>();

    final result = await showDialog<bool>(
      context: context,
      builder: (dialogContext) {
        return StatefulBuilder(
          builder: (context, setDialogState) {
            return AlertDialog(
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
              title: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    'Record Payment',
                    style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    service.title,
                    style: TextStyle(
                      fontSize: 14,
                      color: Colors.grey.shade600,
                      fontWeight: FontWeight.w400,
                    ),
                  ),
                ],
              ),
              content: Form(
                key: formKey,
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    // Balance highlight
                    Container(
                      width: double.infinity,
                      padding: const EdgeInsets.all(12),
                      decoration: BoxDecoration(
                        color: Colors.orange.shade50,
                        borderRadius: BorderRadius.circular(10),
                        border: Border.all(color: Colors.orange.shade200),
                      ),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text('Outstanding Balance',
                              style: TextStyle(color: Colors.grey.shade700)),
                          Text(
                            service.balanceAmount.toStringAsFixed(2),
                            style: const TextStyle(
                              fontWeight: FontWeight.bold,
                              color: Colors.orange,
                              fontSize: 16,
                            ),
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(height: 16),

                    TextFormField(
                      controller: amountController,
                      keyboardType: const TextInputType.numberWithOptions(decimal: true),
                      decoration: _dialogInputDecoration('Amount to Pay'),
                      validator: (v) {
                        final val = double.tryParse(v ?? '0') ?? 0;
                        if (val <= 0) return 'Enter a valid amount';
                        if (val > service.balanceAmount) return 'Cannot exceed balance';
                        return null;
                      },
                    ),
                    const SizedBox(height: 14),

                    DropdownButtonFormField<String>(
                      value: paymentType,
                      decoration: _dialogInputDecoration('Payment Type'),
                      items: const [
                        DropdownMenuItem(value: 'Cash', child: Text('Cash')),
                        DropdownMenuItem(value: 'Card', child: Text('Card')),
                      ],
                      onChanged: (v) {
                        setDialogState(() => paymentType = v ?? 'Cash');
                      },
                    ),

                    if (paymentType == 'Card') ...[
                      const SizedBox(height: 14),
                      TextFormField(
                        controller: cardNumberController,
                        keyboardType: TextInputType.number,
                        decoration: _dialogInputDecoration('Card Number'),
                        validator: (v) {
                          if (paymentType == 'Card' &&
                              (v == null || v.trim().isEmpty)) {
                            return 'Enter card number';
                          }
                          return null;
                        },
                      ),
                    ],
                  ],
                ),
              ),
              actionsPadding: const EdgeInsets.fromLTRB(16, 0, 16, 16),
              actions: [
                TextButton(
                  onPressed: () => Navigator.pop(dialogContext, false),
                  child: Text('Cancel', style: TextStyle(color: Colors.grey.shade600)),
                ),
                ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.teal,
                    foregroundColor: Colors.white,
                    elevation: 0,
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(10)),
                    padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
                  ),
                  onPressed: () async {
                    if (!formKey.currentState!.validate()) return;

                    final amt = double.tryParse(amountController.text.trim()) ?? 0;
                    final balanceAfterPayment = service.balanceAmount - amt;

                    final txn = TransactionModel(
                      id: DateTime.now().millisecondsSinceEpoch.toString(),
                      serviceId: service.id,
                      customerId: service.customerId,
                      customerName: service.customerName,
                      amount: amt,
                      balanceAmount: balanceAfterPayment,
                      paymentType: paymentType,
                      paymentDetails: {
                        if (paymentType == 'Card')
                          'cardNumber': cardNumberController.text.trim(),
                        'balanceAmount': balanceAfterPayment,
                      },
                      createdAt: DateTime.now(),
                    );

                    final ok =
                        await context.read<TransactionProvider>().addTransaction(txn);

                    if (ok) {
                      final newPaid = service.customerPaidAmount + amt;
                      final newStatus =
                          newPaid >= service.amount ? 'Paid' : 'Partial';

                      await context.read<ServiceEntryProvider>().updateService(
                    paymentType: newStatus,
                    id: service.id,
                    title: service.title,
                    customerName: service.customerName,
                    customerId: service.customerId,
                    description: service.description,
                    serviceDate: service.serviceDate,
                    amount: service.amount,
                    serviceFee: service.serviceFee,
                    customerPaidAmount: newPaid,
                    paymentStatus: newStatus,
                    serviceStatus: service.serviceStatus,
                    paymentExpiryDate: service.paymentExpiryDate,
                    purchaseLines: service.purchaseLines,
                  );

                      if (dialogContext.mounted) {
                        Navigator.pop(dialogContext, true);
                      }
                    } else {
                      if (dialogContext.mounted) {
                        Navigator.pop(dialogContext, false);
                      }
                    }
                  },
                  child: const Text('Confirm Payment'),
                ),
              ],
            );
          },
        );
      },
    );

    if (result == true && mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Payment recorded successfully'),
          backgroundColor: Colors.green,
          behavior: SnackBarBehavior.floating,
        ),
      );
      await context.read<ServiceEntryProvider>().fetchServices();
      await context.read<TransactionProvider>().fetchTransactions();
    }
  }

  InputDecoration _dialogInputDecoration(String label) {
    return InputDecoration(
      labelText: label,
      filled: true,
      fillColor: Colors.grey.shade50,
      isDense: true,
      contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 14),
      border: OutlineInputBorder(
        borderRadius: BorderRadius.circular(10),
        borderSide: BorderSide(color: Colors.grey.shade300),
      ),
      enabledBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(10),
        borderSide: BorderSide(color: Colors.grey.shade300),
      ),
      focusedBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(10),
        borderSide: const BorderSide(color: Colors.teal, width: 1.5),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final services = context.watch<ServiceEntryProvider>().services;
    final isLoading = context.watch<ServiceEntryProvider>().isLoading;

    final pending = services.where((service) {
      final matchesCustomer = service.customerId != null
          ? service.customerId == widget.customer.id
          : service.customerName.toLowerCase() ==
              widget.customer.name.toLowerCase();

      return matchesCustomer &&
          service.paymentStatus.toLowerCase() != 'paid' &&
          (service.amount - service.customerPaidAmount) > 0;
    }).toList();

    // Total outstanding for this customer
    final totalOutstanding = pending.fold<double>(
      0,
      (sum, s) => sum + (s.amount - s.customerPaidAmount),
    );

    return Scaffold(
      backgroundColor: Colors.grey.shade100,
      appBar: AppBar(
        title: Text(
          widget.customer.name,
          style: const TextStyle(fontWeight: FontWeight.w600),
        ),
        backgroundColor: Colors.white,
        elevation: 0,
        scrolledUnderElevation: 0,
        centerTitle: true,
      ),
      body: isLoading && services.isEmpty
          ? const Center(child: CircularProgressIndicator(color: Colors.teal))
          : Column(
              children: [
                // Customer summary header
                if (pending.isNotEmpty)
                  Container(
                    width: double.infinity,
                    margin: const EdgeInsets.fromLTRB(14, 14, 14, 0),
                    padding: const EdgeInsets.all(16),
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(14),
                      boxShadow: [
                        BoxShadow(
                          color: Colors.black.withOpacity(0.04),
                          blurRadius: 8,
                          offset: const Offset(0, 3),
                        ),
                      ],
                    ),
                    child: Row(
                      children: [
                        Container(
                          width: 48,
                          height: 48,
                          decoration: BoxDecoration(
                            color: Colors.teal.shade50,
                            borderRadius: BorderRadius.circular(12),
                          ),
                          child: const Icon(Icons.person_outline,
                              color: Colors.teal, size: 26),
                        ),
                        const SizedBox(width: 14),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                '${pending.length} pending service${pending.length > 1 ? 's' : ''}',
                                style: TextStyle(
                                  fontSize: 13,
                                  color: Colors.grey.shade600,
                                ),
                              ),
                              const SizedBox(height: 2),
                              Text(
                                'Total Due: ${totalOutstanding.toStringAsFixed(2)}',
                                style: const TextStyle(
                                  fontSize: 16,
                                  fontWeight: FontWeight.bold,
                                  color: Colors.orange,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),

                // List
                Expanded(
                  child: pending.isEmpty
                      ? _EmptyState(customerName: widget.customer.name)
                      : ListView.builder(
                          padding: const EdgeInsets.all(14),
                          itemCount: pending.length,
                          itemBuilder: (context, index) {
                            final service = pending[index];
                            final balance =
                                service.amount - service.customerPaidAmount;
                            final paidPercent = service.amount > 0
                                ? (service.customerPaidAmount / service.amount)
                                    .clamp(0.0, 1.0)
                                : 0.0;

                            return Container(
                              margin: const EdgeInsets.only(bottom: 14),
                              decoration: BoxDecoration(
                                color: Colors.white,
                                borderRadius: BorderRadius.circular(16),
                                boxShadow: [
                                  BoxShadow(
                                    color: Colors.black.withOpacity(0.04),
                                    blurRadius: 8,
                                    offset: const Offset(0, 3),
                                  ),
                                ],
                              ),
                              child: Padding(
                                padding: const EdgeInsets.all(16),
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    // Title + Status
                                    Row(
                                      children: [
                                        Expanded(
                                          child: Text(
                                            service.title,
                                            style: const TextStyle(
                                              fontSize: 16,
                                              fontWeight: FontWeight.bold,
                                            ),
                                          ),
                                        ),
                                        _StatusChip(label: service.paymentStatus),
                                      ],
                                    ),
                                    const SizedBox(height: 14),

                                    // Amount boxes
                                    Row(
                                      children: [
                                        _AmountBox(
                                            label: 'Total', value: service.amount),
                                        const SizedBox(width: 8),
                                        _AmountBox(
                                          label: 'Paid',
                                          value: service.customerPaidAmount,
                                          color: Colors.green,
                                        ),
                                        const SizedBox(width: 8),
                                        _AmountBox(
                                          label: 'Balance',
                                          value: balance,
                                          color: Colors.orange,
                                        ),
                                      ],
                                    ),

                                    const SizedBox(height: 12),

                                    // Progress
                                    ClipRRect(
                                      borderRadius: BorderRadius.circular(4),
                                      child: LinearProgressIndicator(
                                        value: paidPercent,
                                        minHeight: 6,
                                        backgroundColor: Colors.grey.shade200,
                                        color: paidPercent >= 1
                                            ? Colors.green
                                            : Colors.teal,
                                      ),
                                    ),
                                    const SizedBox(height: 4),
                                    Text(
                                      '${(paidPercent * 100).toStringAsFixed(0)}% paid',
                                      style: TextStyle(
                                        fontSize: 11,
                                        color: Colors.grey.shade500,
                                      ),
                                    ),

                                    const SizedBox(height: 14),

                                    // Pay button
                                    SizedBox(
                                      width: double.infinity,
                                      height: 42,
                                      child: ElevatedButton.icon(
                                        onPressed: () =>
                                            _showPaymentDialog(context, service),
                                        icon: const Icon(Icons.payment_outlined,
                                            size: 18),
                                        label: const Text(
                                          'Pay Now',
                                          style: TextStyle(fontWeight: FontWeight.w600),
                                        ),
                                        style: ElevatedButton.styleFrom(
                                          backgroundColor: Colors.teal,
                                          foregroundColor: Colors.white,
                                          elevation: 0,
                                          shape: RoundedRectangleBorder(
                                            borderRadius: BorderRadius.circular(10),
                                          ),
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            );
                          },
                        ),
                ),
              ],
            ),
    );
  }
}

// ── Helper Widgets ────────────────────────────────────────────────────────

class _EmptyState extends StatelessWidget {
  final String customerName;
  const _EmptyState({required this.customerName});

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(Icons.check_circle_outline, size: 70, color: Colors.green.shade300),
          const SizedBox(height: 16),
          Text(
            'All payments are up to date',
            style: TextStyle(
              fontSize: 16,
              color: Colors.grey.shade600,
              fontWeight: FontWeight.w500,
            ),
          ),
          const SizedBox(height: 6),
          Text(
            'No pending balances for $customerName',
            style: TextStyle(fontSize: 13, color: Colors.grey.shade500),
            textAlign: TextAlign.center,
          ),
        ],
      ),
    );
  }
}

class _StatusChip extends StatelessWidget {
  final String label;
  const _StatusChip({required this.label});

  Color get _color {
    switch (label.toLowerCase()) {
      case 'paid':
        return Colors.green;
      case 'partial':
        return Colors.orange;
      default:
        return Colors.redAccent;
    }
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
      decoration: BoxDecoration(
        color: _color.withOpacity(0.12),
        borderRadius: BorderRadius.circular(20),
      ),
      child: Text(
        label,
        style: TextStyle(color: _color, fontSize: 12, fontWeight: FontWeight.w600),
      ),
    );
  }
}

class _AmountBox extends StatelessWidget {
  final String label;
  final double value;
  final Color? color;

  const _AmountBox({required this.label, required this.value, this.color});

  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 10),
        decoration: BoxDecoration(
          color: Colors.grey.shade50,
          borderRadius: BorderRadius.circular(10),
          border: Border.all(color: Colors.grey.shade200),
        ),
        child: Column(
          children: [
            Text(label, style: TextStyle(fontSize: 11, color: Colors.grey.shade600)),
            const SizedBox(height: 3),
            Text(
              value.toStringAsFixed(0),
              style: TextStyle(
                fontWeight: FontWeight.bold,
                fontSize: 14,
                color: color ?? Colors.black87,
              ),
            ),
          ],
        ),
      ),
    );
  }
}