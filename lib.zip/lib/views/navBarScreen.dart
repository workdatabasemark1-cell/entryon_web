// screens/main_nav_screen.dart

import 'package:entryon/providers/auth_Provider.dart';
import 'package:entryon/views/customersListScreen.dart';
import 'package:entryon/views/login_screen.dart';
import 'package:entryon/views/menuScreen.dart';

import 'package:entryon/views/purchaseEntriesListScreen.dart';
import 'package:entryon/views/servicesListScreen.dart';
import 'package:entryon/views/transactionListScreen.dart';
import 'package:entryon/views/vatCalculationScreen.dart';
import 'package:flutter/material.dart';
import 'package:lucide_icons/lucide_icons.dart';
import 'package:provider/provider.dart';

class MainNavScreen extends StatefulWidget {
  const MainNavScreen({super.key});

  @override
  State<MainNavScreen> createState() => _MainNavScreenState();
}

class _MainNavScreenState extends State<MainNavScreen> {
  int _currentIndex = 0;

  final List<Widget> _screens = const [
    
    CustomersListScreen(),
    ServicesListScreen(),
    TransactionsListScreen(),
    PurchaseEntriesListScreen(),
    MenuScreen(),
  ];

  void _onTabTapped(int index) {
    setState(() {
      _currentIndex = index;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor:  Colors.grey.shade50,
       

      // ── Body ──────────────────────────────────────────────────────────
      body: Row(
        children: [Container(
          width: 150,
            decoration: BoxDecoration(
             borderRadius: const BorderRadius.all(Radius.circular(10)),
              color: Colors.grey.shade200,
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withOpacity(0.1),
                  spreadRadius: 10,
                  blurRadius: 5,
                  offset: const Offset(0, 0),
                ),
              ],
            ),
            child: Padding(
              padding: const EdgeInsets.all(4.0),
              child: Column(
                children: [
                  Expanded(
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.start,
                      children: [
                    
                    
                    
                    
                        Padding(
                          padding: const EdgeInsets.all(8.0),
                          child: Row(
                            children: [
                              Image.asset('assets/ic_launcher.png', width: 40, height: 40),
                              SizedBox(width: 8),
                              Text('EntryOn', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                            ],
                          ),
                        ),
                          Divider(height: 1, color: Colors.grey[300]),
                         SizedBox(height: 10,),
                        // _buildNavItem(
                        //   icon: LucideIcons.calculator,
                        //   activeIcon: LucideIcons.calculator,
                        //   label: 'Calculator',
                        //   index: 0,
                        // ),
                        // SizedBox(
                        //   height: 5,
                        // ),
                        _buildNavItem(
                          icon: Icons.people_alt_outlined,
                          activeIcon: Icons.people_alt_rounded,
                          label: 'Customers',
                          index: 0,
                        ),
                         SizedBox(
                          height: 5,
                        ),
                        _buildNavItem(
                          icon: Icons.build,
                          activeIcon: Icons.build,
                          label: 'Services',
                          index: 1,
                        ),
                        SizedBox(
                          height: 5,
                        ),
                        _buildNavItem(
                          icon: Icons.receipt_long_outlined,
                          activeIcon: Icons.receipt_long_rounded,
                          label: 'Transactions',
                          index: 2,
                        ),
                        SizedBox(
                          height: 5,
                        ),
                        _buildNavItem(
                          icon: LucideIcons.menuSquare,
                          activeIcon: LucideIcons.menuSquare,
                          label: 'Entries',
                          index: 3,
                        ),SizedBox(
                          height: 5,
                        ),
                        _buildNavItem(
                          icon: LucideIcons.layoutDashboard,
                          activeIcon: LucideIcons.layoutDashboard,
                          label: 'Menu',
                          index: 4,
                        ),
                      ],
                    ),
                  ),

                        _buildNavOtherItem(
                          icon: LucideIcons.logOut,
                          activeIcon: LucideIcons.logOut,
                          label: 'Logout',
                          onTap:(){_logout(context);},
                        ),
                ],
              ),
            ),
          ),
          Expanded(
            child: IndexedStack(
              index: _currentIndex,
              children: _screens,
            ),
          ),

        ],
      ),

      // ── FAB ────────────────────────────────────────────────────────────
      // floatingActionButton:
      //     ( _currentIndex == 1 || _currentIndex == 2)
      //         ? FloatingActionButton(
      //             onPressed: () {
      //               if (_currentIndex == 1) {
      //                 Navigator.push(
      //                   context,
      //                   MaterialPageRoute(
      //                     builder: (context) => const CreateCustomerScreen(),
      //                   ),
      //                 );
      //               } else if (_currentIndex == 2) {
      //                 Navigator.push(
      //                   context,
      //                   MaterialPageRoute(
      //                     builder: (context) => const PurchaseEntryScreen(),
      //                   ),
      //                 );
      //               } else {
      //                 Navigator.pushNamed(context, '/purchase-entry');
      //               }
      //             },
      //             backgroundColor: const Color(0xFF4F8EF7),
      //             foregroundColor: Colors.white,
      //             elevation: 4,
      //             child: const Icon(Icons.add_rounded, size: 28),
      //           )
      //         : null,

      // ── Bottom Navigation Bar (Venzo Style) ────────────────────────────
    //   bottomNavigationBar: SafeArea(
    //     child: Padding(
    //       padding: const EdgeInsets.fromLTRB(10, 0, 10,0),
    //       child: Container(
    //         height: 60,
    //         decoration: BoxDecoration(
    //           borderRadius: const BorderRadius.all(Radius.circular(16)),
    //           color: Colors.white,
    //           boxShadow: [
    //             BoxShadow(
    //               color: Colors.black.withOpacity(0.1),
    //               spreadRadius: 0,
    //               blurRadius: 2,
    //               offset: const Offset(0, 0),
    //             ),
    //           ],
    //         ),
    //         child: Padding(
    //           padding: const EdgeInsets.all(4.0),
    //           child: Row(
    //             mainAxisAlignment: MainAxisAlignment.spaceBetween,
    //             children: [
    //               _buildNavItem(
    //                 icon: LucideIcons.calculator,
    //                 activeIcon: LucideIcons.calculator,
    //                 label: 'Calculator',
    //                 index: 0,
    //               ),
    //               _buildNavItem(
    //                 icon: Icons.people_alt_outlined,
    //                 activeIcon: Icons.people_alt_rounded,
    //                 label: 'Customers',
    //                 index: 1,
    //               ),
    //               _buildNavItem(
    //                 icon: LucideIcons.menuSquare,
    //                 activeIcon: LucideIcons.menuSquare,
    //                 label: 'Entries',
    //                 index: 2,
    //               ),
    //               _buildNavItem(
    //                 icon: LucideIcons.layoutDashboard,
    //                 activeIcon: LucideIcons.layoutDashboard,
    //                 label: 'Menu',
    //                 index: 3,
    //               ),
    //             ],
    //           ),
    //         ),
    //       ),
    //     ),
    //   ),
   
    );
  }
Future<void> _logout(BuildContext context) async {
  final confirm = await showDialog<bool>(
    context: context,
    builder: (dialogContext) {
      return AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        title: const Text(
          'Logout',
          style: TextStyle(fontWeight: FontWeight.bold),
        ),
        content: const Text('Are you sure you want to logout?'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(dialogContext, false),
            child: Text('Cancel', style: TextStyle(color: Colors.grey.shade600)),
          ),
          ElevatedButton(
            style: ElevatedButton.styleFrom(
              backgroundColor: Colors.red,
              foregroundColor: Colors.white,
              elevation: 0,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
            ),
            onPressed: () => Navigator.pop(dialogContext, true),
            child: const Text('Logout'),
          ),
        ],
      );
    },
  );

  if (confirm == true && context.mounted) {
    context.read<AuthProvider>().logout();

    Navigator.of(context).pushAndRemoveUntil(
      MaterialPageRoute(builder: (_) => const LoginScreen()),
      (route) => false,
    );
  }
}
  Widget _buildNavItem({
    required IconData icon,
    required IconData activeIcon,
    required String label,
    required int index,
  }) {
    final bool isActive = _currentIndex == index;
    const activeColor = Color.fromARGB(255, 0, 0, 0);

    return GestureDetector(
      onTap: () => _onTabTapped(index),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 200),
        padding: const EdgeInsets.symmetric(vertical: 8, horizontal: 8),
        decoration: BoxDecoration(
          color: isActive
              ? activeColor.withOpacity(0.10)
              : Colors.transparent,
          borderRadius: BorderRadius.circular(5),
        ),
        child: SizedBox(width: 170,
          child: Row(
            mainAxisAlignment: MainAxisAlignment.start,
            children: [
              AnimatedSwitcher(
                duration: const Duration(milliseconds: 200),
                child: Icon(
                  isActive ? activeIcon : icon,
                  key: ValueKey(isActive),
                  color: isActive ? activeColor : Colors.grey.shade500,
                  size: isActive ? 22 : 20,
                ),
              ),
              const SizedBox(width: 2),
              Text(
                label,
                style: TextStyle(
                  color: isActive ? activeColor : Colors.grey.shade500,
                  fontSize: isActive ? 15 : 13,
                  fontWeight:
                      isActive ? FontWeight.w600 : FontWeight.normal,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
 Widget _buildNavOtherItem({
    required IconData icon,
    required IconData activeIcon,
    required String label,
  
    required VoidCallback onTap,
  }) {
   
    const activeColor = Color.fromARGB(255, 0, 0, 0);

    return GestureDetector(
      onTap: onTap,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 200),
        padding: const EdgeInsets.symmetric(vertical: 8, horizontal: 8),
        decoration: BoxDecoration(
          color:activeColor.withOpacity(0.10),
         
          borderRadius: BorderRadius.circular(5),
        ),
        child: SizedBox(width: 170,
          child: Row(
            mainAxisAlignment: MainAxisAlignment.start,
            children: [
              AnimatedSwitcher(
                duration: const Duration(milliseconds: 200),
                child: Icon(
            icon,
         
                  color:  activeColor ,
                  size:  20,
                ),
              ),
              const SizedBox(width: 2),
              Text(
                label,
                style: TextStyle(
                  color: activeColor ,
                  fontSize: 13,
                  fontWeight:
                      FontWeight.normal,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

}