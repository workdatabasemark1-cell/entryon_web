import 'package:entryon/models/customer_model.dart';
import 'package:entryon/models/supplier_model.dart';
import 'package:entryon/providers/customer_provider.dart';
import 'package:entryon/providers/supplier_provider.dart';
import 'package:entryon/views/createCustomerScreen.dart';
import 'package:entryon/views/createSupplierScreen.dart';
import 'package:entryon/views/customerDetailsScreen.dart';
import 'package:flutter/material.dart';
import 'package:lucide_icons/lucide_icons.dart';
import 'package:provider/provider.dart';
import 'package:flutter_staggered_grid_view/flutter_staggered_grid_view.dart';


import 'editSupplierScreen.dart';

// ── Constants ────────────────────────────────────────────────────────────────

abstract class _K {
  static const customerColor = Colors.blue;
  static const supplierColor = Colors.green;
  static const cardRadius = 10.0;
  static const pillRadius = 5.0;
  static const gridColumns = 3;
}

// ─────────────────────────────────────────────────────────────────────────────

class CustomersListScreen extends StatefulWidget {
  const CustomersListScreen({super.key});

  @override
  State<CustomersListScreen> createState() => _CustomersListScreenState();
}

class _CustomersListScreenState extends State<CustomersListScreen>
    with TickerProviderStateMixin {
  late final TabController _tabController;

  bool _showCreateScreen = false;

  final _customerSearch = TextEditingController();
  final _supplierSearch = TextEditingController();

  // Cached filtered lists — only rebuilt on search input
  List<Customer>? _filteredCustomers;
  List<Supplier>? _filteredSuppliers;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 2, vsync: this)
      // Only rebuild the AppBar button, not the whole tree
      ..addListener(_onTabChanged);

    WidgetsBinding.instance.addPostFrameCallback((_) {
      context.read<CustomerProvider>().fetchCustomers();
      context.read<SupplierProvider>().fetchSuppliers();
    });
  }

  void _onTabChanged() {
    // Rebuild only when the index actually changes (not on swipe mid-animation)
    if (_tabController.indexIsChanging) setState(() {});
  }

  @override
  void dispose() {
    _customerSearch.dispose();
    _supplierSearch.dispose();
    _tabController
      ..removeListener(_onTabChanged)
      ..dispose();
    super.dispose();
  }

  // ── Filtering ─────────────────────────────────────────────────────────────

  void _filterCustomers(String q) {
    final all = context.read<CustomerProvider>().customers;
    setState(() {
      _filteredCustomers = q.isEmpty
          ? null // null = "use full list"
          : all
              .where((c) =>
                  c.name.toLowerCase().contains(q.toLowerCase()) ||
                  c.phone.contains(q) ||
                  c.taxNumber.toLowerCase().contains(q.toLowerCase()))
              .toList();
    });
  }

  void _filterSuppliers(String q) {
    final all = context.read<SupplierProvider>().suppliers;
    setState(() {
      _filteredSuppliers = q.isEmpty
          ? null
          : all
              .where((s) =>
                  s.name.toLowerCase().contains(q.toLowerCase()) ||
                  s.phone.contains(q) ||
                  s.vatNumber.toLowerCase().contains(q.toLowerCase()))
              .toList();
    });
  }

  // ── Deletion ──────────────────────────────────────────────────────────────

  Future<void> _confirmDelete({
    required String title,
    required String message,
    required Future<void> Function() onConfirm,
    required String successMessage,
  }) async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: Colors.white,
        title: Text(title),
        content: Text(message),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(context, false),
              child: const Text('Cancel')),
          TextButton(
            onPressed: () => Navigator.pop(context, true),
            child: Text('Delete',
                style: TextStyle(color: Colors.red.shade600)),
          ),
        ],
      ),
    );

    if (confirmed != true || !mounted) return;
    await onConfirm();
    if (!mounted) return;
    ScaffoldMessenger.of(context)
        .showSnackBar(SnackBar(content: Text(successMessage)));
  }

  void _deleteCustomer(String id) => _confirmDelete(
        title: 'Delete Customer',
        message: 'Are you sure you want to delete this customer?',
        onConfirm: () => context.read<CustomerProvider>().deleteCustomer(id),
        successMessage: 'Customer deleted successfully',
      );

  void _deleteSupplier(String id) => _confirmDelete(
        title: 'Delete Supplier',
        message: 'Are you sure you want to delete this supplier?',
        onConfirm: () => context.read<SupplierProvider>().deleteSupplier(id),
        successMessage: 'Supplier deleted successfully',
      );

  // ── Navigation helpers ────────────────────────────────────────────────────

  void _toggleCreateScreen(bool value) =>
      setState(() => _showCreateScreen = value);

  // ── Build ─────────────────────────────────────────────────────────────────

  @override
  Widget build(BuildContext context) {
    final isCustomersTab = _tabController.index == 0;

    return Scaffold(
      backgroundColor: Colors.grey.shade100,
      appBar: AppBar(scrolledUnderElevation: 0,
        backgroundColor: Colors.white,
        centerTitle: true,
        title: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [ Row(
            children: [   _PillTabBar(controller: _tabController),
             
            ],
          ),
            const Text(
              'Customers & Suppliers',
              style: TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.w500,
                  color: Colors.black),
            ),
         
            Row(
              children: [ SizedBox(width: 325,
                child:isCustomersTab? _SearchBar(
                        controller: _customerSearch,
                        hint: 'Search by name, phone, or tax number...',
                        onChanged: _filterCustomers,
                      ): _SearchBar(
                      controller: _supplierSearch,
                      hint: 'Search by name, phone, or VAT number...',
                      onChanged: _filterSuppliers,
                    ),
              ),
           isCustomersTab?     _AddButton(
                  label: 'Create Customer' ,
                  onTap: () {
                    // _toggleCreateScreen(true);
                  showDialog(
              context: context,
              builder: (_) => Dialog(
                insetPadding: EdgeInsets.all(16),
                child: SizedBox(
                  width: 1000,
                  child: CreateCustomerScreen(
                      onClose: () => _toggleCreateScreen(false)),
                ),
              ),
            ).then((_) {
              context.read<CustomerProvider>().fetchCustomers();
            });
                  },
                ):
                _AddButton(
                  label: 'Create Supplier',
                  onTap: () {
                  //   _toggleCreateScreen(true);
                  // Provider.of<CustomerProvider>(context, listen: false).toggleShowAddSupplierScreen();

                  showDialog(
              context: context,
              builder: (_) => Dialog(
                insetPadding: EdgeInsets.all(16),
                child: SizedBox(
                  width: 500,
                  child: CreateSupplierScreen(
                      onClose: () => _toggleCreateScreen(false)),
                ),
              ),).then((_) {
              context.read<CustomerProvider>().fetchCustomers();
            });
                  },
                ),
              ],
            ),
          ],
        ),
      ),
      body: Row(
        children: [
          Expanded(
            child: Padding(
             padding: const EdgeInsets.only(top: 8.0),
              child: TabBarView(
                controller: _tabController,
                children: [
                  _customersTab(),
                  _suppliersTab(),
                ],
              ),
            ),
          ),


          //   isCustomersTab?
          // showDialog(
          //     context: context,
          //     builder: (_) => Dialog(
          //       insetPadding: EdgeInsets.all(16),
          //       child: SizedBox(
          //         width: 900,
          //         child: CreateCustomerScreen(
          //             onClose: () => _toggleCreateScreen(false)),
          //       ),
          //     ),
          //   ).then((_) {
          //     context.read<CustomerProvider>().fetchCustomers();
          //   }): showDialog(
          //     context: context,
          //     builder: (_) => Dialog(
          //       insetPadding: EdgeInsets.all(16),
          //       child: SizedBox(
          //         width: 500,
          //         child: CreateSupplierScreen(
          //             onClose: () => _toggleCreateScreen(false)),
          //       ),
          //     ),
          //   ).then((_) {
          //     context.read<SupplierProvider>().fetchSuppliers();
          //   }),
        //   _showCreateScreen==true &&
        //   Provider.of<CustomerProvider>(context, listen: false).showAddSupplierScreen==true&&isCustomersTab
        //   ?
         
        // //  SizedBox():
        // //     _SidePanel(
        // //       child: 
        // //       // isCustomersTab
        // //           // ? CreateCustomerScreen(
        // //           //     onClose: () => _toggleCreateScreen(false))
        // //           // : 
        // //           CreateSupplierScreen(
        // //               onClose: () =>   Provider.of<CustomerProvider>(context, listen: false).toggleCloseShowAddSupplierScreen()
        // //               ),
        // //     ),
        ],
      ),
    );
  }

  // ── Tab bodies ────────────────────────────────────────────────────────────

  Widget _customersTab() {
    return Column(children: [
      // _SearchBar(
      //   controller: _customerSearch,
      //   hint: 'Search by name, phone, or tax number...',
      //   onChanged: _filterCustomers,
      // ),
      Expanded(
        child: RefreshIndicator(
          onRefresh: () => context.read<CustomerProvider>().fetchCustomers(),
          child: Selector<CustomerProvider, List<Customer>>(
            selector: (_, p) => p.customers,
            builder: (_, customers, __) {
              if (customers.isEmpty) {
                return _EmptyState(
                    icon: Icons.people_outline, text: 'No customers found');
              }
              final list = _filteredCustomers ?? customers;
              return _MasonryGrid(
                itemCount: list.length,
                itemBuilder: (i) {
                  final customer = list[i];
                  final alertState = context.read<CustomerProvider>().getActivationAlertState(customer);
                  final isAlerting = alertState != ActivationAlertState.none;
                  final expiryDate = customer.softwareActivations.isNotEmpty
                      ? context.read<CustomerProvider>().parseActivationDate(
                          customer.softwareActivations.first['expiryDate'],
                        )
                      : null;

                  return _ContactCard(
                    avatarLetter: customer.name[0].toUpperCase(),
                    avatarColor: alertState == ActivationAlertState.expired
                        ? Colors.red.shade700
                        : alertState == ActivationAlertState.warning
                            ? Colors.orange.shade700
                            : _K.customerColor.shade700,
                    title: customer.name,
                    subtitle: customer.phone,
                    expiryDate: expiryDate,
                    infoRows: _customerInfoRows(customer),
                    editColor: _K.customerColor.shade700,
                    isExpired: isAlerting,
                    alertState: alertState,
                    onEdit: () {
  showDialog(
    context: context,
    builder: (_) => Dialog(
      insetPadding: EdgeInsets.all(16),
      child: SizedBox(
        width: 900,
        child: CreateCustomerScreen(customer: list[i]),
      ),
    ),
  ).then((_) {
    context.read<CustomerProvider>().fetchCustomers();
  });
},
                    onViewDetails: () {
                      // Navigator.push(
                      //   context,
                      //   MaterialPageRoute(
                      //     builder: (_) => CustomerDetailsScreen(customer: customer),
                      //   ),
                      // );
                                                 showDialog(
  context: context,
  builder: (_) => Dialog(
    insetPadding: const EdgeInsets.all(20),
    child: SizedBox(
      width: 600,
      height: 900,
      child: CustomerDetailsScreen(customer: customer),
    ),
  ),
);
                    },

                      onDelete: () => _deleteCustomer(customer.id),
                    );
                  },
                );
            },
          ),
        ),
      ),
    ]);
  }

  Widget _suppliersTab() {
    return Column(children: [
     
      Expanded(
        child: RefreshIndicator(
          onRefresh: () => context.read<SupplierProvider>().fetchSuppliers(),
          child: Selector<SupplierProvider, List<Supplier>>(
            selector: (_, p) => p.suppliers,
            builder: (_, suppliers, __) {
              if (suppliers.isEmpty) {
                return _EmptyState(
                    icon: Icons.store_outlined, text: 'No suppliers found');
              }
              final list = _filteredSuppliers ?? suppliers;
              return _MasonryGrid(
                itemCount: list.length,
                itemBuilder: (i) => _ContactCard(isExpired: false,onViewDetails: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (_) => CustomerDetailsScreen(customer: 
                      Customer(
                        id: list[i].id!,
                        name: list[i].name,
                        phone: list[i].phone,
                        address: list[i].address ?? '',
                        taxNumber: list[i].vatNumber,
                      )),
                    ),
                  );
                },
                  alertState: ActivationAlertState.none,
                  avatarLetter: list[i].name[0].toUpperCase(),
                  avatarColor: _K.supplierColor.shade700,
                  title: list[i].name,
                  subtitle: list[i].phone,
                  infoRows: _supplierInfoRows(list[i]),
                  editColor: _K.supplierColor.shade700,
                 onEdit: () {
  showDialog(
    context: context,
    builder: (_) => Dialog(
      insetPadding: EdgeInsets.all(16),
      child: SizedBox(
        width: 500,
        child: EditSupplierScreen(supplier: list[i]),
      ),
    ),
  ).then((_) {
    context.read<SupplierProvider>().fetchSuppliers();
  });
},

                  onDelete: () => _deleteSupplier(list[i].id!),
                ),
              );
            },
          ),
        ),
      ),
    ]);
  }

  // ── Info row builders ─────────────────────────────────────────────────────

  static List<CardInfoRow> _customerInfoRows(Customer c) => [
        CardInfoRow(Icons.phone_outlined, 'Phone 1', c.phone),
        if (c.phone2?.isNotEmpty ?? false)
          CardInfoRow(Icons.phone_outlined, 'Phone 2', c.phone2!),
        if (c.email?.isNotEmpty ?? false)
          CardInfoRow(Icons.email_outlined, 'Email', c.email!),
        CardInfoRow(Icons.location_on_outlined, 'Address', c.address),
        if (c.cityName?.isNotEmpty ?? false)
          CardInfoRow(Icons.location_city_outlined, 'City', c.cityName!),
        if (c.organizationName?.isNotEmpty ?? false)
          CardInfoRow(Icons.business_outlined, 'Organization',
              c.organizationName!),
        if (c.periodSectionName?.isNotEmpty ?? false)
          CardInfoRow(Icons.calendar_today_outlined, 'Period',
              c.periodSectionName!),
        CardInfoRow(
            Icons.receipt_long_outlined, 'VAT Number', c.taxNumber),
        if (c.crNumber?.isNotEmpty ?? false)
          CardInfoRow(
              Icons.assignment_outlined, 'CR Number', c.crNumber!),
      ];

  static List<CardInfoRow> _supplierInfoRows(Supplier s) => [
        CardInfoRow(Icons.phone_outlined, 'Phone 1', s.phone),
        CardInfoRow(Icons.location_on_outlined, 'Address',
            s.address ?? 'Not specified'),
        CardInfoRow(Icons.numbers_outlined, 'VAT Number', s.vatNumber),
      ];
}

// ─────────────────────────────────────────────────────────────────────────────
// Small extracted widgets
// ─────────────────────────────────────────────────────────────────────────────

class _PillTabBar extends StatelessWidget {
  const _PillTabBar({required this.controller});
  final TabController controller;

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 42,
      width: 300,
      padding: const EdgeInsets.all(4),
      decoration: BoxDecoration(
        color: Colors.grey.shade200,
        borderRadius: BorderRadius.circular(_K.pillRadius),
      ),
      child: TabBar(
        controller: controller,
        indicator: BoxDecoration(
          borderRadius: BorderRadius.circular(_K.pillRadius),
          color: Colors.white,
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.10),
              blurRadius: 4,
              offset: const Offset(0, 1),
            ),
          ],
        ),
        indicatorSize: TabBarIndicatorSize.tab,
        dividerColor: Colors.transparent,
        labelColor: Colors.black,
        unselectedLabelColor: Colors.black38,
        labelStyle: const TextStyle(fontWeight: FontWeight.w600, fontSize: 14),
        tabs: const [Tab(text: 'Customers'), Tab(text: 'Suppliers')],
      ),
    );
  }
}

class _AddButton extends StatelessWidget {
  const _AddButton({required this.label, required this.onTap});
  final String label;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 40,
      padding: const EdgeInsets.symmetric(horizontal: 10),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(8),
        boxShadow: [
          BoxShadow(
              color: Colors.black.withOpacity(0.1),
              blurRadius: 2,
              offset: Offset.zero),
        ],
      ),
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(8),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Icon(Icons.add),
            const SizedBox(width: 8),
            Text(label,
                style:
                    const TextStyle(fontSize: 16, fontWeight: FontWeight.w600)),
          ],
        ),
      ),
    );
  }
}

class _SearchBar extends StatelessWidget {
  const _SearchBar(
      {required this.controller,
      required this.hint,
      required this.onChanged});
  final TextEditingController controller;
  final String hint;
  final ValueChanged<String> onChanged;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(8),
      child: TextField(
        controller: controller,
        onChanged: onChanged,
        decoration: InputDecoration(
          filled: true,
          fillColor: Colors.grey.shade50,
          contentPadding: EdgeInsets.symmetric(vertical: 8),
          hintText: hint,
          isDense: true,focusColor:Colors.grey.shade50,
          hoverColor: Colors.grey.shade50,

          prefixIcon: const Icon(LucideIcons.search,size: 15,),
          suffixIcon: controller.text.isNotEmpty
              ? IconButton(
                  icon: const Icon(Icons.clear),
                  onPressed: () {
                    controller.clear();
                    onChanged('');
                  },
                )
              : null,
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(8),
            borderSide: BorderSide(color: Colors.grey.shade200),
          ),
          enabledBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(8),
          borderSide: BorderSide(color: Colors.grey.shade200),
          ),
          focusedBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(8),
           borderSide: BorderSide(color: Colors.grey.shade200),
          ),
          
        ),
      ),
    );
  }
}

class _SidePanel extends StatelessWidget {
  const _SidePanel({required this.child});
  final Widget child;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(8.0),
      child: SizedBox(
        width: 500,
        
        child: DecoratedBox(
          decoration: BoxDecoration(borderRadius: BorderRadius.circular(10),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withOpacity(0.15),
                blurRadius: 12,
              ),
            ],
          ),
          child: child,
        ),
      ),
    );
  }
}

class _MasonryGrid extends StatelessWidget {
  const _MasonryGrid(
      {required this.itemCount, required this.itemBuilder});
  final int itemCount;
  final Widget Function(int) itemBuilder;

  @override
  Widget build(BuildContext context) {
    return MasonryGridView.count(
      padding: const EdgeInsets.symmetric(horizontal: 8),
      crossAxisCount: _K.gridColumns,
      mainAxisSpacing: 10,
      crossAxisSpacing: 10,
      itemCount: itemCount,
      itemBuilder: (_, i) => itemBuilder(i),
    );
  }
}

class _EmptyState extends StatelessWidget {
  const _EmptyState({required this.icon, required this.text});
  final IconData icon;
  final String text;

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
        Icon(icon, size: 64, color: Colors.grey.shade400),
        const SizedBox(height: 16),
        Text(text,
            style: TextStyle(fontSize: 18, color: Colors.grey.shade600)),
      ]),
    );
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// Unified Contact Card  (replaces _CustomerCard + _SupplierCard)
// ─────────────────────────────────────────────────────────────────────────────

@immutable
class CardInfoRow {
  final IconData icon;
  final String label;
  final String value;
  const CardInfoRow(this.icon, this.label, this.value);
}

class _ContactCard extends StatefulWidget {
  const _ContactCard({
    required this.avatarLetter,
    required this.avatarColor,
    required this.title,
    required this.subtitle,
    this.expiryDate,
    required this.infoRows,
    required this.editColor,
    required this.isExpired,
    required this.alertState,
    required this.onEdit,
    required this.onViewDetails,
    required this.onDelete,
  });

  final String avatarLetter;
  final Color avatarColor;
  final String title;
  final String subtitle;
  final DateTime? expiryDate;
  final List<CardInfoRow> infoRows;
  final Color editColor;
  final bool isExpired;
  final ActivationAlertState alertState;
  final VoidCallback onEdit;
  final VoidCallback onViewDetails;
  final VoidCallback onDelete;

  @override
  State<_ContactCard> createState() => _ContactCardState();
}

class _ContactCardState extends State<_ContactCard>
    with SingleTickerProviderStateMixin {
  late final AnimationController _ctrl = AnimationController(
      vsync: this, duration: const Duration(milliseconds: 250));

  late final Animation<double> _expandAnim =
      CurvedAnimation(parent: _ctrl, curve: Curves.easeInOut);

  late final Animation<double> _rotateAnim =
      Tween<double>(begin: 0, end: 0.5).animate(_expandAnim);

  bool _expanded = false;

  @override
  void dispose() {
    _ctrl.dispose();
    super.dispose();
  }

  void _toggle() {
    setState(() => _expanded = !_expanded);
    _expanded ? _ctrl.forward() : _ctrl.reverse();
  }

  @override
  Widget build(BuildContext context) {
    final isWarning = widget.alertState == ActivationAlertState.warning;
    final isExpired = widget.alertState == ActivationAlertState.expired;
    final borderColor = isExpired
        ? Colors.red.shade600
        : isWarning
            ? Colors.orange.shade600
            : Colors.transparent;
    final surfaceColor = isExpired
        ? Colors.red.shade50
        : isWarning
            ? Colors.orange.shade50
            : Colors.white;

    return Container(
      decoration: BoxDecoration(
        color: surfaceColor,
        borderRadius: BorderRadius.circular(_K.cardRadius),
        border: Border.all(color: borderColor, width: widget.isExpired ? 1.4 : 0),
        boxShadow: [
          BoxShadow(
              color: Colors.black.withOpacity(0.07),
              blurRadius: 2,
              offset: Offset.zero),
        ],
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(_K.cardRadius),
        child: Column(children: [
          if (widget.isExpired)
            Container(
              width: double.infinity,
              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
              color: isExpired ? Colors.red.shade100 : Colors.orange.shade100,
              child: Row(
                children: [
                  Icon(Icons.warning_amber_rounded, size: 16, color: isExpired ? Colors.red.shade700 : Colors.orange.shade700),
                  const SizedBox(width: 6),
                  Expanded(
                    child: Text(
                      isExpired ? 'Activation expired' : 'Activation expires soon',
                      style: TextStyle(
                        color: isExpired ? Colors.red.shade700 : Colors.orange.shade700,
                        fontSize: 12,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                  ),
                ],
              ),
            ),
          // Header
          InkWell(
            onTap: _toggle,
            child: Padding(
              padding:
                  const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
              child: Row(children: [
                _Avatar(
                    letter: widget.avatarLetter, color: widget.avatarColor),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(widget.title,
                          style: const TextStyle(
                              fontWeight: FontWeight.w700, fontSize: 15)),
                      const SizedBox(height: 2),
                      Row(mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text(widget.subtitle,
                              style: TextStyle(
                                  fontSize: 13, color: Colors.grey.shade600)),
                                  Text(widget.expiryDate != null ? ' Expires: ${widget.expiryDate!.toLocal().toString().split(' ')[0]}' : '',
                              style: TextStyle(
                                  fontSize: 13, color: Colors.grey.shade600)),
                                 
                        ],
                      ),
                    ],
                  ),
                ),
                RotationTransition(
                  turns: _rotateAnim,
                  child: Icon(Icons.keyboard_arrow_down_rounded,
                      color: Colors.grey.shade400, size: 22),
                ),
              ]),
            ),
          ),

          // Expandable body
          SizeTransition(
            sizeFactor: _expandAnim,
            axisAlignment: -1,
            child: Column(children: [
              Divider(height: 1, color: Colors.grey.shade100),
              Padding(
                padding: const EdgeInsets.fromLTRB(16, 14, 16, 6),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    ...widget.infoRows.map((row) => Padding(
                          padding: const EdgeInsets.only(bottom: 8),
                          child: Row(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Icon(row.icon,
                                  size: 16, color: Colors.grey.shade500),
                              const SizedBox(width: 8),
                              Text('${row.label}: ',
                                  style: TextStyle(
                                      fontSize: 13,
                                      color: Colors.grey.shade500,
                                      fontWeight: FontWeight.w500)),
                              Expanded(
                                child: Text(
                                  row.value.isEmpty ? '—' : row.value,
                                  style: const TextStyle(
                                      fontSize: 13,
                                      fontWeight: FontWeight.w600),
                                ),
                              ),
                            ],
                          ),
                        )),
                    const SizedBox(height: 8),
                    Row(children: [
                      Expanded(
                          child: _ActionButton(
                        icon: Icons.remove_red_eye_outlined,
                        label: 'Details',
                        color: Colors.teal.shade700,
                        onTap: widget.onViewDetails,
                      )),
                      const SizedBox(width: 10),
                      Expanded(
                          child: _ActionButton(
                        icon: Icons.edit_outlined,
                        label: 'Edit',
                        color: widget.editColor,
                        onTap: widget.onEdit,
                      )),
                      const SizedBox(width: 10),
                      Expanded(
                          child: _ActionButton(
                        icon: Icons.delete_outline_rounded,
                        label: 'Delete',
                        color: Colors.red.shade600,
                        onTap: widget.onDelete,
                      )),
                    ]),
                    const SizedBox(height: 10),
                  ],
                ),
              ),
            ]),
          ),
        ]),
      ),
    );
  }
}

class _Avatar extends StatelessWidget {
  const _Avatar({required this.letter, required this.color});
  final String letter;
  final Color color;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 42,
      height: 42,
      decoration: BoxDecoration(
        color: color.withOpacity(0.12),
        borderRadius: BorderRadius.circular(11),
      ),
      child: Center(
        child: Text(letter,
            style: TextStyle(
                color: color, fontWeight: FontWeight.bold, fontSize: 17)),
      ),
    );
  }
}

class _ActionButton extends StatelessWidget {
  const _ActionButton(
      {required this.icon,
      required this.label,
      required this.color,
      required this.onTap});
  final IconData icon;
  final String label;
  final Color color;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return Material(
      color: color.withOpacity(0.08),
      borderRadius: BorderRadius.circular(30),
      child: InkWell(
        borderRadius: BorderRadius.circular(30),
        onTap: onTap,
        child: Padding(
          padding: const EdgeInsets.symmetric(vertical: 10),
          child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
            Icon(icon, size: 17, color: color),
            const SizedBox(width: 6),
            Text(label,
                style: TextStyle(
                    fontSize: 13,
                    fontWeight: FontWeight.w600,
                    color: color)),
          ]),
        ),
      ),
    );
  }
}