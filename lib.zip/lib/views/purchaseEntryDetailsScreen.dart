import 'package:entryon/models/purchase_entry_model.dart';
import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:intl/intl.dart';

class PurchaseEntryDetailsScreen extends StatefulWidget {
  final PurchaseInvoice invoice;
  final VoidCallback? onDelete;
  final void Function(List<PurchaseItem>)? onExportPdf;
  final void Function(List<PurchaseItem>)? onExportExcel;
  final VoidCallback? onEdit;

  const PurchaseEntryDetailsScreen({
    super.key,
    required this.invoice,
    this.onDelete,
    this.onExportPdf,
    this.onExportExcel,
    this.onEdit,
  });

  @override
  State<PurchaseEntryDetailsScreen> createState() => _PurchaseEntryDetailsScreenState();
}

class _PurchaseEntryDetailsScreenState extends State<PurchaseEntryDetailsScreen> {
  DateTime? _itemFilterFrom;
  DateTime? _itemFilterTo;
  String _supplierFilter = '';
  String _sortBy = 'date_desc';
  late final TextEditingController _supplierController;
  late List<PurchaseItem> _filteredInvoiceItems;

  @override
  void initState() {
    super.initState();
    _supplierController = TextEditingController();
    _filteredInvoiceItems = List.from(widget.invoice.items);
  }

  @override
  void dispose() {
    _supplierController.dispose();
    super.dispose();
  }

  void _applyInvoiceItemFilters() {
    final supplierQuery = _supplierFilter.trim().toLowerCase();
    final baseItems = widget.invoice.items.where((item) {
      final matchesSupplier =
          supplierQuery.isEmpty ||
          item.supplierName.toLowerCase().contains(supplierQuery);
      final itemDate = DateTime(item.date.year, item.date.month, item.date.day);
      final fromDate = _itemFilterFrom != null
          ? DateTime(
              _itemFilterFrom!.year,
              _itemFilterFrom!.month,
              _itemFilterFrom!.day,
            )
          : null;
      final toDate = _itemFilterTo != null
          ? DateTime(
              _itemFilterTo!.year,
              _itemFilterTo!.month,
              _itemFilterTo!.day,
            )
          : null;

      final afterFrom = fromDate == null || !itemDate.isBefore(fromDate);
      final beforeTo = toDate == null || !itemDate.isAfter(toDate);

      return matchesSupplier && afterFrom && beforeTo;
    }).toList();

    _filteredInvoiceItems = List.from(baseItems);
    _sortFilteredItems();
  }

  void _sortFilteredItems() {
    _filteredInvoiceItems.sort((a, b) {
      switch (_sortBy) {
        case 'date_asc':
          return a.date.compareTo(b.date);
        case 'date_desc':
          return b.date.compareTo(a.date);
        case 'supplier_asc':
          return a.supplierName.toLowerCase().compareTo(b.supplierName.toLowerCase());
        case 'supplier_desc':
          return b.supplierName.toLowerCase().compareTo(a.supplierName.toLowerCase());
        case 'amount_asc':
          return a.totalIncVat.compareTo(b.totalIncVat);
        case 'amount_desc':
          return b.totalIncVat.compareTo(a.totalIncVat);
        default:
          return b.date.compareTo(a.date);
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF5F6FA),
      // appBar: AppBar(
      //   title: const Text('Invoice Details'),
      //   backgroundColor: Colors.white,
      //   elevation: 0,
      //   leading: Row(
      //     children: [_buildFilters(),
      //       IconButton(
      //         icon: const Icon(Icons.arrow_back),
      //         onPressed: () => Navigator.pop(context),
      //       ),
      //     ],
      //   ),
      // ),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Row(
                  children: [
                    IconButton(
                      icon: const Icon(Icons.arrow_back),
                      onPressed: () => Navigator.pop(context),
                    ),
                    const SizedBox(width: 8),
                    const Text(
                      'Invoice Details',
                      style: TextStyle(
                        fontSize: 20,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ],
                ),
               
              ],
            ),
            SizedBox(height: 8),
            // Info + Totals Row (same as before)
            Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Expanded(
                  flex: 3,
                  child: _InfoCard(
                    title: 'Invoice Info',
                    icon: Icons.info_outline_rounded,
                    children: [
                      Row(
                        children: [
                          Expanded(
                            child: Column(children:[ _InfoTile(
                              label: 'Customer',
                              value: widget.invoice.customerName,
                            ),
                            if (widget.invoice.customerVatNumber.isNotEmpty)
                              _InfoTile(
                                label: 'VAT Number',
                                value: widget.invoice.customerVatNumber,
                              ),]),
                          ),
                                               Expanded(
                                                 child: Column(children:[ _InfoTile(
                                                                             label: 'Created Date',
                                                                             value: DateFormat(
                                                                               'dd MMM yyyy',
                                                                             ).format(widget.invoice.createdAt),
                                                                           ),
                                                                           if (widget.invoice.periodSectionName.isNotEmpty)
                                                                             _InfoTile(
                                                                               label: 'Period Section',
                                                                               value: widget.invoice.periodSectionName,
                                                                             ),]),
                                               ),
                        ],
                      )
                     
                    ],
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  flex: 2,
                  child: Container(
                    padding: const EdgeInsets.all(16),
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(14),
                      border: Border.all(color: Colors.grey.shade200),
                    ),
                    child:    Column(
                      children: [
                        _buildFilters(),SizedBox(height: 12),
                        Row(
                                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                      children: [
                                        Row(
                                          children: [
                        SizedBox(
                          width: 135,
                          child:InkWell(
  onTap: () => widget.onExportPdf?.call(_filteredInvoiceItems),
  borderRadius: BorderRadius.circular(30),
  child: Container(
    padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 5),
    decoration: BoxDecoration(
      color: Colors.white,
      borderRadius: BorderRadius.circular(30),
      border: Border.all(color: Colors.red),
      boxShadow: [
        BoxShadow(
          color: Colors.black.withOpacity(0.05),
          blurRadius: 4,
          offset: const Offset(0, 2),
        ),
      ],
    ),
    child: Row(
      mainAxisSize: MainAxisSize.min,
      children: const [
        FaIcon(
          FontAwesomeIcons.solidFilePdf,
          color: Colors.red,
          size: 18,
        ),
        SizedBox(width: 8),
        Text(
          'Export PDF',
          style: TextStyle(
            color: Colors.red,
            fontWeight: FontWeight.w600,
            fontSize: 14,
          ),
        ),
      ],
    ),
  ),
)

                        ),
                        const SizedBox(width: 12),
                        SizedBox(
                          width: 135,
                          child:InkWell(
  onTap: () => widget.onExportExcel?.call(_filteredInvoiceItems),
  borderRadius: BorderRadius.circular(30),
  child: Container(
    padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 5),
    decoration: BoxDecoration(
      color: Colors.white,
      borderRadius: BorderRadius.circular(30),
      border: Border.all(color: Colors.green.shade700),
      boxShadow: [
        BoxShadow(
          color: Colors.black.withOpacity(0.05),
          blurRadius: 4,
          offset: const Offset(0, 2),
        ),
      ],
    ),
    child: Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        FaIcon(
          FontAwesomeIcons.solidFileExcel,
          color: Colors.green.shade700,
          size: 18,
        ),
        const SizedBox(width: 8),
        Text(
          'Export Excel',
          style: TextStyle(
            color: Colors.green.shade700,
            fontWeight: FontWeight.w600,
            fontSize: 14,
          ),
        ),
      ],
    ),
  ),
)
,
                        ),
                                          ],
                                        ),
                                        Row(
                                          children: [
                        _OutlineBtn(
                          label: 'Delete Invoice',
                          icon: Icons.delete_outline_rounded,
                          color: Colors.red.shade600,
                          onTap: widget.onDelete ?? () {},
                        ),
                        const SizedBox(width: 10),
                        _OutlineBtn(
                          label: 'Edit Invoice',
                          icon: Icons.edit_outlined,
                          color: const Color(0xFF4F8EF7),
                          onTap: widget.onEdit ?? () {},
                        ),
                                          ],
                                        ),
                                      ],
                                    ),
                      ],
                    ),
           ),
                ),
              ],
            ),

            const SizedBox(height: 16),

            // Line Items Section
            Expanded(
              child: Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(14),
                  border: Border.all(color: Colors.grey.shade200),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        const Icon(
                          Icons.list_alt_outlined,
                          size: 16,
                          color: Color(0xFF4F8EF7),
                        ),
                        const SizedBox(width: 6),
                        Text(
                          'Line Items',
                          style: TextStyle(
                            fontWeight: FontWeight.w700,
                            fontSize: 13,
                            color: Colors.grey.shade700,
                          ),
                        ),
                        const Spacer(),
                        Container(
                          margin: const EdgeInsets.only(right: 8),
                          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                          decoration: BoxDecoration(
                            color: const Color(0xFFF0F1F5),
                            borderRadius: BorderRadius.circular(20),
                          ),
                          child: Text(
                            '${_filteredInvoiceItems.length} items',
                            style: const TextStyle(
                              fontSize: 12,
                              fontWeight: FontWeight.w600,
                              color: Color(0xFF4F8EF7),
                            ),
                          ),
                        ),
                        DropdownButtonHideUnderline(
                          child: DropdownButton<String>(
                            value: _sortBy,
                            isDense: true,
                            items: const [
                              DropdownMenuItem(value: 'date_desc', child: Text('Sort: Newest')),
                              DropdownMenuItem(value: 'date_asc', child: Text('Sort: Oldest')),
                              DropdownMenuItem(value: 'supplier_asc', child: Text('Sort: Supplier A-Z')),
                              DropdownMenuItem(value: 'supplier_desc', child: Text('Sort: Supplier Z-A')),
                              DropdownMenuItem(value: 'amount_desc', child: Text('Sort: Amount High-Low')),
                              DropdownMenuItem(value: 'amount_asc', child: Text('Sort: Amount Low-High')),
                            ],
                            onChanged: (value) {
                              if (value == null) return;
                              setState(() {
                                _sortBy = value;
                                _sortFilteredItems();
                              });
                            },
                          ),
                        ),
                      ],
                    ),
                    // const SizedBox(height: 12),
                    // // Filters (Date + Supplier)
                    // _buildFilters(),
                    const SizedBox(height: 12),
                    Expanded(child: _buildDataTableWithTotals()),
                  ],
                ),
              ),
            ),
            //const SizedBox(height: 8),
      //  Container(height:50,

      //                          padding: const EdgeInsets.all(16),
      //                          decoration: BoxDecoration(
      //                            color: Colors.white,
      //                            borderRadius: BorderRadius.circular(14),
      //                            border: Border.all(color: Colors.grey.shade200),
      //                          ),
      //                          child: 
                               
                               
      //                          Row(mainAxisAlignment: MainAxisAlignment.end,
      //                            crossAxisAlignment: CrossAxisAlignment.start,
      //                            children: [
      //                              Row(
      //                                children: [
      //                                  const Icon(
      //                                    Icons.calculate_outlined,
      //                                    size: 16,
      //                                    color: Color(0xFF4F8EF7),
      //                                  ),
      //                                  const SizedBox(width: 6),
      //                                  Text(
      //                                    'Totals',
      //                                    style: TextStyle(
      //                                      fontWeight: FontWeight.w700,
      //                                      fontSize: 13,
      //                                      color: Colors.grey.shade700,
      //                                    ),
      //                                  ),
      //                                ],
      //                              ),
      //                              const SizedBox(height: 12),
      //                             Row(
      //                                mainAxisAlignment: MainAxisAlignment.spaceBetween,
      //                                children: [
      //                                  const Text(
      //                                    'Excl VAT : ',
      //                                    style: TextStyle(
      //                                      fontWeight: FontWeight.w700,
      //                                      fontSize: 14,
      //                                      color: Colors.black,
      //                                    ),
      //                                  ),
      //                                  Text(
      //                                    widget.invoice.totalAmountExVat
      //                                        .toStringAsFixed(2),
      //                                    style: const TextStyle(
      //                                      fontWeight: FontWeight.w800,
      //                                      fontSize: 16,
      //                                      color: Colors.black,
      //                                    ),
      //                                  ),
      //                                ],
      //                              ),
      //                              SizedBox(width: 12),
      //                              const Divider(height: 16),
      //                            Row(
      //                                mainAxisAlignment: MainAxisAlignment.spaceBetween,
      //                                children: [
      //                                  const Text(
      //                                    '',
      //                                    style: TextStyle(
      //                                      fontWeight: FontWeight.w700,
      //                                      fontSize: 14,
      //                                      color: Colors.black,
      //                                    ),
      //                                  ),
      //                                  Text(
      //                                    widget.invoice.totalVatAmount
      //                                        .toStringAsFixed(2),
      //                                    style: const TextStyle(
      //                                      fontWeight: FontWeight.w800,
      //                                      fontSize: 16,
      //                                      color: Colors.black,
      //                                    ),
      //                                  ),
      //                                ],
      //                              ),
      //                              SizedBox(width: 12),
      //                              const Divider(height: 16),
      //                              Row(
      //                                mainAxisAlignment: MainAxisAlignment.spaceBetween,
      //                                children: [
      //                                  const Text(
      //                                    ' ',
      //                                    style: TextStyle(
      //                                      fontWeight: FontWeight.w700,
      //                                      fontSize: 14,
      //                                      color: Color(0xFF4F8EF7),
      //                                    ),
      //                                  ),
      //                                  Text(
      //                                    widget.invoice.totalAmountIncVat
      //                                        .toStringAsFixed(2),
      //                                    style: const TextStyle(
      //                                      fontWeight: FontWeight.w800,
      //                                      fontSize: 16,
      //                                      color: Color(0xFF4F8EF7),
      //                                    ),
      //                                  ),
      //                                ],
      //                              ),
      //                            ],
      //                          ),
                            
      //                        ),
      
            // Action Buttons
         ],
        ),
      ),
    );
  }

  Widget _buildFilters() {
    return Row(mainAxisAlignment: MainAxisAlignment.end,
      crossAxisAlignment: CrossAxisAlignment.center,
      children: [
        // Row(
        //   children: [
        //     // const Icon(
        //     //   Icons.filter_alt_outlined,
        //     //   size: 16,
        //     //   color: Color(0xFF4F8EF7),
        //     // ),
        //     // const SizedBox(width: 6),
        //     // const Text(
        //     //   'Invoice date & supplier filter',
        //     //   style: TextStyle(
        //     //     fontWeight: FontWeight.w700,
        //     //     fontSize: 13,
        //     //     color: Color(0xFF4F8EF7),
        //     //   ),
        //     // ),
        //     // const Spacer(),
        //     if (_itemFilterFrom != null ||
        //         _itemFilterTo != null ||
        //         _supplierFilter.isNotEmpty)
        //       TextButton(
        //         onPressed: () {
        //           setState(() {
        //             _itemFilterFrom = null;
        //             _itemFilterTo = null;
        //             _supplierFilter = '';
        //             _supplierController.clear();
        //             _applyInvoiceItemFilters();
        //           });
        //         },
        //         child: const Text('Clear'),
        //       ),
        //   ],
        // ),
        
        SizedBox(
          width: 150,height: 35,
          child: DateField(
            label: 'From date',
            selectedDate: _itemFilterFrom,
            onTap: () async {
              final picked = await showDatePicker(
                context: context,
                initialDate: _itemFilterFrom ?? DateTime.now(),
                firstDate: DateTime(2020),
                lastDate: DateTime.now(),
              );
              if (picked != null) {
                setState(() {
                  _itemFilterFrom = picked;
                  _applyInvoiceItemFilters();
                });
              }
            },
          ),
        ),
        const SizedBox(width: 8),
        SizedBox(
          width: 150,height: 35,
          child: DateField(
            label: 'To date',
            selectedDate: _itemFilterTo,
            onTap: () async {
              final picked = await showDatePicker(
                context: context,
                initialDate: _itemFilterTo ?? DateTime.now(),
                firstDate: DateTime(2020),
                lastDate: DateTime.now(),
              );
              if (picked != null) {
                setState(() {
                  _itemFilterTo = picked;
                  _applyInvoiceItemFilters();
                });
              }
            },
          ),
        ),
        const SizedBox(width: 8),
        Spacer(),
        SizedBox(
          width: 250,
          height: 35,
          child: TextField(
            controller: _supplierController,
            decoration: InputDecoration(
              hintText: 'Search supplier name',
              prefixIcon: const Icon(Icons.search, size: 18),
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(10),
              ),
              isDense: true,
            ),
            onChanged: (value) {
              setState(() {
                _supplierFilter = value;
                _applyInvoiceItemFilters();
              });
            },
          ),
        ),
     
      Container(height: 35, decoration: BoxDecoration(
        color: Colors.grey.shade200,
        borderRadius: BorderRadius.circular(10),border: Border.all(color: Colors.grey.shade300),
      ),

        margin: const EdgeInsets.only(left: 8),
        child: TextButton(
          onPressed: () {
            setState(() {
              _itemFilterFrom = null;
              _itemFilterTo = null;
              _supplierFilter = '';
              _supplierController.clear();
              _applyInvoiceItemFilters();
            });
          },
          child: const Text('Clear', style: TextStyle(color: Colors.black87, fontWeight: FontWeight.w600)),
        ),
      ),
      ],
    );
  }
Widget _buildDataTableWithTotals() {
  final totalExcl = _filteredInvoiceItems.fold<double>(
      0, (sum, item) => sum + item.amountExVat);
  final totalVat = _filteredInvoiceItems.fold<double>(
      0, (sum, item) => sum + item.vatAmount);
  final totalInc = _filteredInvoiceItems.fold<double>(
      0, (sum, item) => sum + item.totalIncVat);

  return Column(mainAxisAlignment: MainAxisAlignment.spaceBetween,
    children: [
      Expanded(
        child: Row(crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Expanded(
              child: SingleChildScrollView(
                scrollDirection: Axis.vertical,
                child: _buildDataTable(),
              ),
            ),
          ],
        ),
      ),

      // FIXED TOTAL ROW
      Container(
        height: 42,
        decoration: BoxDecoration(
          color: const Color(0xFFF5F6FA),
          border: Border.all(color: Colors.grey.shade300),
          borderRadius:BorderRadius.only(bottomLeft: Radius.circular(10),bottomRight: Radius.circular(10))
        ),
        child: Row(
          children: [
            _cell('Total', flex: 3, bold: true),
            _cell('', flex: 6),
            _cell('', flex: 6),
            _cell('', flex: 6),
            _cell('', flex: 6),
            _cell('', flex: 10),
            _cell(totalExcl.toStringAsFixed(2), flex: 3,bold: true),
            //  SizedBox(width: 8),
            _cell(totalVat.toStringAsFixed(2), flex: 2,bold: true),
         
            _cell(
              totalInc.toStringAsFixed(2),
              flex: 3,
              bold: true,
              color: const Color(0xFF4F8EF7),
            ),
            
          ],
        ),
      ),
    ],
  );
}

Widget _cell(String text,
    {int flex = 1, bool bold = false, Color? color}) {
  return Expanded(
    flex: flex,
    child: Padding(
      padding: const EdgeInsets.symmetric(horizontal: 8),
      child: Text(
        text,
        style: TextStyle(
          fontWeight: bold ? FontWeight.bold : FontWeight.normal,
          fontSize: 13,
          color: color,
        ),
      ),
    ),
  );
}

  Widget _buildDataTable() {
    return DataTable(
      dataRowHeight: 42,
      headingRowHeight: 42,
      columnSpacing: 12,
      border: TableBorder.all(
        color: Colors.grey.shade200,
        borderRadius: BorderRadius.circular(10),
      ),
      headingRowColor: WidgetStateProperty.all(const Color(0xFFF5F6FA)),
      columns: const [
        DataColumn(
          label: Text(
            'SL No.',
            style: TextStyle(fontWeight: FontWeight.w700, fontSize: 13),
          ),
        ),
         DataColumn(
          label: Text(
            'Id',
            style: TextStyle(fontWeight: FontWeight.w700, fontSize: 13),
          ),
        ),
        DataColumn(
          label: Text(
            'Created Date',
            style: TextStyle(fontWeight: FontWeight.w700, fontSize: 13),
          ),
        ),
        DataColumn(
          label: Text(
            'Invoice Date',
            style: TextStyle(fontWeight: FontWeight.w700, fontSize: 13),
          ),
        ),
        DataColumn(
          label: Text(
            'Supplier',
            style: TextStyle(fontWeight: FontWeight.w700, fontSize: 13),
          ),
        ),
        DataColumn(
          label: Text(
            'VAT No',
            style: TextStyle(fontWeight: FontWeight.w700, fontSize: 13),
          ),
        ),
        DataColumn(
          label: Text(
            'Invoice No',
            style: TextStyle(fontWeight: FontWeight.w700, fontSize: 13),
          ),
        ),
        DataColumn(
          label: Text(
            'Excl. Amount',
            style: TextStyle(fontWeight: FontWeight.w700, fontSize: 13),
          ),
        ),
        DataColumn(
          label: Text(
            'VAT',
            style: TextStyle(fontWeight: FontWeight.w700, fontSize: 13),
          ),
        ),
        DataColumn(
          label: Text(
            'Total',
            style: TextStyle(fontWeight: FontWeight.w700, fontSize: 13),
          ),
        ),
      ],
      rows: List.generate(_filteredInvoiceItems.length, (i) {
        final item = _filteredInvoiceItems[i];
        return DataRow(
          color: WidgetStateProperty.all(
            i.isEven ? const Color(0xFFF9FAFB) : Colors.white,
          ),
          cells: [
            DataCell(Text('${i + 1}')),
            DataCell(Text(item.id)),
            DataCell(
              Text(DateFormat('dd/MM/yyyy HH:mm:ss').format(item.createdAt)),
            ),
            DataCell(Text(DateFormat('dd/MM/yyyy').format(item.date))),
            DataCell(
              Text(
                item.supplierName,
                overflow: TextOverflow.ellipsis,
                maxLines: 2,
              ),
            ),
            DataCell(Text(item.vatNumber)),
            DataCell(Text(item.invoiceNo)),
            DataCell(Text(item.amountExVat.toStringAsFixed(2))),
            DataCell(Text(item.vatAmount.toStringAsFixed(2))),
            DataCell(
              Text(
                item.totalIncVat.toStringAsFixed(2),
                style: const TextStyle(
                  fontWeight: FontWeight.bold,
                  color: Color(0xFF4F8EF7),
                ),
              ),
            ),
          ],
        );
      }),
    );
  }
} // ── Helper widgets ────────────────────────────────────────────────────────────
class _InfoCard extends StatelessWidget {
  const _InfoCard({
    required this.title,
    required this.icon,
    required this.children,
  });
  final String title;
  final IconData icon;
  final List<Widget> children;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: Colors.grey.shade200),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(icon, size: 16, color: const Color(0xFF4F8EF7)),
              const SizedBox(width: 6),
              Text(
                title,
                style: TextStyle(
                  fontWeight: FontWeight.w700,
                  fontSize: 13,
                  color: Colors.grey.shade700,
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          ...children,
        ],
      ),
    );
  }
}

class _InfoTile extends StatelessWidget {
  const _InfoTile({required this.label, required this.value});
  final String label;
  final String value;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 8),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SizedBox(
            width: 120,
            child: Text(
              label,
              style: TextStyle(
                fontSize: 13,
                color: Colors.grey.shade500,
                fontWeight: FontWeight.w500,
              ),
            ),
          ),
          Expanded(
            child: Text(
              value,
              style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w600),
            ),
          ),
        ],
      ),
    );
  }
}
class DateField extends StatelessWidget {
  final String label;
  final DateTime? selectedDate;
  final VoidCallback onTap;

  const DateField({
    super.key,
    required this.label,
    required this.selectedDate,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 12, ),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(8),
          border: Border.all(color: Colors.grey.shade300),
        ),
        child: Center(
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                selectedDate != null
                    ? "${selectedDate!.day.toString().padLeft(2, '0')}-"
                          "${selectedDate!.month.toString().padLeft(2, '0')}-"
                          "${selectedDate!.year}"
                    : label,
                style: TextStyle(
                  fontSize: 15,
                  color: selectedDate != null ? Colors.black : Colors.grey,
                ),
              ),
              const Icon(Icons.calendar_today, size: 18, color: Colors.grey),
            ],
          ),
        ),
      ),
    );
  }
}

class _OutlineBtn extends StatelessWidget {
  const _OutlineBtn({
    required this.label,
    required this.icon,
    required this.color,
    required this.onTap,
  });
  final String label;
  final IconData icon;
  final Color color;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return OutlinedButton.icon(
      onPressed: onTap,
      icon: Icon(icon, size: 18, color: color),
      label: Text(label),
      style: OutlinedButton.styleFrom(
        foregroundColor: color,
        side: BorderSide(color: color.withOpacity(0.4)),
        padding: const EdgeInsets.symmetric(vertical: 13,horizontal: 10),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(30)),
        textStyle: const TextStyle(fontWeight: FontWeight.w600, fontSize: 14),
      ),
    );
  }
}
