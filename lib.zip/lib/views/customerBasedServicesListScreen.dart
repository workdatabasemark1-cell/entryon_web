import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:provider/provider.dart';
import '../models/customer_model.dart';
import '../models/service_model.dart';
import '../providers/service_entry_provider.dart';
import 'serviceEntryDetailsScreen.dart';

class CustomerBasedServicesListScreen extends StatelessWidget {
  final Customer customer;

  const CustomerBasedServicesListScreen({super.key, required this.customer});

  Color _statusColor(String status) {
    switch (status.toLowerCase()) {
      case 'paid':
      case 'completed':
        return Colors.green;
      case 'partial':
      case 'in progress':
        return Colors.orange;
      default:
        return Colors.redAccent;
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey.shade100,
      appBar: AppBar(
        title: Text('${customer.name} Services', style: const TextStyle(fontWeight: FontWeight.w600)),
        backgroundColor: Colors.white,
        elevation: 0,
        scrolledUnderElevation: 0,
      ),
      body: Consumer<ServiceEntryProvider>(
        builder: (context, provider, _) {
          if (provider.isLoading && provider.services.isEmpty) {
            return const Center(child: CircularProgressIndicator(color: Colors.teal));
          }

          final services = provider.services.where((service) {
            final matchesCustomer = service.customerId != null
                ? service.customerId == customer.id
                : service.customerName.toLowerCase() == customer.name.toLowerCase();
            return matchesCustomer;
          }).toList()
            ..sort((a, b) => b.serviceDate.compareTo(a.serviceDate));

          if (services.isEmpty) {
            return Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(Icons.handyman_outlined, size: 70, color: Colors.grey.shade400),
                  const SizedBox(height: 12),
                  Text('No services found for this customer', style: TextStyle(color: Colors.grey.shade600, fontSize: 16)),
                ],
              ),
            );
          }

          final totalAmount = services.fold<double>(0.0, (sum, s) => sum + s.amount);
          final totalPaidAmount = services.fold<double>(0.0, (sum, s) => sum + s.customerPaidAmount);
          final totalBalanceAmount = totalAmount - totalPaidAmount;

          return Column(
            children: [
              Expanded(
                child: ListView.builder(
                  padding: const EdgeInsets.all(12),
                  itemCount: services.length,
                  itemBuilder: (context, index) {
                    final service = services[index];
                    final balance = service.amount - service.customerPaidAmount;

                    return GestureDetector(
                      onTap: () {
                        showDialog(
                          context: context,
                          builder: (_) => Dialog(
                            insetPadding: const EdgeInsets.all(20),
                            child: SizedBox(
                              width: 700,
                              height: 900,
                              child: ServiceEntryDetailsScreen(service: service),
                            ),
                          ),
                        );
                      },
                      child: Container(
                        margin: const EdgeInsets.only(bottom: 10),
                        padding: const EdgeInsets.all(12),
                        decoration: BoxDecoration(
                          color: Colors.white,
                          borderRadius: BorderRadius.circular(10),
                          boxShadow: [
                            BoxShadow(color: Colors.black.withOpacity(0.04), blurRadius: 8, offset: const Offset(0, 3)),
                          ],
                        ),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Row(
                              children: [
                                Expanded(
                                  child: Text(
                                    service.title,
                                    style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                                    maxLines: 1,
                                    overflow: TextOverflow.ellipsis,
                                  ),
                                ),
                                Text(
                                  DateFormat('dd MMM yyyy').format(service.serviceDate),
                                  style: TextStyle(fontSize: 12, color: Colors.grey.shade500),
                                ),
                              ],
                            ),
                            const SizedBox(height: 6),
                            Text(service.customerName, style: TextStyle(color: Colors.grey.shade600, fontSize: 14)),
                            const SizedBox(height: 8),
                            Row(
                              children: [
                                _MiniChip(label: service.paymentStatus, header: 'Payment', color: _statusColor(service.paymentStatus)),
                                const SizedBox(width: 8),
                                _MiniChip(label: service.serviceStatus, header: 'Service', color: _statusColor(service.serviceStatus)),
                              ],
                            ),
                            const SizedBox(height: 8),
                            Row(
                              children: [
                                Expanded(child: _AmountBox(label: 'Total', value: service.amount)),
                                const SizedBox(width: 8),
                                Expanded(child: _AmountBox(label: 'Paid', value: service.customerPaidAmount, color: Colors.green)),
                                const SizedBox(width: 8),
                                Expanded(child: _AmountBox(label: 'Balance', value: balance, color: balance > 0 ? Colors.red : Colors.green)),
                              ],
                            ),
                          ],
                        ),
                      ),
                    );
                  },
                ),
              ),
              Container(
                width: double.infinity,
                padding: const EdgeInsets.fromLTRB(12, 10, 12, 12),
                decoration: BoxDecoration(
                  color: Colors.white,
                  border: Border(top: BorderSide(color: Colors.grey.shade200)),
                ),
                child: Row(
                  children: [
                    Expanded(child: _SummaryBox(label: 'Total Amount', value: totalAmount, color: Colors.black87)),
                    const SizedBox(width: 8),
                    Expanded(child: _SummaryBox(label: 'Total Paid', value: totalPaidAmount, color: Colors.green)),
                    const SizedBox(width: 8),
                    Expanded(child: _SummaryBox(label: 'Total Balance', value: totalBalanceAmount, color: totalBalanceAmount > 0 ? Colors.red : Colors.green)),
                  ],
                ),
              ),
            ],
          );
        },
      ),
    );
  }
}

class _MiniChip extends StatelessWidget {
  final String label;
  final String header;
  final Color color;

  const _MiniChip({required this.label, required this.header, required this.color});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
      decoration: BoxDecoration(color: color.withOpacity(0.12), borderRadius: BorderRadius.circular(8)),
      child: Column(
        children: [
          Text(header, style: TextStyle(color: Colors.black, fontSize: 11, fontWeight: FontWeight.w600)),
          Text(label, style: TextStyle(color: color, fontSize: 12, fontWeight: FontWeight.w600)),
        ],
      ),
    );
  }
}

class _AmountBox extends StatelessWidget {
  final String label;
  final double value;
  final Color? color;

  const _AmountBox({required this.label, required this.value, this.color});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 6),
      decoration: BoxDecoration(
        color: Colors.grey.shade50,
        borderRadius: BorderRadius.circular(8),
        border: Border.all(color: Colors.grey.shade200),
      ),
      child: Column(
        children: [
          Text(label, style: TextStyle(fontSize: 10, color: Colors.grey.shade600)),
          Text(value.toStringAsFixed(0), style: TextStyle(fontWeight: FontWeight.bold, color: color ?? Colors.black87)),
        ],
      ),
    );
  }
}

class _SummaryBox extends StatelessWidget {
  final String label;
  final double value;
  final Color color;

  const _SummaryBox({required this.label, required this.value, required this.color});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 8),
      decoration: BoxDecoration(
        color: Colors.grey.shade50,
        borderRadius: BorderRadius.circular(8),
        border: Border.all(color: Colors.grey.shade200),
      ),
      child: Column(
        children: [
          Text(label, style: TextStyle(fontSize: 10, color: Colors.grey.shade600)),
          const SizedBox(height: 2),
          Text(value.toStringAsFixed(2), style: TextStyle(fontWeight: FontWeight.bold, color: color, fontSize: 13)),
        ],
      ),
    );
  }
}
