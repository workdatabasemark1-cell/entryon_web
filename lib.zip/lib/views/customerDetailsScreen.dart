import 'package:entryon/views/customerBasedServicesListScreen.dart';
import 'package:entryon/views/customerTransactionsListScreen.dart';
import 'package:entryon/views/customerwiseMakeTransactionScreen.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../models/customer_model.dart';

class CustomerDetailsScreen extends StatelessWidget {
  final Customer customer;

  const CustomerDetailsScreen({super.key, required this.customer});

  @override
  Widget build(BuildContext context) {
    final sections = <_DetailSectionData>[
      _DetailSectionData(
        title: 'Basic Info',
        items: [
          _DetailItem(label: 'Name', value: customer.name),
          _DetailItem(label: 'Phone', value: customer.phone),
          if ((customer.phone2 ?? '').isNotEmpty) _DetailItem(label: 'Alt Phone', value: customer.phone2!),
          if ((customer.email ?? '').isNotEmpty) _DetailItem(label: 'Email', value: customer.email!),
          _DetailItem(label: 'Tax Number', value: customer.taxNumber),
          if ((customer.crNumber ?? '').isNotEmpty) _DetailItem(label: 'CR Number', value: customer.crNumber!),
          _DetailItem(label: 'ZATCA Enabled', value: customer.zatcaEnabled == true ? 'Yes' : 'No'),
        ],
      ),
      _DetailSectionData(
        title: 'Organization',
        items: [
          if ((customer.organizationName ?? '').isNotEmpty) _DetailItem(label: 'Organization', value: customer.organizationName!),
          if ((customer.organizationUnitName ?? '').isNotEmpty) _DetailItem(label: 'Unit', value: customer.organizationUnitName!),
          if ((customer.commonName ?? '').isNotEmpty) _DetailItem(label: 'Common Name', value: customer.commonName!),
          if ((customer.businessCategory ?? '').isNotEmpty) _DetailItem(label: 'Category', value: customer.businessCategory!),
        ],
      ),
      _DetailSectionData(
        title: 'Address',
        items: [
          if ((customer.address ?? '').isNotEmpty) _DetailItem(label: 'Address', value: customer.address),
          if ((customer.registeredAddress ?? '').isNotEmpty) _DetailItem(label: 'Registered Address', value: customer.registeredAddress!),
          if ((customer.buildingNo ?? '').isNotEmpty) _DetailItem(label: 'Building No.', value: customer.buildingNo!),
          if ((customer.streetName ?? '').isNotEmpty) _DetailItem(label: 'Street', value: customer.streetName!),
          if ((customer.districtName ?? '').isNotEmpty) _DetailItem(label: 'District', value: customer.districtName!),
          if ((customer.cityName ?? '').isNotEmpty) _DetailItem(label: 'City', value: customer.cityName!),
          if ((customer.zipCode ?? '').isNotEmpty) _DetailItem(label: 'ZIP Code', value: customer.zipCode!),
          if ((customer.country ?? '').isNotEmpty) _DetailItem(label: 'Country', value: customer.country!),
        ],
      ),
      _DetailSectionData(
        title: 'Software',
        items: [
          if (customer.usedSoftwares.isNotEmpty)
            _DetailItem(label: 'Used Softwares', value: customer.usedSoftwares.join(', ')),
          if (customer.softwareActivations.isNotEmpty)
            _DetailItem(label: 'Activations', value: '${customer.softwareActivations.length} configured'),
        ],
      ),
    ];

    return Scaffold(
      backgroundColor: Colors.grey.shade100,
      appBar: AppBar(
        title: const Text('Customer Details', style: TextStyle(fontWeight: FontWeight.w600)),
        backgroundColor: Colors.white,
        elevation: 0,
        scrolledUnderElevation: 0,
        centerTitle: true,
      ),
      body: Column(
        children: [
          Expanded(
            child: SingleChildScrollView(
              padding: const EdgeInsets.all(12),
              child: Column(
                children: [
                  Container(
                    width: double.infinity,
                    padding: const EdgeInsets.all(16),
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(14),
                      boxShadow: [
                        BoxShadow(color: Colors.black.withOpacity(0.04), blurRadius: 10, offset: const Offset(0, 4)),
                      ],
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          children: [
                            CircleAvatar(
                              radius: 28,
                              backgroundColor: Colors.teal.withOpacity(0.12),
                              child: const Icon(Icons.person, color: Colors.teal, size: 28),
                            ),
                            const SizedBox(width: 12),
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(customer.name, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
                                  const SizedBox(height: 4),
                                  Text(customer.phone.isEmpty ? 'No phone provided' : customer.phone, style: TextStyle(color: Colors.grey.shade600)),
                                ],
                              ),
                            ),
                          ],
                        ),
                        const SizedBox(height: 12),
                        if (customer.createdAt != null)
                          Text('Created: ${DateFormat('dd MMM yyyy').format(customer.createdAt!)}', style: TextStyle(color: Colors.grey.shade600)),
                        const SizedBox(height: 12),
                     ],
                    ),
                  ),
                  const SizedBox(height: 12),
                  ...sections.where((section) => section.items.isNotEmpty).map((section) => _SectionCard(title: section.title, items: section.items)),
                ],
              ),
            ),
          ),
              Container(  padding: const EdgeInsets.all(10),
                color: Colors.grey.shade100,
                child: Row(
                      children: [
                        Expanded(
                          child: ElevatedButton.icon(
                            onPressed: () {
                              showDialog(
                                context: context,
                                builder: (_) => Dialog(
                                  insetPadding: const EdgeInsets.all(20),
                                  child: SizedBox(
                                    width: 600,
                                    height: 900,
                                    child: CustomerwiseMakeTransactionScreen(customer: customer),
                                  ),
                                ),
                              );
                            },
                            icon: const Icon(Icons.payment_outlined),
                            label: const Text('Make Payment'),
                            style: ElevatedButton.styleFrom(
                              
                              backgroundColor: Colors.teal,
                              foregroundColor: Colors.white,
                              padding: const EdgeInsets.symmetric(vertical: 12),
                            ),
                          ),
                        ),
                        const SizedBox(width: 10),
                        Expanded(
                          child: OutlinedButton.icon(
                            onPressed: () {
                              showDialog(
                                context: context,
                                builder: (_) => Dialog(
                                  insetPadding:  EdgeInsets.all(20),
                                  child: SizedBox(
                                    width: 600,
                                    height: 900,
                                    child: CustomerTransactionsListScreen(customerName: customer.name, customerId: customer.id),
                                  ),
                                ),
                              );
                            },
                            icon: const Icon(Icons.list_alt),
                            label: const Text('View Transactions'),
                            style: OutlinedButton.styleFrom(
                              padding: const EdgeInsets.symmetric(vertical: 12),
                            ),
                          ),
                        ),
                        const SizedBox(width: 10),
                        Expanded(
                          child: OutlinedButton.icon(
                            onPressed: () {
                              showDialog(
                                context: context,
                                builder: (_) => Dialog(
                                  insetPadding: const EdgeInsets.all(20),
                                  child: SizedBox(
                                    width: 600,
                                    height: 900,
                                    child: CustomerBasedServicesListScreen(customer: customer),
                                  ),
                                ),
                              );
                            },
                            icon: const Icon(Icons.list_alt),
                            label: const Text('View Services'),
                            style: OutlinedButton.styleFrom(
                              padding: const EdgeInsets.symmetric(vertical: 12),
                            ),
                          ),
                        ),
                      ],
                    ),
              ),
               
        ],
      ),
    );
  }
}

class _SectionCard extends StatelessWidget {
  final String title;
  final List<_DetailItem> items;

  const _SectionCard({super.key, required this.title, required this.items});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(14),
      margin: const EdgeInsets.only(bottom: 12),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12),
        boxShadow: [
          BoxShadow(color: Colors.black.withOpacity(0.04), blurRadius: 8, offset: const Offset(0, 3)),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(title, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w700)),
          const SizedBox(height: 8),
          ...items.map((item) => Padding(
                padding: const EdgeInsets.only(bottom: 8),
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    SizedBox(
                      width: 120,
                      child: Text(item.label, style: TextStyle(color: Colors.grey.shade600)),
                    ),
                    Expanded(child: Text(item.value, style: const TextStyle(fontWeight: FontWeight.w500))),
                  ],
                ),
              )),
        ],
      ),
    );
  }
}

class _DetailItem {
  final String label;
  final String value;

  const _DetailItem({required this.label, required this.value});
}

class _DetailSectionData {
  final String title;
  final List<_DetailItem> items;

  const _DetailSectionData({required this.title, required this.items});
}
