import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:intl/intl.dart';
import '../models/service_model.dart';
import '../models/transaction_model.dart';
import '../providers/service_entry_provider.dart';
import '../providers/transaction_provider.dart';

class ServicewiseMakeTransactionScreen extends StatefulWidget {
  final ServiceEntry service;

  const ServicewiseMakeTransactionScreen({super.key, required this.service});

  @override
  State<ServicewiseMakeTransactionScreen> createState() =>
      _ServicewiseMakeTransactionScreenState();
}

class _ServicewiseMakeTransactionScreenState
    extends State<ServicewiseMakeTransactionScreen> {
  late ServiceEntry _service;

  @override
  void initState() {
    super.initState();
    _service = widget.service;
  }

  Future<void> _showPaymentDialog(BuildContext context) async {
    final amountController =
        TextEditingController(text: _service.balanceAmount.toStringAsFixed(2));
    String paymentType = 'Cash';
    final cardNumberController = TextEditingController();
    final formKey = GlobalKey<FormState>();

    final result = await showDialog<bool>(
      context: context,
      builder: (dialogContext) {
        return StatefulBuilder(
          builder: (context, setDialogState) {
            return AlertDialog(
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
              title: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    'Record Payment',
                    style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    _service.title,
                    style: TextStyle(
                      fontSize: 14,
                      color: Colors.grey.shade600,
                      fontWeight: FontWeight.w400,
                    ),
                  ),
                ],
              ),
              content: Form(
                key: formKey,
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    // Balance highlight
                    Container(
                      width: double.infinity,
                      padding: const EdgeInsets.all(12),
                      decoration: BoxDecoration(
                        color: Colors.orange.shade50,
                        borderRadius: BorderRadius.circular(10),
                        border: Border.all(color: Colors.orange.shade200),
                      ),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text('Outstanding Balance',
                              style: TextStyle(color: Colors.grey.shade700)),
                          Text(
                            _service.balanceAmount.toStringAsFixed(2),
                            style: const TextStyle(
                              fontWeight: FontWeight.bold,
                              color: Colors.orange,
                              fontSize: 16,
                            ),
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(height: 16),

                    TextFormField(
                      controller: amountController,
                      keyboardType:
                          const TextInputType.numberWithOptions(decimal: true),
                      decoration: _dialogInputDecoration('Amount to Pay'),
                      validator: (v) {
                        final val = double.tryParse(v ?? '0') ?? 0;
                        if (val <= 0) return 'Enter a valid amount';
                        if (val > _service.balanceAmount) {
                          return 'Cannot exceed balance';
                        }
                        return null;
                      },
                    ),
                    const SizedBox(height: 14),

                    DropdownButtonFormField<String>(
                      value: paymentType,
                      decoration: _dialogInputDecoration('Payment Type'),
                      items: const [
                        DropdownMenuItem(value: 'Cash', child: Text('Cash')),
                        DropdownMenuItem(value: 'Card', child: Text('Card')),
                      ],
                      onChanged: (v) {
                        setDialogState(() => paymentType = v ?? 'Cash');
                      },
                    ),

                    if (paymentType == 'Card') ...[
                      const SizedBox(height: 14),
                      TextFormField(
                        controller: cardNumberController,
                        keyboardType: TextInputType.number,
                        decoration: _dialogInputDecoration('Card Number'),
                        validator: (v) {
                          if (paymentType == 'Card' &&
                              (v == null || v.trim().isEmpty)) {
                            return 'Enter card number';
                          }
                          return null;
                        },
                      ),
                    ],
                  ],
                ),
              ),
              actionsPadding: const EdgeInsets.fromLTRB(16, 0, 16, 16),
              actions: [
                TextButton(
                  onPressed: () => Navigator.pop(dialogContext, false),
                  child: Text('Cancel',
                      style: TextStyle(color: Colors.grey.shade600)),
                ),
                ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.teal,
                    foregroundColor: Colors.white,
                    elevation: 0,
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(10)),
                    padding: const EdgeInsets.symmetric(
                        horizontal: 20, vertical: 12),
                  ),
                  onPressed: () async {
                    if (!formKey.currentState!.validate()) return;

                    final amt =
                        double.tryParse(amountController.text.trim()) ?? 0;
                    final balanceAfterPayment = _service.balanceAmount - amt;

                    final txn = TransactionModel(
                      id: DateTime.now().millisecondsSinceEpoch.toString(),
                      serviceId: _service.id,
                      customerId: _service.customerId,
                      customerName: _service.customerName,
                      amount: amt,
                      balanceAmount: balanceAfterPayment,
                      paymentType: paymentType,
                      paymentDetails: {
                        if (paymentType == 'Card')
                          'cardNumber': cardNumberController.text.trim(),
                        'balanceAmount': balanceAfterPayment,
                      },
                      createdAt: DateTime.now(),
                    );

                    final ok = await context
                        .read<TransactionProvider>()
                        .addTransaction(txn);

                    if (ok) {
                      final newPaid = _service.customerPaidAmount + amt;
                      final newStatus =
                          newPaid >= _service.amount ? 'Paid' : 'Partial';

                      await context.read<ServiceEntryProvider>().updateService(
                        paymentType: _service.paymentType,
                            id: _service.id,
                            title: _service.title,
                            customerName: _service.customerName,
                            customerId: _service.customerId,
                            description: _service.description,
                            serviceDate: _service.serviceDate,
                            amount: _service.amount,
                            serviceFee: _service.serviceFee,
                            customerPaidAmount: newPaid,
                            paymentStatus: newStatus,
                            serviceStatus: _service.serviceStatus,
                            paymentExpiryDate: _service.paymentExpiryDate,
                            purchaseLines: _service.purchaseLines,
                          );

                      if (dialogContext.mounted) {
                        Navigator.pop(dialogContext, true);
                      }
                    } else {
                      if (dialogContext.mounted) {
                        Navigator.pop(dialogContext, false);
                      }
                    }
                  },
                  child: const Text('Confirm Payment'),
                ),
              ],
            );
          },
        );
      },
    );

    if (result == true && mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Payment recorded successfully'),
          backgroundColor: Colors.green,
          behavior: SnackBarBehavior.floating,
        ),
      );

      // Refresh local service data
      await context.read<ServiceEntryProvider>().fetchServices();
      final updated = context
          .read<ServiceEntryProvider>()
          .services
          .where((s) => s.id == _service.id)
          .toList();

      if (updated.isNotEmpty) {
        setState(() => _service = updated.first);
      }

      await context.read<TransactionProvider>().fetchTransactions();
    }
  }

  InputDecoration _dialogInputDecoration(String label) {
    return InputDecoration(
      labelText: label,
      filled: true,
      fillColor: Colors.grey.shade50,
      isDense: true,
      contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 14),
      border: OutlineInputBorder(
        borderRadius: BorderRadius.circular(10),
        borderSide: BorderSide(color: Colors.grey.shade300),
      ),
      enabledBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(10),
        borderSide: BorderSide(color: Colors.grey.shade300),
      ),
      focusedBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(10),
        borderSide: const BorderSide(color: Colors.teal, width: 1.5),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final balance = _service.amount - _service.customerPaidAmount;
    final paidPercent = _service.amount > 0
        ? (_service.customerPaidAmount / _service.amount).clamp(0.0, 1.0)
        : 0.0;
    final isFullyPaid = balance <= 0;

    return Scaffold(
      backgroundColor: Colors.grey.shade100,
      appBar: AppBar(
        title: const Text(
          'Service Payment',
          style: TextStyle(fontWeight: FontWeight.w600),
        ),
        backgroundColor: Colors.white,
        elevation: 0,
        scrolledUnderElevation: 0,
        centerTitle: true,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            // ── Header Card ─────────────────────────────────────────────
            Container(
              width: double.infinity,
              padding: const EdgeInsets.all(20),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(16),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withOpacity(0.04),
                    blurRadius: 8,
                    offset: const Offset(0, 3),
                  ),
                ],
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Expanded(
                        child: Text(
                          _service.title,
                          style: const TextStyle(
                            fontSize: 20,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ),
                      _StatusChip(label: _service.paymentStatus),
                    ],
                  ),
                  const SizedBox(height: 8),
                  Row(
                    children: [
                      Icon(Icons.person_outline,
                          size: 16, color: Colors.grey.shade600),
                      const SizedBox(width: 6),
                      Text(
                        _service.customerName,
                        style: TextStyle(
                          fontSize: 14,
                          color: Colors.grey.shade600,
                        ),
                      ),
                    ],
                  ),
                  if (_service.serviceDate != null) ...[
                    const SizedBox(height: 4),
                    Row(
                      children: [
                        Icon(Icons.calendar_today_outlined,
                            size: 14, color: Colors.grey.shade500),
                        const SizedBox(width: 6),
                        Text(
                          DateFormat('dd MMM yyyy').format(_service.serviceDate),
                          style: TextStyle(
                            fontSize: 13,
                            color: Colors.grey.shade500,
                          ),
                        ),
                      ],
                    ),
                  ],
                ],
              ),
            ),

            const SizedBox(height: 16),

            // ── Financial Summary ───────────────────────────────────────
            Container(
              width: double.infinity,
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(16),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withOpacity(0.04),
                    blurRadius: 8,
                    offset: const Offset(0, 3),
                  ),
                ],
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    'Payment Summary',
                    style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                  ),
                  const SizedBox(height: 16),

                  Row(
                    children: [
                      _AmountBox(label: 'Total', value: _service.amount),
                      const SizedBox(width: 10),
                      _AmountBox(
                        label: 'Paid',
                        value: _service.customerPaidAmount,
                        color: Colors.green,
                      ),
                      const SizedBox(width: 10),
                      _AmountBox(
                        label: 'Balance',
                        value: balance,
                        color: isFullyPaid ? Colors.green : Colors.orange,
                      ),
                    ],
                  ),

                  const SizedBox(height: 16),

                  // Progress bar
                  ClipRRect(
                    borderRadius: BorderRadius.circular(4),
                    child: LinearProgressIndicator(
                      value: paidPercent,
                      minHeight: 8,
                      backgroundColor: Colors.grey.shade200,
                      color: isFullyPaid ? Colors.green : Colors.teal,
                    ),
                  ),
                  const SizedBox(height: 6),
                  Text(
                    '${(paidPercent * 100).toStringAsFixed(0)}% paid',
                    style: TextStyle(fontSize: 12, color: Colors.grey.shade500),
                  ),
                ],
              ),
            ),

            const SizedBox(height: 16),

            // ── Status message or Pay button ────────────────────────────
            if (isFullyPaid)
              Container(
                width: double.infinity,
                padding: const EdgeInsets.all(20),
                decoration: BoxDecoration(
                  color: Colors.green.shade50,
                  borderRadius: BorderRadius.circular(16),
                  border: Border.all(color: Colors.green.shade200),
                ),
                child: Column(
                  children: [
                    Icon(Icons.check_circle,
                        size: 48, color: Colors.green.shade400),
                    const SizedBox(height: 12),
                    const Text(
                      'Fully Paid',
                      style: TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.bold,
                        color: Colors.green,
                      ),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      'This service has no outstanding balance',
                      style: TextStyle(
                        fontSize: 13,
                        color: Colors.grey.shade600,
                      ),
                    ),
                  ],
                ),
              )
            else
              SizedBox(
                width: double.infinity,
                height: 50,
                child: ElevatedButton.icon(
                  onPressed: () => _showPaymentDialog(context),
                  icon: const Icon(Icons.payment_outlined, size: 20),
                  label: const Text(
                    'Make Payment',
                    style: TextStyle(fontSize: 16, fontWeight: FontWeight.w600),
                  ),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.teal,
                    foregroundColor: Colors.white,
                    elevation: 0,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                  ),
                ),
              ),
          ],
        ),
      ),
    );
  }
}

// ── Helper Widgets ────────────────────────────────────────────────────────

class _StatusChip extends StatelessWidget {
  final String label;
  const _StatusChip({required this.label});

  Color get _color {
    switch (label.toLowerCase()) {
      case 'paid':
        return Colors.green;
      case 'partial':
        return Colors.orange;
      default:
        return Colors.redAccent;
    }
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
      decoration: BoxDecoration(
        color: _color.withOpacity(0.12),
        borderRadius: BorderRadius.circular(20),
      ),
      child: Text(
        label,
        style: TextStyle(color: _color, fontSize: 12, fontWeight: FontWeight.w600),
      ),
    );
  }
}

class _AmountBox extends StatelessWidget {
  final String label;
  final double value;
  final Color? color;

  const _AmountBox({required this.label, required this.value, this.color});

  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 12),
        decoration: BoxDecoration(
          color: Colors.grey.shade50,
          borderRadius: BorderRadius.circular(10),
          border: Border.all(color: Colors.grey.shade200),
        ),
        child: Column(
          children: [
            Text(label,
                style: TextStyle(fontSize: 11, color: Colors.grey.shade600)),
            const SizedBox(height: 4),
            Text(
              value.toStringAsFixed(0),
              style: TextStyle(
                fontWeight: FontWeight.bold,
                fontSize: 15,
                color: color ?? Colors.black87,
              ),
            ),
          ],
        ),
      ),
    );
  }
}