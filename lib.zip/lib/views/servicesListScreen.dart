import 'package:entryon/models/service_model.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:intl/intl.dart';
import '../providers/service_entry_provider.dart';
import '../utils/date_utils.dart';
import 'createServiceEntryScreen.dart';
import 'editServiceEntryScreen.dart';
import 'serviceEntryDetailsScreen.dart';
import 'makeTransactionScreen.dart';
import 'transactionListScreen.dart';

class ServicesListScreen extends StatefulWidget {
  const ServicesListScreen({super.key});

  @override
  State<ServicesListScreen> createState() => _ServicesListScreenState();
}

class _ServicesListScreenState extends State<ServicesListScreen> {
  final TextEditingController _searchController = TextEditingController();
  DateTime? _fromDate;
  DateTime? _toDate;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      context.read<ServiceEntryProvider>().fetchServices();
    });
  }

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  Future<void> _pickDateRange() async {
    final now = DateTime.now();
    final initialStart = _fromDate ?? now.subtract(const Duration(days: 30));
    final initialEnd = _toDate ?? now;

    final picked = await showDateRangePicker(
      context: context,
      firstDate: DateTime(2020),
      lastDate: DateTime(2100),
      initialDateRange: DateTimeRange(start: initialStart, end: initialEnd),
    );

    if (picked != null) {
      setState(() {
        _fromDate = picked.start;
        _toDate = picked.end;
      });
    }
  }

  List<ServiceEntry> _filteredServices(List<ServiceEntry> services) {
    final query = _searchController.text.trim().toLowerCase();
    final start = _fromDate;
    final end = _toDate;

    return services.where((service) {
      final matchesName = query.isEmpty || service.customerName.toLowerCase().contains(query);
      final matchesDate = isDateWithinRange(service.serviceDate, start, end);
      return matchesName && matchesDate;
    }).toList();
  }

  Color _statusColor(String status) {
    switch (status.toLowerCase()) {
      case 'paid':
      case 'completed':
        return Colors.green;
      case 'partial':
      case 'in progress':
        return Colors.orange;
      default:
        return Colors.redAccent;
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey.shade100,
      appBar: AppBar(
        title: const Text('Services', style: TextStyle(fontWeight: FontWeight.w600)),
        backgroundColor: Colors.white,
        elevation: 0,
        actions: [
             IconButton(
              icon: const Icon(Icons.refresh, color: Colors.teal),
              tooltip: 'Refresh',
              onPressed: () async {
                await context.read<ServiceEntryProvider>().fetchServices();
              },
            ),
             Padding(
                padding: const EdgeInsets.fromLTRB(10, 10, 10, 10),
                child: Row(
                  children: [
                    SizedBox(width: 250,height: 35,
                      child: TextField(
                        controller: _searchController,
                        onChanged: (_) => setState(() {}),
                        decoration: InputDecoration(
                          hintText: 'Search by customer name',
                          prefixIcon: const Icon(Icons.search),
                          filled: true,isDense: true,
                          contentPadding: const EdgeInsets.symmetric(vertical: 0, horizontal: 5),
                          fillColor: Colors.white,
                          focusColor: Colors.white,
                          hoverColor: Colors.white,
                         border: OutlineInputBorder(borderRadius: BorderRadius.circular(10), borderSide: BorderSide.none),
                        ),
                      ),
                    ),
                   
                    const SizedBox(height: 4),
                    Container(
  width: 150,
  padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 7.5),
  decoration: BoxDecoration(
    border: Border.all(color: Colors.grey.shade400),
    borderRadius: BorderRadius.circular(8),
  ),
  child: InkWell(
    onTap: _pickDateRange,
    child: Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        const Icon(Icons.calendar_today_outlined, size: 18),
        const SizedBox(width: 8),
        Expanded(
          child: Text(
            _fromDate == null && _toDate == null
                ? 'Filter by date'
                : '${_fromDate != null ? DateFormat('dd MMM').format(_fromDate!) : ""}'
                  '${_fromDate != null && _toDate != null ? ' - ' : ''}'
                  '${_toDate != null ? DateFormat('dd MMM').format(_toDate!) : ""}',
            overflow: TextOverflow.ellipsis,
          ),
        ),
      ],
    ),
  ),
),

                    if (_searchController.text.trim().isNotEmpty || _fromDate != null || _toDate != null)
                      Row(
                        children: [ const SizedBox(width: 8),
                          Container(
                            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 7.5),
                            decoration: BoxDecoration(
                              color: Colors.black.withOpacity(0.08),
                              borderRadius: BorderRadius.circular(8),
                            ),
                            child: InkWell(
                              onTap: () => setState(() {
                                _searchController.clear();
                                _fromDate = null;
                                _toDate = null;
                              }),
                              child: const Text(
                                'Reset',
                                style: TextStyle(color: Colors.black),
                              ),
                            ),
                          ),
                        ],
                      ),
                      SizedBox(width: 8),

 Container(
  padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4.5),
  decoration: BoxDecoration(
    color: Colors.teal.withOpacity(0.12),
    borderRadius: BorderRadius.circular(10),
    border: Border.all(color: Colors.teal),
  ),
  child: GestureDetector(
       onTap: () {
       showDialog(
  context: context,
  builder: (_) => Dialog(
    insetPadding: const EdgeInsets.all(10),
    child: SizedBox(
      width: 600,
      height: 900,
      child: CreateServiceEntryScreen(),
    ),
  ),
);
if (mounted) {
        context.read<ServiceEntryProvider>().fetchServices();
      }
       },
    child: Row(
      mainAxisSize: MainAxisSize.min,
      children: const [
        Icon(Icons.add_circle_outline, color: Colors.teal),
        SizedBox(width: 8),
        Text(
          'Add Service',
          style: TextStyle(
            color: Colors.teal,
            fontWeight: FontWeight.w600,
          ),
        ),
      ],
    ),
  ),
)

                  ],
                ),
              ),
          
          // IconButton(
          //   icon: const Icon(Icons.receipt_long, color: Colors.teal),
          //   onPressed: () async {
          //     await Navigator.push(context, MaterialPageRoute(builder: (_) => const TransactionsListScreen()));
          //     if (mounted) context.read<ServiceEntryProvider>().fetchServices();
          //   },
          // ),
          // IconButton(
          //   icon: const Icon(Icons.payment, color: Colors.teal),
          //   onPressed: () async {
          //     await Navigator.push(context, MaterialPageRoute(builder: (_) => const MakeTransactionScreen()));
          //     if (mounted) context.read<ServiceEntryProvider>().fetchServices();
          //   },
          // ),
        
        ],
      ),
      body: Column(
        children: [
         Expanded(
            child: Consumer<ServiceEntryProvider>(
              builder: (context, provider, _) {
                if (provider.isLoading && provider.services.isEmpty) {
                  return const Center(child: CircularProgressIndicator(color: Colors.teal));
                }
            
                final filteredServices = _filteredServices(provider.services);
            
                if (filteredServices.isEmpty) {
                  return Center(
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(Icons.handyman_outlined, size: 70, color: Colors.grey.shade400),
                        const SizedBox(height: 16),
                        Text('No services found', style: TextStyle(color: Colors.grey.shade600, fontSize: 16)),
                      ],
                    ),
                  );
                }
            
                return Column(
                  children: [
                  
                    Expanded(
                      child: GridView.builder(
  padding: const EdgeInsets.fromLTRB(10, 10, 10, 10),
  itemCount: filteredServices.length,
  gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
    crossAxisCount: 3,
    mainAxisSpacing: 10,
    crossAxisSpacing: 10,
    mainAxisExtent:111, // adjust height ratio
  ),
  itemBuilder: (context, index) {
    final service = filteredServices[index];
    final balance = service.balanceAmount;

    return GestureDetector(
       onTap: () {
       showDialog(
  context: context,
  builder: (_) => Dialog(
    insetPadding: const EdgeInsets.all(20),
    child: SizedBox(
      width: 700,
      height: 900,
      child: ServiceEntryDetailsScreen(service: service),
    ),
  ),
);

       },
      child: Container(
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(10),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.04),
              blurRadius: 8,
              offset: const Offset(0, 3),
            )
          ],
        ),
        child: Material(
          color: Colors.transparent,
          child: Padding(
            padding: const EdgeInsets.all(10),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Expanded(
                      child: Column(crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            service.title,
                            style: const TextStyle(
                              fontSize: 17,
                              fontWeight: FontWeight.bold,
                            ),
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                          ),
                            Text(
                          service.customerName,
                          style: TextStyle(color: Colors.grey.shade600, fontSize: 14, fontWeight: FontWeight.w600),
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                        ),
                        ],
                      ),
                    ),
                    Text(
                  DateFormat('dd MMM yyyy').format(service.serviceDate),
                  style: TextStyle(fontSize: 12, color: Colors.grey.shade500),
                ),
                    PopupMenuButton<String>(color: Colors.white,
                      onSelected: (value) async {
                       
                        if (value == 'edit') {
                           showDialog(
  context: context,
  builder: (_) => Dialog(
    insetPadding: const EdgeInsets.all(20),
    child: SizedBox(
      width: 600,
      height: 900,
      child: EditServiceEntryScreen(serviceId: service.id),
    ),
  ),
);
                          if (mounted) provider.fetchServices();
                        } else if (value == 'delete') {
                          final confirmed = await showDialog<bool>(
                            context: context,
                            builder: (_) => AlertDialog(
                              title: const Text('Delete Service'),
                              content: const Text(
                                  'Are you sure you want to delete this service?'),
                              actions: [
                                TextButton(
                                  onPressed: () =>
                                      Navigator.pop(context, false),
                                  child: const Text('Cancel'),
                                ),
                                TextButton(
                                  onPressed: () =>
                                      Navigator.pop(context, true),
                                  child: const Text(
                                    'Delete',
                                    style: TextStyle(color: Colors.red),
                                  ),
                                ),
                              ],
                            ),
                          );
                          if (confirmed == true) {
                            await provider.deleteService(service.id);
                          }
                        }
                      },
                      itemBuilder: (_) => [
                        const PopupMenuItem(
                          value: 'edit',
                          child: Text('Edit'),
                        ),
                        const PopupMenuItem(
                          value: 'delete',
                          child: Text(
                            'Delete',
                            style: TextStyle(color: Colors.red),
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
          
                // const SizedBox(height: 4),
                Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, crossAxisAlignment: CrossAxisAlignment.end,
                  children: [
                    Column(crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
          
                        // Text(
                        //   service.customerName,
                        //   style: TextStyle(color: Colors.grey.shade600),
                        //   maxLines: 1,
                        //   overflow: TextOverflow.ellipsis,
                        // ),
                       
                         
                        //  const SizedBox(height: 1),
                        Row(
                          children: [
                            _MiniChip(
                              header: 'Payment Status',
                              label: service.paymentStatus,
                              color: _statusColor(service.paymentStatus),
                            ),
                            const SizedBox(width: 8),
                            _MiniChip(
                              header: 'Service Status',
                              label: service.serviceStatus,
                              color: _statusColor(service.serviceStatus),
                            ),
                          ],
                        ),
                      ],
                    ),
                  
                    Row(
                  children: [
                    Container(width: 100,
                      child: _AmountBox(
                        label: 'Total',
                        value: service.amount,
                      ),
                    ),
                    const SizedBox(width: 6),
                    Container(width: 100,
                      child: _AmountBox(
                        label: 'Paid',
                        value: service.customerPaidAmount,
                        color: Colors.green,
                      ),
                    ),
                      const SizedBox(width: 6),
                Container(width: 100,
                  child: _AmountBox(
                    label: 'Balance',
                    value: balance,
                    color: balance > 0 ? Colors.red : Colors.green,
                  ),
                ),
                  ],
                ),
                  ],
                ),
          
              
              ],
            ),
          ),
        ),
      ),
    );
  },
)
 ),
                  ],
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}

class _MiniChip extends StatelessWidget {
  final String label;
  final String header;
  final Color color;
  const _MiniChip({required this.label, required this.header, required this.color});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 3),
      decoration: BoxDecoration(color: color.withOpacity(0.12), borderRadius: BorderRadius.circular(8)),
      child: Column(
        children: [
          Text(header, style: TextStyle(color: Colors.black, fontSize: 12, fontWeight: FontWeight.w600)),
          Text(label, style: TextStyle(color: color, fontSize: 12, fontWeight: FontWeight.w600)),
        ],
      ),
    );
  }
}

class _AmountBox extends StatelessWidget {
  final String label;
  final double value;
  final Color? color;
  const _AmountBox({required this.label, required this.value, this.color});

  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: Container(
         padding: const EdgeInsets.symmetric(vertical: 4.5),
        decoration: BoxDecoration(
          color: Colors.grey.shade50,
          borderRadius: BorderRadius.circular(10),
          border: Border.all(color: Colors.grey.shade200),
        ),
        child: Column(
          children: [
            Text(label, style: TextStyle(fontSize: 11, color: Colors.grey.shade600)),
            // const SizedBox(height: 1),
            Text(value.toStringAsFixed(0), style: TextStyle(fontWeight: FontWeight.bold, color: color ?? Colors.black87)),
          ],
        ),
      ),
    );
  }
}