import 'package:entryon/providers/service_entry_provider.dart';
import 'package:entryon/providers/transaction_provider.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:provider/provider.dart';

class ServiceTransactionsListScreen extends StatelessWidget {
  final String serviceId;

  const ServiceTransactionsListScreen({super.key, required this.serviceId});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey.shade100,
      appBar: AppBar(
        title: const Text('Service Transactions', style: TextStyle(fontWeight: FontWeight.w600)),
        backgroundColor: Colors.white,
        elevation: 0,
        scrolledUnderElevation: 0,
      ),
      body: Consumer<TransactionProvider>(
        builder: (context, provider, _) {
          if (provider.isLoading && provider.transactions.isEmpty) {
            return const Center(child: CircularProgressIndicator(color: Colors.teal));
          }

          final transactions = provider.transactions
              .where((txn) => txn.serviceId.toLowerCase() == serviceId.toLowerCase())
              .toList()
            ..sort((a, b) => b.createdAt.compareTo(a.createdAt));

          final matchingService = context.read<ServiceEntryProvider>().services.firstWhere(
            (service) => service.id.toLowerCase() == serviceId.toLowerCase(),
            orElse: () => null as dynamic,
          );

          final totalAmount = matchingService != null
              ? matchingService.amount
              : transactions.fold<double>(0.0, (sum, txn) => sum + txn.amount);
          final totalPaidAmount = matchingService != null
              ? matchingService.customerPaidAmount
              : transactions.fold<double>(0.0, (sum, txn) => sum + txn.amount);
          final totalBalanceAmount = totalAmount - totalPaidAmount;

          if (transactions.isEmpty) {
            return Column(
              children: [
                Expanded(
                  child: Center(
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(Icons.receipt_long_outlined, size: 70, color: Colors.grey.shade400),
                        const SizedBox(height: 12),
                        Text('No transactions found for this service', style: TextStyle(color: Colors.grey.shade600, fontSize: 16)),
                      ],
                    ),
                  ),
                ),
                Container(
                  width: double.infinity,
                  padding: const EdgeInsets.fromLTRB(12, 10, 12, 12),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    border: Border(top: BorderSide(color: Colors.grey.shade200)),
                  ),
                  child: Row(
                    children: [
                      Expanded(child: _SummaryBox(label: 'Total Amount', value: totalAmount, color: Colors.black87)),
                      const SizedBox(width: 8),
                      Expanded(child: _SummaryBox(label: 'Total Paid', value: totalPaidAmount, color: Colors.green)),
                      const SizedBox(width: 8),
                      Expanded(child: _SummaryBox(label: 'Balance Amount', value: totalBalanceAmount, color: totalBalanceAmount > 0 ? Colors.red : Colors.green)),
                    ],
                  ),
                ),
              ],
            );
          }

          return Column(
            children: [
              Expanded(
                child: ListView.builder(
                  padding: const EdgeInsets.all(12),
                  itemCount: transactions.length,
                  itemBuilder: (context, index) {
                    final txn = transactions[index];
                    return Container(
                      margin: const EdgeInsets.only(bottom: 10),
                      padding: const EdgeInsets.all(10),
                      decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(10),
                        boxShadow: [
                          BoxShadow(
                            color: Colors.black.withOpacity(0.04),
                            blurRadius: 8,
                            offset: const Offset(0, 3),
                          ),
                        ],
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            children: [
                              Expanded(
                                child: Text(
                                  txn.customerName,
                                  style: const TextStyle(
                                    fontSize: 15,
                                    fontWeight: FontWeight.bold,
                                  ),
                                  maxLines: 1,
                                  overflow: TextOverflow.ellipsis,
                                ),
                              ),
                              Container(
                                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                                decoration: BoxDecoration(
                                  color: Colors.teal.withOpacity(0.12),
                                  borderRadius: BorderRadius.circular(20),
                                ),
                                child: Text(
                                  txn.paymentType,
                                  style: const TextStyle(
                                    color: Colors.teal,
                                    fontWeight: FontWeight.w600,
                                  ),
                                ),
                              ),
                            ],
                          ),
                          const SizedBox(height: 2),
                          Text(
                            'Service: ${txn.serviceId}',
                            style: TextStyle(color: Colors.grey.shade600),
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                          ),
                          const SizedBox(height: 2),
                          Row(
                            children: [
                              Expanded(
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(
                                      'Amount: ${txn.amount.toStringAsFixed(2)}',
                                      style: const TextStyle(fontWeight: FontWeight.w600),
                                    ),
                                    const SizedBox(height: 2),
                                    Text(
                                      'Balance: ${txn.balanceAmount.toStringAsFixed(2)}',
                                      style: TextStyle(fontWeight: FontWeight.w600, color: Colors.red.shade700),
                                    ),
                                  ],
                                ),
                              ),
                              Text(
                                DateFormat('dd MMM yyyy • HH:mm').format(txn.createdAt),
                                style: TextStyle(fontSize: 12, color: Colors.grey.shade500),
                              ),
                            ],
                          ),
                        ],
                      ),
                    );
                  },
                ),
              ),
              Container(
                width: double.infinity,
                padding: const EdgeInsets.fromLTRB(12, 10, 12, 12),
                decoration: BoxDecoration(
                  color: Colors.white,
                  border: Border(top: BorderSide(color: Colors.grey.shade200)),
                ),
                child: Row(
                  children: [
                    Expanded(child: _SummaryBox(label: 'Total Amount', value: totalAmount, color: Colors.black87)),
                    const SizedBox(width: 8),
                    Expanded(child: _SummaryBox(label: 'Total Paid', value: totalPaidAmount, color: Colors.green)),
                    const SizedBox(width: 8),
                    Expanded(child: _SummaryBox(label: 'Total Balance', value: totalBalanceAmount, color: totalBalanceAmount > 0 ? Colors.red : Colors.green)),
                  ],
                ),
              ),
            ],
          );
        },
      ),
    );
  }
}

class _SummaryBox extends StatelessWidget {
  final String label;
  final double value;
  final Color color;

  const _SummaryBox({required this.label, required this.value, required this.color});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 8),
      decoration: BoxDecoration(
        color: Colors.grey.shade50,
        borderRadius: BorderRadius.circular(8),
        border: Border.all(color: Colors.grey.shade200),
      ),
      child: Column(
        children: [
          Text(label, style: TextStyle(fontSize: 10, color: Colors.grey.shade600)),
          const SizedBox(height: 2),
          Text(value.toStringAsFixed(2), style: TextStyle(fontWeight: FontWeight.bold, color: color, fontSize: 13)),
        ],
      ),
    );
  }
}
