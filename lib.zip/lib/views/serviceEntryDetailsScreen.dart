import 'package:entryon/views/serviceTransactionsListScreen.dart';
import 'package:entryon/views/servicewiseMakeTransactionScreen.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../models/service_model.dart';

class ServiceEntryDetailsScreen extends StatelessWidget {
  final ServiceEntry service;

  const ServiceEntryDetailsScreen({super.key, required this.service});

  Color _statusColor(String status) {
    switch (status.toLowerCase()) {
      case 'paid':
      case 'completed':
        return Colors.green;
      case 'partial':
      case 'in progress':
        return Colors.orange;
      default:
        return Colors.redAccent;
    }
  }

  @override
  Widget build(BuildContext context) {
    final purchaseTotal = service.purchaseLines.fold<double>(0.0, (sum, line) => sum + line.cost);
    final balanceAmount = service.amount - service.customerPaidAmount;

    return Scaffold(
      backgroundColor: Colors.grey.shade100,
      appBar: AppBar(
        title: const Text('Service Details', style: TextStyle(fontWeight: FontWeight.w600)),
        backgroundColor: Colors.white,
        elevation: 0,
        scrolledUnderElevation: 0,
        centerTitle: true,
      ),
      body: Column(
        children: [
          Expanded(
            child: SingleChildScrollView(
              padding: const EdgeInsets.all(10),
              child: Column(
                children: [
                  // Header Card
                  Row(
                    children: [
                      Expanded(
                        child: Container(
                          width: double.infinity,
                          padding: const EdgeInsets.all(10),
                          decoration: BoxDecoration(
                            color: Colors.white,
                            borderRadius: BorderRadius.circular(10),
                            boxShadow: [
                              BoxShadow(color: Colors.black.withOpacity(0.05), blurRadius: 10, offset: const Offset(0, 4)),
                            ],
                          ),
                          child: Column(  crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Row(mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Column(mainAxisAlignment: MainAxisAlignment.start, crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      Text(service.title, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                                    
                                       Text(service.customerName, style: TextStyle(fontSize: 14, color: Colors.grey.shade800)),
                                    ],
                                  ),
                                 
                                  const SizedBox(width: 6),
                                  Row(
                                    children: [
                                      _StatusChip(
                                        header: 'Payment Status',
                                        label: service.paymentStatus,
                                        color: _statusColor(service.paymentStatus)
                                      ),
                                      const SizedBox(width: 10),
                                      _StatusChip(
                                        header: 'Service Status',
                                        label: service.serviceStatus,
                                        color: _statusColor(service.serviceStatus)
                                      ),
                                    ],
                                  ),
                                ],
                              ),
                                
                          //  Text(service.description??"No description available", style: TextStyle(fontSize: 12, color: Colors.grey.shade800)),
                            ],
                          ),
                        ),
                      ),
                      SizedBox(width:5), Container(padding: const EdgeInsets.all(10),width: 160,decoration: BoxDecoration(
                          color: Colors.white,
                          borderRadius: BorderRadius.circular(10),
                          boxShadow: [
                            BoxShadow(color: Colors.black.withOpacity(0.05), blurRadius: 10, offset: const Offset(0, 4)),
                          ],),
                         child: Column(
                           children: [
                             _InfoRow(label: 'Date', value: DateFormat('dd MMM yyyy').format(service.serviceDate)),
                             const SizedBox(height: 6),
                              _InfoRow(
                                label: 'Expiry',
                                value: service.paymentExpiryDate != null
                                    ? DateFormat('dd MMM yyyy').format(service.paymentExpiryDate!)
                                    : 'Not set',
                              ),
                           ],
                         ),
                       ),
                    ],
                  ),
            
                  const SizedBox(height: 10),
            _SectionCard(
                    title: 'Service Description',
                    child: Column(
                      children: [
                       
                        if ((service.description ?? '').isNotEmpty)
                        Text(service.description??"No description available", style: const TextStyle(fontWeight: FontWeight.w500)),
                      ],
                    ),
                  ),
                   const SizedBox(height: 10),
             _SectionCard(
                    title: 'Purchase Lines',
                    child: service.purchaseLines.isEmpty
                        ? const Padding(
                            padding: EdgeInsets.symmetric(vertical: 10),
                            child: Text('No purchase lines recorded', style: TextStyle(color: Colors.grey)),
                          )
                        : Column(
                            children: service.purchaseLines.map((line) {
                              return Container(
                                // margin: const EdgeInsets.only(bottom: 10),
                                padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
                                decoration: BoxDecoration(
                                  color: Colors.grey.shade50,
                                  borderRadius: BorderRadius.circular(10),
                                  border: Border.all(color: Colors.grey.shade200),
                                ),
                                child: Row(
                                  children: [
                                    Expanded(child: Text(line.purchaseName, style: const TextStyle(fontWeight: FontWeight.w500))),
                                    Text(line.cost.toStringAsFixed(2), style: const TextStyle(fontWeight: FontWeight.w600)),
                                  ],
                                ),
                              );
                            }).toList(),
                          ),
                  ),
                  const SizedBox(height: 10),
                  // Financial Summary
                  _SectionCard(
                    title: 'Financial Summary',
                    child: Column(
                      children: [
                        _MoneyRow(label: 'Service Fee', value: service.serviceFee),
                        _MoneyRow(label: 'Purchase Total', value: purchaseTotal),
                        const Divider(height: 24),
                        _MoneyRow(label: 'Total Amount', value: service.amount, isBold: true),
                        _MoneyRow(label: 'Amount Paid', value: service.customerPaidAmount, color: Colors.green),
                        _MoneyRow(label: 'Balance', value: balanceAmount, color: balanceAmount > 0 ? Colors.red : Colors.green, isBold: true),
                      ],
                    ),
                  ),
            
              
                  // Service Info
                  
            
                  // Purchase Lines
                 
            
                  if (service.createdAt != null || service.updatedAt != null) ...[
                    const SizedBox(height: 10),
                    _SectionCard(
                      title: 'Timestamps',
                      child: Column(
                        children: [
                          // if (service.createdAt != null)
                          //   _InfoRow(label: 'Created', value: DateFormat('dd MMM yyyy • HH:mm').format(service.createdAt!)),
                          if (service.updatedAt != null)
                            _InfoRow(label: 'Updated', value: DateFormat('dd MMM yyyy • HH:mm').format(service.updatedAt!)),
                        ],
                      ),
                    ),
                  ],
                 
                ],
              ),
            ),
          ),
  const SizedBox(height: 10),
            Padding(
              padding: const EdgeInsets.all(10.0),
              child: Container(
                width: double.infinity,
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(10),
                  boxShadow: [
                    BoxShadow(color: Colors.black.withOpacity(0.04), blurRadius: 8, offset: const Offset(0, 3)),
                  ],
                ),
                child: Row(
                  children: [
                    Expanded(
                      child: ElevatedButton.icon(
                        onPressed: () {
                          showDialog(
                                context: context,
                                builder: (_) => Dialog(
                                  insetPadding: const EdgeInsets.all(20),
                                  child: SizedBox(
                                    width: 600,
                                    height: 900,
                                    child: ServicewiseMakeTransactionScreen(service: service),
                                  ),
                                ),
                              );
                          // Navigator.push(
                          //   context,
                          //   MaterialPageRoute(builder: (_) => ServicewiseMakeTransactionScreen(service: service)),
                          // );
                        },
                        icon: const Icon(Icons.payment_outlined),
                        label: const Text('Make Payment'),
                        style: ElevatedButton.styleFrom(
                          backgroundColor: Colors.teal,
                          foregroundColor: Colors.white,
                          padding: const EdgeInsets.symmetric(vertical: 12),
                        ),
                      ),
                    ),
                    const SizedBox(width: 10),
                    Expanded(
                      child: OutlinedButton.icon(
                        onPressed: () {
                          showDialog(
                                context: context,
                                builder: (_) => Dialog(
                                  insetPadding: const EdgeInsets.all(20),
                                  child: SizedBox(
                                    width: 600,
                                    height: 900,
                                    child: ServiceTransactionsListScreen(serviceId: service.id),
                                  ),
                                ),
                              );
                          // Navigator.push(
                          //   context,
                          //   MaterialPageRoute(
                          //     builder: (_) => ServiceTransactionsListScreen(serviceId: service.id),
                          //   ),
                          // );
                        },
                        icon: const Icon(Icons.list_alt),
                        label: const Text('View Transactions'),
                        style: OutlinedButton.styleFrom(
                          padding: const EdgeInsets.symmetric(vertical: 12),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          
        ],
      ),

    );
  }
}

// ── Reusable Widgets ───────────────────────────────────────────────────────

class _SectionCard extends StatelessWidget {
  final String title;
  final Widget child;
  const _SectionCard({required this.title, required this.child});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(10),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(10),
        boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.04), blurRadius: 8, offset: const Offset(0, 3))],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(title, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
          const SizedBox(height: 5),
          child,
        ],
      ),
    );
  }
}

class _InfoRow extends StatelessWidget {
  final String label;
  final String value;
  const _InfoRow({required this.label, required this.value});

  @override
  Widget build(BuildContext context) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(label, style: TextStyle(color: Colors.grey.shade600)),
        Expanded(child: Text("  : $value", style: const TextStyle(fontWeight: FontWeight.w500))),
      ],
    );
  }
}

class _MoneyRow extends StatelessWidget {
  final String label;
  final double value;
  final bool isBold;
  final Color? color;

  const _MoneyRow({required this.label, required this.value, this.isBold = false, this.color});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 8),
      child: Row(
        children: [
          Expanded(child: Text(label, style: TextStyle(color: Colors.grey.shade700))),
          Text(
            value.toStringAsFixed(2),
            style: TextStyle(
              fontWeight: isBold ? FontWeight.bold : FontWeight.w500,
              color: color ?? Colors.black87,
              fontSize: isBold ? 16 : 14,
            ),
          ),
        ],
      ),
    );
  }
}

class _StatusChip extends StatelessWidget {
  final String header;
  final String label;
  final Color color;
  const _StatusChip({required this.header, required this.label, required this.color});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
      decoration: BoxDecoration(
        color: color.withOpacity(0.12),
        borderRadius: BorderRadius.circular(10),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          Text(
            header,
            style: TextStyle(color: Colors.black, fontSize: 12),
          ),
          Text(label, style: TextStyle(color: color, fontWeight: FontWeight.w600, fontSize: 12)),
        ],
      ),
    );
  }
}