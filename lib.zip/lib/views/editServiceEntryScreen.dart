import 'package:entryon/providers/customer_provider.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:provider/provider.dart';
import '../models/service_model.dart';
import '../providers/edit_service_provider.dart';
import '../providers/service_entry_provider.dart';

class EditServiceEntryScreen extends StatefulWidget {
  final String serviceId;
  const EditServiceEntryScreen({super.key, required this.serviceId});

  @override
  State<EditServiceEntryScreen> createState() => _EditServiceEntryScreenState();
}

class _EditServiceEntryScreenState extends State<EditServiceEntryScreen> {
  final _formKey = GlobalKey<FormState>();

  final _titleController = TextEditingController();
  final _descriptionController = TextEditingController();
  final _amountController = TextEditingController();
  final _paidAmountController = TextEditingController();
  final _serviceFeeController = TextEditingController(text: '0');
  final _purchaseNameController = TextEditingController();
  final _purchaseCostController = TextEditingController();

  DateTime _serviceDate = DateTime.now();
  DateTime? _paymentExpiryDate;
  String _paymentStatus = 'Pending';
  String _serviceStatus = 'Pending';
  String _paymentType = 'Cash';
  String? _selectedCustomerId;
  List<ServicePurchaseLine> _purchaseLines = [];
  bool _isSaving = false;
  bool _isLoading = true;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) async {
      context.read<CustomerProvider>().fetchCustomers();
      final success = await context.read<EditServiceProvider>().fetchServiceById(widget.serviceId);
      if (!mounted) return;

      if (!success) {
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Service not found')));
        Navigator.pop(context);
        return;
      }

      final service = context.read<EditServiceProvider>().service!;
      _titleController.text = service.title;
      _descriptionController.text = service.description ?? '';
      _purchaseLines = List.from(service.purchaseLines);
      _serviceFeeController.text = service.serviceFee.toStringAsFixed(2);
      _amountController.text = service.amount.toStringAsFixed(2);
      _serviceDate = service.serviceDate;
      _paymentExpiryDate = service.paymentExpiryDate;
      _paymentStatus = _normalizePaymentStatus(service.paymentStatus);
      _serviceStatus = _normalizeServiceStatus(service.serviceStatus);
      _paymentType = _normalizePaymentType(service.paymentType);
      _paidAmountController.text = service.customerPaidAmount.toStringAsFixed(2);
      _selectedCustomerId = service.customerId;

      setState(() => _isLoading = false);
    });
  }

  Future<void> _pickDate({required bool payment}) async {
    final picked = await showDatePicker(
      context: context,
      initialDate: payment ? (_paymentExpiryDate ?? DateTime.now()) : _serviceDate,
      firstDate: DateTime(2020),
      lastDate: DateTime(2100),
    );
    if (picked != null) {
      setState(() => payment ? _paymentExpiryDate = picked : _serviceDate = picked);
    }
  }

  void _addPurchaseLine() {
    final name = _purchaseNameController.text.trim();
    final cost = double.tryParse(_purchaseCostController.text.trim()) ?? 0;
    if (name.isEmpty) return;

    setState(() {
      _purchaseLines.add(ServicePurchaseLine(
        id: DateTime.now().toIso8601String(),
        purchaseName: name,
        cost: cost,
      ));
      _purchaseNameController.clear();
      _purchaseCostController.clear();
      _recalculateTotal();
    });
  }

  void _removePurchaseLine(int index) {
    setState(() {
      _purchaseLines.removeAt(index);
      _recalculateTotal();
    });
  }

  void _recalculateTotal() {
    _amountController.text = ServiceEntry.calculateTotalAmount(
      purchaseLines: _purchaseLines,
      serviceCost: double.tryParse(_serviceFeeController.text.trim()) ?? 0,
    ).toStringAsFixed(2);
  }

  double get _totalServiceCost => ServiceEntry.calculateTotalAmount(
        purchaseLines: _purchaseLines,
        serviceCost: double.tryParse(_serviceFeeController.text.trim()) ?? 0,
      );

  double get _balanceAmount =>
      _totalServiceCost - (double.tryParse(_paidAmountController.text.trim()) ?? 0);

  String _normalizePaymentStatus(String? value) {
    final normalized = (value ?? '').trim().toLowerCase();
    if (normalized == 'partial' || normalized == 'partially' || normalized == 'partially paid') {
      return 'Partial';
    }
    if (normalized == 'paid' || normalized == 'complete' || normalized == 'completed') {
      return 'Paid';
    }
    return 'Pending';
  }

  String _normalizeServiceStatus(String? value) {
    final normalized = (value ?? '').trim().toLowerCase();
    if (normalized == 'in progress' || normalized == 'inprogress' || normalized == 'ongoing' || normalized == 'progress') {
      return 'In Progress';
    }
    if (normalized == 'completed' || normalized == 'complete' || normalized == 'done') {
      return 'Completed';
    }
    return 'Pending';
  }

  String _normalizePaymentType(String? value) {
    final normalized = (value ?? '').trim().toLowerCase();
    if (normalized == 'card' || normalized == 'credit card' || normalized == 'credit') {
      return 'Card';
    }
    return 'Cash';
  }

  Future<void> _save() async {
    if (!_formKey.currentState!.validate()) return;

    setState(() => _isSaving = true);

    final customers = context.read<CustomerProvider>().customers;
    final selectedCustomer = customers.cast<dynamic>().firstWhere(
          (c) => c.id == _selectedCustomerId,
          orElse: () => null,
        );

    final success = await context.read<ServiceEntryProvider>().updateService(
          id: widget.serviceId,
          title: _titleController.text.trim(),
          customerName: selectedCustomer?.name ?? '',
          customerId: _selectedCustomerId,
          description: _descriptionController.text.trim(),
          serviceDate: _serviceDate,
          amount: _totalServiceCost,
          serviceFee: double.tryParse(_serviceFeeController.text.trim()) ?? 0,
          customerPaidAmount: double.tryParse(_paidAmountController.text.trim()) ?? 0,
          paymentStatus: _normalizePaymentStatus(_paymentStatus),
          serviceStatus: _normalizeServiceStatus(_serviceStatus),
          paymentType: _normalizePaymentType(_paymentType),
          paymentExpiryDate: _paymentExpiryDate,
          purchaseLines: _purchaseLines,
        );

    if (!mounted) return;
    setState(() => _isSaving = false);

    if (success) {
      Navigator.pop(context);
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Service updated successfully'), backgroundColor: Colors.green),
      );
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(context.read<ServiceEntryProvider>().errorMessage ?? 'Failed to update'),
          backgroundColor: Colors.red,
        ),
      );
    }
  }

  @override
  void dispose() {
    _titleController.dispose();
    _descriptionController.dispose();
    _amountController.dispose();
    _paidAmountController.dispose();
    _purchaseNameController.dispose();
    _purchaseCostController.dispose();
    _serviceFeeController.dispose();
    super.dispose();
  }

  InputDecoration _inputDecoration(String label) {
    return InputDecoration(
      labelText: label,
      filled: true,
      fillColor: Colors.white,
      isDense: true,
      contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 14),
      border: OutlineInputBorder(borderRadius: BorderRadius.circular(10), borderSide: BorderSide(color: Colors.grey.shade300)),
      enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(10), borderSide: BorderSide(color: Colors.grey.shade300)),
      focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(10), borderSide: const BorderSide(color: Colors.teal, width: 1.5)),
    );
  }

  @override
  Widget build(BuildContext context) {
    final customers = context.watch<CustomerProvider>().customers;

    if (_isLoading) {
      return const Scaffold(
        body: Center(child: CircularProgressIndicator(color: Colors.teal)),
      );
    }

    return Scaffold(
      backgroundColor: Colors.grey.shade100,
      appBar: AppBar(
        title: const Text('Edit Service', style: TextStyle(fontWeight: FontWeight.w600)),
        backgroundColor: Colors.white,
        elevation: 0,
        scrolledUnderElevation: 0,
        centerTitle: true,
        actions: [
          Padding(
            padding: const EdgeInsets.only(right: 12),
            child: TextButton.icon(
              onPressed: _isSaving ? null : _save,
              icon: _isSaving
                  ? const SizedBox(width: 16, height: 16, child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white))
                  : const Icon(Icons.save_outlined, size: 18),
              label: const Text('Update'),
              style: TextButton.styleFrom(
                backgroundColor: Colors.teal,
                foregroundColor: Colors.white,
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
              ),
            ),
          ),
        ],
      ),
      body: Form(
        key: _formKey,
        child: ListView(
          padding: const EdgeInsets.all(10),
          children: [
            // ── Basic Info ──────────────────────────────────────────────
            _SectionTitle('Basic Information'),
            const SizedBox(height: 10),
            Container(
              padding: const EdgeInsets.all(10),
              decoration: _cardDecoration(),
              child: Column(
                children: [
                  TextFormField(
                    controller: _titleController,
                    decoration: _inputDecoration('Service Title *'),
                    validator: (v) => (v == null || v.trim().isEmpty) ? 'Required' : null,
                  ),
                  const SizedBox(height: 10),
                  DropdownButtonFormField<String>(
                    value: _selectedCustomerId,
                    decoration: _inputDecoration('Select Customer *'),
                    items: customers
                        .map((c) => DropdownMenuItem(value: c.id, child: Text(c.name)))
                        .toList(),
                    onChanged: (v) => setState(() => _selectedCustomerId = v),
                    validator: (v) => v == null ? 'Select a customer' : null,
                  ),
                  const SizedBox(height: 10),
                  TextFormField(
                    controller: _descriptionController,
                    maxLines: 3,
                    decoration: _inputDecoration('Description (Optional)'),
                  ),
                ],
              ),
            ),

            const SizedBox(height: 10),

            // ── Purchase Lines ──────────────────────────────────────────
            _SectionTitle('Purchase Lines'),
            const SizedBox(height: 10),
            Container(
              padding: const EdgeInsets.all(10),
              decoration: _cardDecoration(),
              child: Column(
                children: [
                  Row(
                    children: [
                      Expanded(
                        flex: 3,
                        child: TextFormField(
                          controller: _purchaseNameController,
                          decoration: _inputDecoration('Purchase Name'),
                        ),
                      ),
                      const SizedBox(width: 10),
                      Expanded(
                        flex: 2,
                        child: TextFormField(
                          controller: _purchaseCostController,
                          keyboardType: TextInputType.number,
                          decoration: _inputDecoration('Cost'),
                        ),
                      ),
                      const SizedBox(width: 8),
                      IconButton(
                        onPressed: _addPurchaseLine,
                        icon: const Icon(Icons.add_circle, color: Colors.teal, size: 32),
                      ),
                    ],
                  ),
                  if (_purchaseLines.isNotEmpty) ...[
                    const SizedBox(height: 10),
                    ..._purchaseLines.asMap().entries.map((entry) {
                      final index = entry.key;
                      final line = entry.value;
                      return Container(
                        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 10),
                        decoration: BoxDecoration(
                          color: Colors.grey.shade50,
                          borderRadius: BorderRadius.circular(10),
                          border: Border.all(color: Colors.grey.shade200),
                        ),
                        child: Row(
                          children: [
                            Expanded(child: Text(line.purchaseName, style: const TextStyle(fontWeight: FontWeight.w500))),
                            Text(line.cost.toStringAsFixed(2), style: const TextStyle(fontWeight: FontWeight.w600)),
                            const SizedBox(width: 8),
                            GestureDetector(
                              onTap: () => _removePurchaseLine(index),
                              child: const Icon(Icons.close, size: 18, color: Colors.redAccent),
                            ),
                          ],
                        ),
                      );
                    }),
                  ],
                ],
              ),
            ),

            const SizedBox(height: 10),

            // ── Financial ───────────────────────────────────────────────
            _SectionTitle('Financial Details'),
            const SizedBox(height: 10),
            Container(
              padding: const EdgeInsets.all(16),
              decoration: _cardDecoration(),
              child: Column(
                children: [
                  Row(
                    children: [
                      Expanded(
                        child: TextFormField(
                          controller: _serviceFeeController,
                          keyboardType: TextInputType.number,
                          decoration: _inputDecoration('Service Fee'),
                          onChanged: (_) => setState(() => _recalculateTotal()),
                        ),
                      ),
                      const SizedBox(width: 10),
                      Expanded(
                        child: TextFormField(
                          controller: _amountController,
                          readOnly: true,
                          decoration: _inputDecoration('Total Service Cost'),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 10),
                  Row(
                    children: [
                      Expanded(
                        child: TextFormField(
                          controller: _paidAmountController,
                          keyboardType: TextInputType.number,
                          decoration: _inputDecoration('Customer Paid Amount'),
                          onChanged: (_) => setState(() {}),
                        ),
                      ),
                      const SizedBox(width: 10),
                      // Balance summary
                      Expanded(
                        child: Container(
                          width: double.infinity,
                          padding: const EdgeInsets.all(10),
                          decoration: BoxDecoration(
                            color: _balanceAmount > 0 ? Colors.red.shade50 : Colors.green.shade50,
                            borderRadius: BorderRadius.circular(10),
                            border: Border.all(
                              color: _balanceAmount > 0 ? Colors.red.shade200 : Colors.green.shade200,
                            ),
                          ),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              const Text('Balance Amount', style: TextStyle(fontWeight: FontWeight.w600)),
                              Text(
                                _balanceAmount.toStringAsFixed(2),
                                style: TextStyle(
                                  fontWeight: FontWeight.bold,
                                  fontSize: 16,
                                  color: _balanceAmount > 0 ? Colors.red : Colors.green,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),

            const SizedBox(height: 10),

            // ── Status & Dates ──────────────────────────────────────────
            _SectionTitle('Status & Dates'),
            const SizedBox(height: 10),
            Container(
              padding: const EdgeInsets.all(10),
              decoration: _cardDecoration(),
              child: Column(
                children: [
                  Row(
                    children: [
                      Expanded(
                        child: DropdownButtonFormField<String>(
                          value: _paymentType,
                          decoration: _inputDecoration('Payment Type'),
                          items: const [
                            DropdownMenuItem(value: 'Cash', child: Text('Cash')),
                            DropdownMenuItem(value: 'Card', child: Text('Card')),
                          ],
                          onChanged: (v) => setState(() => _paymentType = v ?? 'Cash'),
                        ),
                      ),
                      const SizedBox(width: 10),
                      Expanded(
                        child: DropdownButtonFormField<String>(
                          value: _paymentStatus,
                          decoration: _inputDecoration('Payment Status'),
                          items: const [
                            DropdownMenuItem(value: 'Pending', child: Text('Pending')),
                            DropdownMenuItem(value: 'Partial', child: Text('Partial')),
                            DropdownMenuItem(value: 'Paid', child: Text('Paid')),
                          ],
                          onChanged: (v) => setState(() => _paymentStatus = v ?? 'Pending'),
                        ),
                      ),
                      const SizedBox(width: 10),
                      Expanded(
                        child: DropdownButtonFormField<String>(
                          value: _serviceStatus,
                          decoration: _inputDecoration('Service Status'),
                          items: const [
                            DropdownMenuItem(value: 'Pending', child: Text('Pending')),
                            DropdownMenuItem(value: 'In Progress', child: Text('In Progress')),
                            DropdownMenuItem(value: 'Completed', child: Text('Completed')),
                          ],
                          onChanged: (v) => setState(() => _serviceStatus = v ?? 'Pending'),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 10),
                  Row(
                    children: [
                      Expanded(
                        child: _DateField(
                          label: 'Service Date',
                          value: DateFormat('dd MMM yyyy').format(_serviceDate),
                          onTap: () => _pickDate(payment: false),
                        ),
                      ),
                      const SizedBox(width: 10),
                      Expanded(
                        child: _DateField(
                          label: 'Payment Expiry Date',
                          value: _paymentExpiryDate == null
                              ? 'Select date'
                              : DateFormat('dd MMM yyyy').format(_paymentExpiryDate!),
                          onTap: () => _pickDate(payment: true),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),

            // const SizedBox(height: 40),
          ],
        ),
      ),
    );
  }

  BoxDecoration _cardDecoration() {
    return BoxDecoration(
      color: Colors.white,
      borderRadius: BorderRadius.circular(14),
      boxShadow: [
        BoxShadow(color: Colors.black.withOpacity(0.04), blurRadius: 8, offset: const Offset(0, 3)),
      ],
    );
  }
}

// ── Shared Widgets ────────────────────────────────────────────────────────

class _SectionTitle extends StatelessWidget {
  final String title;
  const _SectionTitle(this.title);

  @override
  Widget build(BuildContext context) {
    return Text(title, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold));
  }
}

// Reuse the same _DateField widget from Create screen
class _DateField extends StatelessWidget {
  final String label;
  final String value;
  final VoidCallback onTap;

  const _DateField({required this.label, required this.value, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(10),
      child: InputDecorator(
        decoration: InputDecoration(
          labelText: label,
          filled: true,
          fillColor: Colors.white,
          isDense: true,
          contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 14),
          border: OutlineInputBorder(borderRadius: BorderRadius.circular(10), borderSide: BorderSide(color: Colors.grey.shade300)),
          enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(10), borderSide: BorderSide(color: Colors.grey.shade300)),
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text(value),
            Icon(Icons.calendar_today_outlined, size: 18, color: Colors.grey.shade600),
          ],
        ),
      ),
    );
  }
}