import 'package:entryon/providers/auth_Provider.dart';
import 'package:entryon/views/changeUserIdPasswordScreen.dart';
import 'package:entryon/views/createCustomerScreen.dart';
import 'package:entryon/views/createSectionScreen.dart';
import 'package:entryon/views/createSupplierScreen.dart';
import 'package:flutter/material.dart';
import 'package:lucide_icons/lucide_icons.dart';
import 'package:entryon/views/servicesListScreen.dart';
import 'package:provider/provider.dart';
import 'purchaseEntryScreen.dart';



class MenuScreen extends StatelessWidget {
  const MenuScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey.shade50,
      appBar: AppBar(centerTitle: true,

        title: const Text("Entryon Menu",style: TextStyle(color: Colors.black,fontWeight: FontWeight.w600,fontSize:22),),
        backgroundColor: Colors.white,
        elevation: 0,
      ),

      body: Padding(
        padding: const EdgeInsets.all(10),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [

           
            // --- MENU GRID ---
            Expanded(
              child: GridView.count(
                crossAxisCount: 1,
                crossAxisSpacing: 16,
                mainAxisSpacing: 16,
                mainAxisExtent: 50,
                children: [
 _menuCustomButton(
                    context,
                    title: "Create Section",
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: const [
                      Icon(LucideIcons.calendarRange, color: Colors.black, size: 20),]
                    ),
                    color: Colors.grey,
                    onTap: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (_) => const PeriodSectionsScreen(),
                        ),
                      );
                    },
                  ),
                  _menuButton(
                    context,
                    title: "Create Purchase",
                    icon: Icons.add_shopping_cart,
                    color: Colors.teal,
                    onTap: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (_) => const PurchaseEntryScreen(),
                        ),
                      );
                    },
                  ),

                  _menuButton(
                    context,
                    title: "Create Customer",
                    icon: Icons.list_alt_rounded,
                    color: Colors.blue,
                    onTap: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (_) => const CreateCustomerScreen(),
                        ),
                      );
                    },
                  ),

                  _menuButton(
                    context,
                    title: "Create Supplier",
                    icon: Icons.store,
                    color: Colors.purple,
                    onTap: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (_) => const CreateSupplierScreen(),
                        ),
                      );
                    },
                  ),

                  _menuButton(
                    context,
                    title: "Services",
                    icon: Icons.build,
                    color: Colors.indigo,
                    onTap: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (_) => const ServicesListScreen(),
                        ),
                      );
                    },
                  ),

                  _menuButton(
                    context,
                    title: "Change UserId & Password ",
                    icon: Icons.bar_chart,
                    color: Colors.orange,
                    onTap: () {
                    _showPasswordGate(context);
                    },
                  ),

                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
  Future<void> _showPasswordGate(BuildContext context) async {
  final passwordController = TextEditingController();
  bool obscure = true;

  final ok = await showDialog<bool>(
    context: context,
    barrierDismissible: false,
    builder: (dialogContext) {
      return StatefulBuilder(
        builder: (context, setDialogState) {
          return AlertDialog(
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
            title: const Text(
              'Enter Password',
              style: TextStyle(fontWeight: FontWeight.bold),
            ),
            content: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Text(
                  'Enter your current password to continue',
                  style: TextStyle(fontSize: 13, color: Colors.grey.shade600),
                ),
                const SizedBox(height: 16),
                TextField(
                  controller: passwordController,
                  obscureText: obscure,
                  autofocus: true,
                  decoration: InputDecoration(
                    labelText: 'Password',
                    prefixIcon: const Icon(Icons.lock_outline, color: Colors.teal),
                    suffixIcon: IconButton(
                      icon: Icon(
                        obscure ? Icons.visibility_outlined : Icons.visibility_off_outlined,
                        color: Colors.grey.shade600,
                      ),
                      onPressed: () => setDialogState(() => obscure = !obscure),
                    ),
                    filled: true,
                    fillColor: Colors.grey.shade50,
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(12),
                      borderSide: BorderSide(color: Colors.grey.shade300),
                    ),
                    enabledBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(12),
                      borderSide: BorderSide(color: Colors.grey.shade300),
                    ),
                    focusedBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(12),
                      borderSide: const BorderSide(color: Colors.teal, width: 1.5),
                    ),
                  ),
                  onSubmitted: (_) {
                    // handled by button
                  },
                ),
              ],
            ),
            actions: [
              TextButton(
                onPressed: () => Navigator.pop(dialogContext, false),
                child: Text('Cancel', style: TextStyle(color: Colors.grey.shade600)),
              ),
              ElevatedButton(
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.teal,
                  foregroundColor: Colors.white,
                  elevation: 0,
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                ),
                onPressed: () {
                  final auth = context.read<AuthProvider>();

                  // Check against current stored password
                  // We verify by trying login logic without logging out
                  if (passwordController.text == auth.masterPassword) {
                    Navigator.pop(dialogContext, true);
                  } else {
                    ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(
                        content: Text('Incorrect password'),
                        backgroundColor: Colors.red,
                        behavior: SnackBarBehavior.floating,
                      ),
                    );
                  }
                },
                child: const Text('Continue'),
              ),
            ],
          );
        },
      );
    },
  );

  if (ok == true && context.mounted) {
    final authProvider = context.read<AuthProvider>();

   showDialog(
                                context: context,
                                builder: (_) => Dialog(
                                  insetPadding: const EdgeInsets.all(20),
                                  child: SizedBox(
                                    width: 600,
                                    height: 900,
                                    child: EditCredentialsScreen(),
                                  ),
                                ),
                              );
                      // Navigator.push(
                      //   context,
                      //   MaterialPageRoute(
                      //     builder: (_) => const ReportsScreen(),
                      //   ),
                      // );
  }
}
                     
  // --- MENU BUTTON WIDGET ---
  Widget _menuButton(
    BuildContext context, {
    required String title,
    required IconData icon,
    required Color color,
    required VoidCallback onTap,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(10),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.08),
              blurRadius: 8,
              offset: const Offset(0, 3),
            ),
          ],
        ),
        padding: const EdgeInsets.all(8),
        child: Row(
          children: [
            Expanded(
              child: Row(
                mainAxisAlignment: MainAxisAlignment.start,
                children: [
                  Container(
                    width: 35,
                    height: 40,
                    decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(10),
                    color: color.withOpacity(0.15),
                    ),
                    child: Center(child: Icon(icon, color: color, size: 20)),
                  ),
                  const SizedBox(width: 12),
                  Text(
                    title,
                    textAlign: TextAlign.center,
                    style: const TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.w600,
                    ),
                  )
                ],
              ),
            ),
            Icon(Icons.keyboard_arrow_right, color: Colors.grey.shade400)
          ],
        ),
      ),
    );
  }
  Widget _menuCustomButton(
    BuildContext context, {
    required String title,
    required Widget child,
    required Color color,
    required VoidCallback onTap,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(10),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.08),
              blurRadius: 8,
              offset: const Offset(0, 3),
            ),
          ],
        ),
        padding: const EdgeInsets.all(8),
        child: Row(
          children: [
            Expanded(
              child: Row(
                mainAxisAlignment: MainAxisAlignment.start,
                children: [
                  Container(
                    width: 35,
                    height: 40,
                    decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(10),
                    color: color.withOpacity(0.15),
                    ),
                    child: Center(child: child),
                  ),
                  const SizedBox(width: 12),
                  Text(
                    title,
                    textAlign: TextAlign.center,
                    style: const TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.w600,
                    ),
                  )
                ],
              ),
            ),
            Icon(Icons.keyboard_arrow_right, color: Colors.grey.shade400)
          ],
        ),
      ),
    );
  }

}

