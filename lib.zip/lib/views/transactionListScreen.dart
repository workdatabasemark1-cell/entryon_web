import 'package:entryon/models/transaction_model.dart';
import 'package:entryon/providers/service_entry_provider.dart';
import 'package:entryon/views/makeTransactionScreen.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:intl/intl.dart';
import '../providers/transaction_provider.dart';
import '../utils/date_utils.dart';

class TransactionsListScreen extends StatefulWidget {
  const TransactionsListScreen({super.key});

  @override
  State<TransactionsListScreen> createState() => _TransactionsListScreenState();
}

class _TransactionsListScreenState extends State<TransactionsListScreen> {
  final TextEditingController _searchController = TextEditingController();
  DateTime? _fromDate;
  DateTime? _toDate;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      context.read<TransactionProvider>().fetchTransactions();
    });
  }

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  Future<void> _pickDateRange() async {
    final now = DateTime.now();
    final initialStart = _fromDate ?? now.subtract(const Duration(days: 30));
    final initialEnd = _toDate ?? now;

    final picked = await showDateRangePicker(
      context: context,
      firstDate: DateTime(2020),
      lastDate: DateTime(2100),
      initialDateRange: DateTimeRange(start: initialStart, end: initialEnd),
    );

    if (picked != null) {
      setState(() {
        _fromDate = picked.start;
        _toDate = picked.end;
      });
    }
  }

  List<TransactionModel> _filteredTransactions(List<TransactionModel> transactions) {
    final query = _searchController.text.trim().toLowerCase();
    final start = _fromDate;
    final end = _toDate;

    return transactions.where((txn) {
      final matchesName = query.isEmpty || txn.customerName.toLowerCase().contains(query);
      final matchesDate = isDateWithinRange(txn.createdAt, start, end);
      return matchesName && matchesDate;
    }).toList();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey.shade100,
      appBar: AppBar(
        title: const Text('Transactions', style: TextStyle(fontWeight: FontWeight.w600)),
        backgroundColor: Colors.white,
        elevation: 0,
        scrolledUnderElevation: 0,
       actions: [Padding(
                padding: const EdgeInsets.fromLTRB(10, 10, 10, 10),
                child:
                 Row(
                  children: [
                    SizedBox(
                      width: 250,
                      height: 35,
                      child: TextField(
                        controller: _searchController,
                        onChanged: (_) => setState(() {}),
                        decoration: InputDecoration(
                          hintText: 'Search by customer name',
                          prefixIcon: const Icon(Icons.search),
                          filled: true,
                          isDense: true,
                          contentPadding: const EdgeInsets.symmetric(vertical: 0, horizontal: 5),
                          fillColor: Colors.white,
                          focusColor: Colors.white,
                          hoverColor: Colors.white,
                          border: OutlineInputBorder(borderRadius: BorderRadius.circular(10), borderSide: BorderSide.none),
                        ),
                      ),
                    ),
                    const SizedBox(width: 8),
                    Container(
                      width: 150,
                      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 7.5),
                      decoration: BoxDecoration(
                        border: Border.all(color: Colors.grey.shade400),
                        borderRadius: BorderRadius.circular(8),
                      ),
                      child: InkWell(
                        onTap: _pickDateRange,
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            const Icon(Icons.calendar_today_outlined, size: 18),
                            const SizedBox(width: 8),
                            Expanded(
                              child: Text(
                                _fromDate == null && _toDate == null
                                    ? 'Filter by date'
                                    : '${_fromDate != null ? DateFormat('dd MMM').format(_fromDate!) : ""}'
                                      '${_fromDate != null && _toDate != null ? ' - ' : ''}'
                                      '${_toDate != null ? DateFormat('dd MMM').format(_toDate!) : ""}',
                                overflow: TextOverflow.ellipsis,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                    if (_searchController.text.trim().isNotEmpty || _fromDate != null || _toDate != null) ...[
                      const SizedBox(width: 8),
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 7.5),
                        decoration: BoxDecoration(
                          color: Colors.black.withOpacity(0.08),
                          borderRadius: BorderRadius.circular(8),
                        ),
                        child: InkWell(
                          onTap: () => setState(() {
                            _searchController.clear();
                            _fromDate = null;
                            _toDate = null;
                          }),
                          child: const Text(
                            'Reset',
                            style: TextStyle(color: Colors.black),
                          ),
                        ),
                      ),
                    ],
                    SizedBox(width:10),
                     Container(
  padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4.5),
  decoration: BoxDecoration(
    color: Colors.teal.withOpacity(0.12),
    borderRadius: BorderRadius.circular(10),
    border: Border.all(color: Colors.teal),
  ),
  child: GestureDetector(
       onTap: () {
       showDialog(
  context: context,
  builder: (_) => Dialog(
    insetPadding: const EdgeInsets.all(10),
    child: SizedBox(
      width: 600,
      height: 900,
      child: MakeTransactionScreen(),
    ),
  ),
);
if (mounted) context.read<ServiceEntryProvider>().fetchServices();
       },
    child: Row(
      mainAxisSize: MainAxisSize.min,
      children: const [
        Icon(Icons.add_circle_outline, color: Colors.teal),
        SizedBox(width: 8),
        Text(
          'Create Payment',
          style: TextStyle(
            color: Colors.teal,
            fontWeight: FontWeight.w600,
          ),
        ),
      ],
    ),
  ),
)

                  ],
                  
                ),
              ),],
      
      ),
      body: Column(
        children: [  
          
             
          Expanded(
            child: Consumer<TransactionProvider>(
              builder: (context, provider, _) {
                if (provider.isLoading && provider.transactions.isEmpty) {
                  return const Center(child: CircularProgressIndicator(color: Colors.teal));
                }
            
                final filteredTransactions = _filteredTransactions(provider.transactions);
                final totalPaidAmount = filteredTransactions.fold<double>(0.0, (sum, txn) => sum + txn.amount);
                final totalBalanceAmount = filteredTransactions.fold<double>(0.0, (sum, txn) => sum + ((txn.paymentDetails?['balanceAmount'] as num?)?.toDouble() ?? 0.0));
                final totalAmount = totalPaidAmount + totalBalanceAmount;
            
                if (filteredTransactions.isEmpty) {
                  return Center(
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(Icons.receipt_long_outlined, size: 70, color: Colors.grey.shade400),
                        const SizedBox(height: 16),
                        Text('No transactions found', style: TextStyle(color: Colors.grey.shade600, fontSize: 16)),
                      ],
                    ),
                  );
                }
            
                return Column(
                  children: [
                   Expanded(
                      child: GridView.builder(
  padding: const EdgeInsets.fromLTRB(10, 10, 10, 10),
  itemCount: filteredTransactions.length,
  gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
    crossAxisCount: 3,
    mainAxisSpacing: 10,
    crossAxisSpacing: 10,
    mainAxisExtent:92 // adjust height ratio
  ),
  itemBuilder: (context, index) {
    final txn = filteredTransactions[index];
    final createdAt = txn.createdAt;

    return Container(
      padding: const EdgeInsets.all(10),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(10),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.04),
            blurRadius: 8,
            offset: const Offset(0, 3),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Expanded(
                child: Text(
                  txn.customerName,
                  style: const TextStyle(
                    fontSize: 15,
                    fontWeight: FontWeight.bold,
                  ),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                ),
              ),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                decoration: BoxDecoration(
                  color: Colors.teal.withOpacity(0.12),
                  borderRadius: BorderRadius.circular(20),
                ),
                child: Text(
                  txn.paymentType,
                  style: const TextStyle(
                    color: Colors.teal,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ),
            ],
          ),

          const SizedBox(height: 2),
          Text(
            'Service: ${txn.serviceId}',
            style: TextStyle(color: Colors.grey.shade600),
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
          ),

          const SizedBox(height: 2),
          Row(
            children: [
              Expanded(
                child: Text(
                  'Amount: ${txn.amount.toStringAsFixed(2)}',
                  style: const TextStyle(fontWeight: FontWeight.w600),
                ),
              ),
              Text(
                DateFormat('dd MMM yyyy • HH:mm').format(createdAt),
                style: TextStyle(fontSize: 12, color: Colors.grey.shade500),
              ),
            ],
          ),
        ],
      ),
    );
  },
)
),
                    Row(mainAxisAlignment: MainAxisAlignment.end, 
                      children: [
                        // Expanded(
                        //   child: Text(
                        //     'Total Amount: ${totalAmount.toStringAsFixed(2)}',
                        //     style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 14),
                        //   ),
                        // ),
                          Container(
                      width: 250,
                      padding: const EdgeInsets.fromLTRB(12, 10, 12, 12),
                      decoration: BoxDecoration(
                        color: Colors.white,
                        border: Border(top: BorderSide(color: Colors.grey.shade200)),
                      ),
                          child: Text(
                            'Total Paid: ${totalPaidAmount.toStringAsFixed(2)}',
                            style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
                          ),
                        ),
                        // Expanded(
                        //   child: Text(
                        //     'Total Balance: ${totalBalanceAmount.toStringAsFixed(2)}',
                        //     style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 14),
                        //   ),
                        // ),
                      ],
                    ),
                 
                  ],
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}
