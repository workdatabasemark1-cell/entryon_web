import 'dart:io';

import 'package:entryon/views/createCustomerScreen.dart';
import 'package:entryon/views/createSupplierScreen.dart';
import 'package:entryon/providers/editPurchaseEntryProvider.dart';
import 'package:entryon/views/qr_scanner_screen.dart';
import 'package:entryon/utils/zatca_qr_parser.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:intl/intl.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:file_picker/file_picker.dart';
import 'dart:convert';

import '../models/customer_model.dart';
import '../models/supplier_model.dart';
import '../models/purchase_entry_model.dart';
import '../providers/customer_provider.dart';
import '../providers/supplier_provider.dart';


// ── Lightweight period model (used only inside this screen) ──────────────────
class _Period {
  final String id;
  final String name;
  final DateTime startDate;
  final DateTime endDate;

  _Period({
    required this.id,
    required this.name,
    required this.startDate,
    required this.endDate,
  });

  /// e.g.  "Jan 2026 – Mar 2026"
  String get range =>
      '${DateFormat('MMM yyyy').format(startDate)} – '
      '${DateFormat('MMM yyyy').format(endDate)}';

  /// Full label shown in dropdown
  String get label => '$name  ($range)';
}

// ─────────────────────────────────────────────────────────────────────────────
// Screen — EDIT an existing purchase invoice.
// Uses the same visual layout as PurchaseEntryScreen, but is powered by
// EditPurchaseEntryProvider and loads its data from Firestore by [invoiceId].
// ─────────────────────────────────────────────────────────────────────────────

class EditPurchaseEntryScreen extends StatefulWidget {
  final String invoiceId;
  const EditPurchaseEntryScreen({super.key, required this.invoiceId});

  @override
  State<EditPurchaseEntryScreen> createState() => _EditPurchaseEntryScreenState();
}

class _EditPurchaseEntryScreenState extends State<EditPurchaseEntryScreen> {
  final _formKey = GlobalKey<FormState>();

  // ── Controllers ───────────────────────────────────────────────────────────
  final _invoiceNoController = TextEditingController();
  final _amountExVatController = TextEditingController();
  final _vatRateController = TextEditingController(text: '15');
  final _vatAmountController = TextEditingController();
  final _totalIncVatController = TextEditingController();
  final _customerSearchController = TextEditingController();
  final _supplierSearchController = TextEditingController();

  // ── State ─────────────────────────────────────────────────────────────────
  Customer? _selectedCustomer;
  Supplier? _selectedSupplier;
  DateTime? _invoiceDate;
  String _sortBy = 'date_desc';

  List<Customer> _filteredCustomers = [];
  List<Supplier> _filteredSuppliers = [];

  bool _showCustomerDropdown = false;
  bool _showSupplierDropdown = false;
  bool _isSaving = false;
  int? _editingIndex;

  // Whether the invoice + reference data (customers/suppliers/periods) have
  // finished loading and the form has been populated.
  bool _initialLoadDone = false;
  String? _loadError;

  void _clearEntryFields() {
    _editingIndex = null;
    _amountExVatController.clear();
    _vatAmountController.clear();
    _totalIncVatController.clear();
    _vatRateController.text = '15';
    _invoiceNoController.clear();
    _invoiceDate = null;
    _selectedSupplier = null;
  }

  List<PurchaseItem> _getSortedItems(List<PurchaseItem> items) {
    final sorted = List<PurchaseItem>.from(items);
    sorted.sort((a, b) {
      switch (_sortBy) {
        case 'date_asc':
          return a.date.compareTo(b.date);
        case 'date_desc':
          return b.date.compareTo(a.date);
        case 'supplier_asc':
          return a.supplierName.toLowerCase().compareTo(b.supplierName.toLowerCase());
        case 'supplier_desc':
          return b.supplierName.toLowerCase().compareTo(a.supplierName.toLowerCase());
        case 'amount_asc':
          return a.totalIncVat.compareTo(b.totalIncVat);
        case 'amount_desc':
          return b.totalIncVat.compareTo(a.totalIncVat);
        default:
          return b.id.compareTo(a.id);
      }
    });
    return sorted;
  }

  void _startEditEntry(int index) {
    final provider = context.read<EditPurchaseEntryProvider>();
    if (index < 0 || index >= provider.items.length) return;
    final item = provider.items[index];

    setState(() {
      _editingIndex = index;
      _invoiceNoController.text = item.invoiceNo;
      _invoiceDate = item.date;
      _amountExVatController.text = item.amountExVat.toStringAsFixed(2);
      _vatAmountController.text = item.vatAmount.toStringAsFixed(2);
      _totalIncVatController.text = item.totalIncVat.toStringAsFixed(2);
      _vatRateController.text = item.vatRate.toStringAsFixed(0);

      // Try to match supplier from provider; if not found, create a minimal instance
      final suppliers = context.read<SupplierProvider>().suppliers;
      try {
        _selectedSupplier = suppliers.firstWhere((s) => s.id == item.supplierId);
      } catch (_) {
        _selectedSupplier = Supplier(
          id: item.supplierId,
          name: item.supplierName,
          vatNumber: item.vatNumber,
          phone: '',
        );
      }
    });
  }

  // ── Period sections from Firestore ────────────────────────────────────────
  List<_Period> _periods = [];
  bool _periodsLoading = true;
  _Period? _selectedPeriod;

  // ─────────────────────────────────────────────────────────────────────────
  @override
  void initState() {
    super.initState();
    _loadEverything();
  }

  Future<void> _loadEverything() async {
    // Kick these off in parallel; period matching happens once both the
    // periods and the invoice have loaded.
    await Future.wait([
      _fetchPeriods(),
      context.read<CustomerProvider>().fetchCustomers(),
      context.read<SupplierProvider>().fetchSuppliers(),
    ]);

    final provider = context.read<EditPurchaseEntryProvider>();
    final loaded = await provider.fetchInvoiceById(widget.invoiceId);

    if (!mounted) return;

    if (!loaded) {
      setState(() {
        _loadError = provider.errorMessage ?? 'Failed to load invoice';
        _initialLoadDone = true;
      });
      return;
    }

    _populateFromInvoice(provider.originalInvoice!);

    setState(() {
      _initialLoadDone = true;
    });
  }

  // ── Fetch period sections from Firestore ──────────────────────────────────
  Future<void> _fetchPeriods() async {
    try {
      final snap = await FirebaseFirestore.instance
          .collection('period_sections')
          .orderBy('sectionNumber')
          .get();

      if (!mounted) return;
      setState(() {
        _periods = snap.docs.map((doc) {
          final data = doc.data();
          DateTime parse(dynamic d) =>
              d is Timestamp ? d.toDate() : DateTime.parse(d.toString());
          return _Period(
            id: doc.id,
            name: data['name'] ?? '',
            startDate: parse(data['startDate']),
            endDate: parse(data['endDate']),
          );
        }).toList();
        _periodsLoading = false;
      });
    } catch (e) {
      if (mounted) setState(() => _periodsLoading = false);
      debugPrint('Error fetching periods: $e');
    }
  }

  /// Find and select a period by its ID
  void _matchPeriod(String periodId) {
    try {
      final match = _periods.firstWhere((p) => p.id == periodId);
      setState(() => _selectedPeriod = match);
    } catch (_) {
      // Period no longer exists — leave unset
    }
  }

  // ── Populate the form from the loaded invoice ─────────────────────────────
  void _populateFromInvoice(PurchaseInvoice inv) {
    _invoiceNoController.text = inv.invoiceNo;
    _invoiceDate = inv.invoiceDate;

    if (inv.periodSectionId.isNotEmpty && _periods.isNotEmpty) {
      _matchPeriod(inv.periodSectionId);
    }

    final customers = context.read<CustomerProvider>().customers;
    try {
      _selectedCustomer = customers.firstWhere((c) => c.id == inv.customerId);
    } catch (_) {
      _selectedCustomer = Customer(
        id: inv.customerId,
        name: inv.customerName,
        phone: '',
        address: '',
        taxNumber: inv.customerVatNumber,
        zatcaEnabled: false,
      );
    }

    final suppliers = context.read<SupplierProvider>().suppliers;
    try {
      _selectedSupplier = suppliers.firstWhere((s) => s.id == inv.supplierId);
    } catch (_) {
      _selectedSupplier = Supplier(
        id: inv.supplierId,
        name: inv.supplierName,
        vatNumber: '',
        phone: '',
        address: '',
      );
    }

    _clearEntryAmountFields();
  }

  @override
  void dispose() {
    _invoiceNoController.dispose();
    _amountExVatController.dispose();
    _vatRateController.dispose();
    _vatAmountController.dispose();
    _totalIncVatController.dispose();
    _customerSearchController.dispose();
    _supplierSearchController.dispose();
    super.dispose();
  }

  // ── Customer search ───────────────────────────────────────────────────────
  void _filterCustomers(String query) {
    final customers = context.read<CustomerProvider>().customers;
    setState(() {
      _filteredCustomers = query.isEmpty
          ? customers
          : customers
                .where(
                  (c) =>
                      c.name.toLowerCase().contains(query.toLowerCase()) ||
                      c.phone.contains(query),
                )
                .toList();
      _showCustomerDropdown = true;
    });
  }

  void _selectCustomer(Customer c) => setState(() {
    _selectedCustomer = c;
    _selectedSupplier = null;
    _showCustomerDropdown = false;
    _customerSearchController.clear();
  });

  // ── Supplier search ───────────────────────────────────────────────────────
  void _filterSuppliers(String query) {
    final suppliers = context.read<SupplierProvider>().suppliers;
    setState(() {
      _filteredSuppliers = query.isEmpty
          ? suppliers
          : suppliers
                .where(
                  (s) =>
                      s.name.toLowerCase().contains(query.toLowerCase()) ||
                      s.phone.contains(query),
                )
                .toList();
      _showSupplierDropdown = true;
    });
  }

  void _selectSupplier(Supplier s) => setState(() {
    _selectedSupplier = s;
    _showSupplierDropdown = false;
    _supplierSearchController.clear();
  });

  // ── VAT calculations ──────────────────────────────────────────────────────
  void _calculateFromAmountExVat() {
    final amount = double.tryParse(_amountExVatController.text) ?? 0;
    final rate = double.tryParse(_vatRateController.text) ?? 0;
    setState(() {
      _vatAmountController.text = (amount * rate / 100).toStringAsFixed(2);
      _totalIncVatController.text = (amount + amount * rate / 100)
          .toStringAsFixed(2);
    });
  }

  void _calculateFromVatAmount() {
    final vat = double.tryParse(_vatAmountController.text) ?? 0;
    final rate = double.tryParse(_vatRateController.text) ?? 0;
    if (rate == 0) return;
    final amount = vat / (rate / 100);
    setState(() {
      _amountExVatController.text = amount.toStringAsFixed(2);
      _totalIncVatController.text = (amount + vat).toStringAsFixed(2);
    });
  }

  void _calculateFromTotal() {
    final total = double.tryParse(_totalIncVatController.text) ?? 0;
    final rate = double.tryParse(_vatRateController.text) ?? 0;
    if (rate == 0) return;
    final amount = total / (1 + rate / 100);
    setState(() {
      _amountExVatController.text = amount.toStringAsFixed(2);
      _vatAmountController.text = (total - amount).toStringAsFixed(2);
    });
  }

  // ── Date picker ───────────────────────────────────────────────────────────
  Future<void> _pickInvoiceDate() async {
    final picked = await showDatePicker(
      context: context,
      initialDate: _invoiceDate ?? DateTime.now(),
      firstDate: DateTime(2020),
      lastDate: DateTime(2035),
    );
    if (picked != null) setState(() => _invoiceDate = picked);
  }

  // ── Add / update a local (unsaved) entry ─────────────────────────────────
  Future<void> _addEntry() async {
    if (!_validateInvoiceForm()) return;

    if (!await _checkInvoiceNumberUnique()) return;

    final amountExVat = double.tryParse(_amountExVatController.text) ?? 0;
    if (amountExVat <= 0) {
      _showMsg('Amount must be greater than 0', Colors.orange);
      return;
    }

    final provider = context.read<EditPurchaseEntryProvider>();

    if (_editingIndex != null) {
      final success = provider.updateItem(
        _editingIndex!,
        date: _invoiceDate!,
        invoiceNo: _invoiceNoController.text.trim(),
        supplierName: _selectedSupplier!.name,
        supplierId: _selectedSupplier!.id!,
        vatNumber: _selectedSupplier!.vatNumber,
        amountExVat: amountExVat,
        vatRate: double.tryParse(_vatRateController.text) ?? 0,
        vatAmount: double.tryParse(_vatAmountController.text) ?? 0,
        totalIncVat: double.tryParse(_totalIncVatController.text) ?? 0,
      );
      if (!success) {
        _showMsg('Invoice number duplicates another entry', Colors.orange);
        return;
      }
      _editingIndex = null;
      _amountExVatController.clear();
      _vatAmountController.clear();
      _totalIncVatController.clear();
      _vatRateController.text = '15';
      _showMsg('Entry updated', Colors.green);
      return;
    }

    final added = provider.addItem(
      date: _invoiceDate!,
      invoiceNo: _invoiceNoController.text.trim(),
      supplierName: _selectedSupplier!.name,
      supplierId: _selectedSupplier!.id!,
      vatNumber: _selectedSupplier!.vatNumber,
      amountExVat: amountExVat,
      vatRate: double.tryParse(_vatRateController.text) ?? 0,
      vatAmount: double.tryParse(_vatAmountController.text) ?? 0,
      totalIncVat: double.tryParse(_totalIncVatController.text) ?? 0,
    );

    if (!added) {
      _showMsg(
        'This invoice number is already added to the current invoice',
        Colors.orange,
      );
      return;
    }

    _amountExVatController.clear();
    _vatAmountController.clear();
    _totalIncVatController.clear();
    _vatRateController.text = '15';
    _showMsg('Entry added', Colors.green);
  }

  // ── Save (update) ─────────────────────────────────────────────────────────
  Future<void> _saveInvoice() async {
    // Prevent double-tap submission
    if (_isSaving) return;

    final provider = context.read<EditPurchaseEntryProvider>();

    if (provider.items.isEmpty) {
      _showMsg('Please add at least one entry', Colors.orange);
      return;
    }
    if (!_validateInvoiceForm()) return;
    if (!await _checkInvoiceNumberUnique()) return;

    setState(() => _isSaving = true);

    final success = await provider.updateInvoice(
      invoiceId: widget.invoiceId,
      customerId: _selectedCustomer!.id,
      customerName: _selectedCustomer!.name,
      customerVatNumber: _selectedCustomer!.taxNumber,
      supplierId: _selectedSupplier!.id!,
      supplierName: _selectedSupplier!.name,
      invoiceNo: _invoiceNoController.text.trim(),
      invoiceDate: _invoiceDate!,
      periodSectionId: _selectedPeriod?.id,
      periodSectionName: _selectedPeriod?.name,
    );

    if (success && mounted) {
      _showMsg('Invoice updated successfully!', Colors.green);
      Navigator.pop(context, true);
      return;
    }

    if (!success && mounted) {
      _showMsg(provider.errorMessage ?? 'Error updating invoice', Colors.red);
    }
    if (mounted) setState(() => _isSaving = false);
  }

  void _clearEntryAmountFields() {
    _amountExVatController.clear();
    _vatAmountController.clear();
    _totalIncVatController.clear();
    _vatRateController.text = '15';
  }

  bool _validateInvoiceForm() {
    if (_selectedCustomer == null) {
      _showMsg('Please select a customer', Colors.orange);
      return false;
    }
    if (_selectedSupplier == null) {
      _showMsg('Please select a supplier', Colors.orange);
      return false;
    }
    if (_invoiceNoController.text.trim().isEmpty) {
      _showMsg('Please enter invoice number', Colors.orange);
      return false;
    }
    if (_invoiceDate == null) {
      _showMsg('Please select invoice date', Colors.orange);
      return false;
    }
    return true;
  }

  Future<bool> _checkInvoiceNumberUnique() async {
    final invoiceNo = _invoiceNoController.text.trim();
    if (invoiceNo.isEmpty) return false;

    final provider = context.read<EditPurchaseEntryProvider>();
    final exists = await provider.invoiceNumberExists(
      invoiceNo,
      excludeInvoiceId: widget.invoiceId,
    );

    if (provider.errorMessage != null) {
      _showMsg(provider.errorMessage!, Colors.red);
      return false;
    }

    if (exists) {
      _showMsg('Invoice number "$invoiceNo" already exists.', Colors.orange);
      return false;
    }
    return true;
  }

  // ── Bulk import helpers ─────────────────────────────────────────────────
  void _openBulkImportDialog() {
    final pasteController = TextEditingController();
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Bulk Import'),
        content: SizedBox(
          width: 600,
          child: SingleChildScrollView(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  'Paste CSV/text (columns: invoiceNo,date(dd/MM/yyyy),supplierId|supplierName,amountExVat,vatRate,total[,vatNumber])',
                ),
                const SizedBox(height: 8),
                TextField(
                  controller: pasteController,
                  minLines: 6,
                  maxLines: 14,
                  decoration: InputDecoration(
                    hintText: 'Paste CSV lines here',
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(8),
                    ),
                  ),
                ),
                const SizedBox(height: 8),
                Row(
                  children: [
                    ElevatedButton(
                      onPressed: () async {
                        Navigator.of(ctx).pop();
                        await _processBulkText(pasteController.text);
                      },
                      child: const Text('Import Paste'),
                    ),
                    const SizedBox(width: 12),
                    ElevatedButton(
                      onPressed: () async {
                        Navigator.of(ctx).pop();
                        await _pickCsvFile();
                      },
                      child: const Text('Upload CSV'),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Future<void> _pickCsvFile() async {
    try {
      final result = await FilePicker.platform.pickFiles(
        type: FileType.custom,
        allowedExtensions: ['csv', 'txt'],
        withData: true,
      );
      if (result == null || result.files.isEmpty) return;
      final file = result.files.first;
      final content = file.bytes != null
          ? utf8.decode(file.bytes!)
          : await File(file.path!).readAsString();
      await _processBulkText(content);
    } catch (e) {
      _showMsg('Error reading file: $e', Colors.red);
    }
  }

  Future<void> _processBulkText(String text) async {
    if (text.trim().isEmpty) {
      _showMsg('No data provided', Colors.orange);
      return;
    }

    final lines = text
        .split(RegExp(r'\r?\n'))
        .where((l) => l.trim().isNotEmpty)
        .toList();
    int added = 0;
    int skipped = 0;
    final errors = <String>[];

    final supplierList = context.read<SupplierProvider>().suppliers;
    final provider = context.read<EditPurchaseEntryProvider>();

    for (var i = 0; i < lines.length; i++) {
      final line = lines[i];
      final cols = line.split(',').map((c) => c.trim()).toList();
      if (cols.length < 6) {
        errors.add('Line ${i + 1}: not enough columns');
        skipped++;
        continue;
      }

      final invoiceNo = cols[0].trim();
      final dateStr = cols[1].trim();
      final supplierKey = cols[2].trim();
      final amountStr = cols[3].trim();
      final vatRateStr = cols[4].trim();
      final totalStr = cols[5].trim();
      final vatNumber = cols.length > 6 ? cols[6].trim() : '';

      // Parse date
      DateTime date;
      try {
        final parts = dateStr.split('/');
        if (parts.length != 3) throw 'Invalid date';
        date = DateTime(
          int.parse(parts[2]),
          int.parse(parts[1]),
          int.parse(parts[0]),
        );
      } catch (e) {
        errors.add('Line ${i + 1}: invalid date "$dateStr"');
        skipped++;
        continue;
      }

      final amount =
          double.tryParse(amountStr.replaceAll(',', '')) ?? double.nan;
      final vatRate = double.tryParse(vatRateStr.replaceAll(',', '')) ?? 0;
      final total = double.tryParse(totalStr.replaceAll(',', '')) ?? double.nan;
      if (amount.isNaN) {
        errors.add('Line ${i + 1}: invalid amount "$amountStr"');
        skipped++;
        continue;
      }

      // Resolve supplier
      Supplier? supplier;
      supplier = supplierList.firstWhere(
        (s) =>
            s.id == supplierKey ||
            s.name.toLowerCase() == supplierKey.toLowerCase(),
        orElse: () =>
            Supplier(id: '', name: '', vatNumber: '', phone: '', address: ''),
      );
      if (supplier.id!.isEmpty) {
        errors.add('Line ${i + 1}: supplier "$supplierKey" not found');
        skipped++;
        continue;
      }

      // Check global duplicate in Firestore (excluding this invoice itself)
      final existsGlobal = await provider.invoiceNumberExists(
        invoiceNo,
        excludeInvoiceId: widget.invoiceId,
      );
      if (existsGlobal) {
        errors.add(
          'Line ${i + 1}: invoiceNo "$invoiceNo" already exists in database',
        );
        skipped++;
        continue;
      }

      // Add to local provider (addItem returns false if local duplicate)
      final addedLocal = provider.addItem(
        date: date,
        invoiceNo: invoiceNo,
        supplierName: supplier.name,
        supplierId: supplier.id ?? '',
        vatNumber: vatNumber,
        amountExVat: amount,
        vatRate: vatRate,
        vatAmount: (total - amount).isNaN
            ? (amount * vatRate / 100)
            : (total - amount),
        totalIncVat: total.isNaN ? (amount + amount * vatRate / 100) : total,
      );

      if (!addedLocal) {
        errors.add(
          'Line ${i + 1}: duplicate invoiceNo "$invoiceNo" in current session',
        );
        skipped++;
        continue;
      }

      added++;
    }

    final msg = 'Bulk import finished: $added added, $skipped skipped.';
    _showMsg(msg, errors.isEmpty ? Colors.green : Colors.orange);
    if (errors.isNotEmpty) {
      // Show detailed errors in dialog
      showDialog(
        context: context,
        builder: (c) => AlertDialog(
          title: const Text('Import Errors'),
          content: SizedBox(
            width: 600,
            child: SingleChildScrollView(
              child: Text(
                errors.join('\n'),
                style: const TextStyle(fontSize: 13),
              ),
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(c),
              child: const Text('Close'),
            ),
          ],
        ),
      );
    }
  }

  void _showMsg(String msg, Color color) => ScaffoldMessenger.of(
    context,
  ).showSnackBar(SnackBar(content: Text(msg), backgroundColor: color));

  Future<void> _scanQr() async {
    final data = await showDialog<ZatcaQrData>(
      context: context,
      builder: (context) {
        return Dialog(
          insetPadding: EdgeInsets.all(20),
          child: SizedBox(width: 400, height: 450, child: QrScannerScreen()),
        );
      },
    );
    if (data == null || !mounted) return;

    // ── Fill supplier fields ───────────────────────────────────────────────
    // Try to match an existing supplier by VAT number
    final suppliers = context.read<SupplierProvider>().suppliers;
    Supplier? matched;
    try {
      matched = suppliers.firstWhere(
        (s) => s.vatNumber.trim() == data.vatNumber.trim(),
      );
    } catch (_) {
      // No match — create a temporary placeholder so the form is pre-filled
      matched = Supplier(
        id: '',
        name: data.sellerName,
        vatNumber: data.vatNumber,
        phone: '',
        address: '',
      );
    }

    // ── Fill invoice date ──────────────────────────────────────────────────
    DateTime? parsedDate;
    try {
      parsedDate = DateTime.parse(data.invoiceDate);
    } catch (_) {
      // Some QR codes use "dd/MM/yyyy HH:mm:ss" — try that too
      try {
        final parts = data.invoiceDate.split(' ');
        final dateParts = parts[0].split('/');
        if (dateParts.length == 3) {
          parsedDate = DateTime(
            int.parse(dateParts[2]),
            int.parse(dateParts[1]),
            int.parse(dateParts[0]),
          );
        }
      } catch (_) {}
    }

    // ── Fill amount fields ─────────────────────────────────────────────────

    final totalIncVat = double.tryParse(data.totalIncVat) ?? 0;
    final vatAmount = double.tryParse(data.vatAmount) ?? 0;
    final amountExVat = totalIncVat - vatAmount;
    final vatRate = (amountExVat > 0)
        ? ((vatAmount / amountExVat) * 100).roundToDouble()
        : 15.0;

    setState(() {
      _selectedSupplier = matched;

      if (parsedDate != null) _invoiceDate = parsedDate;
      _amountExVatController.text = amountExVat.toStringAsFixed(2);
      _vatAmountController.text = vatAmount.toStringAsFixed(2);
      _totalIncVatController.text = totalIncVat.toStringAsFixed(2);
      _vatRateController.text = vatRate.toStringAsFixed(0);
    });

    _showMsg('QR scanned: ${data.sellerName}', Colors.green);
  }

  // ── Build ─────────────────────────────────────────────────────────────────
  @override
  Widget build(BuildContext context) {
    if (!_initialLoadDone) {
      return Scaffold(
        backgroundColor: Colors.grey.shade50,
        appBar: AppBar(
          toolbarHeight: 50,
          backgroundColor: Colors.white,
          elevation: 0,
          centerTitle: true,
          title: const Text(
            'Edit Purchase Entry',
            style: TextStyle(fontSize: 16, fontWeight: FontWeight.w600),
          ),
        ),
        body: const Center(child: CircularProgressIndicator()),
      );
    }

    if (_loadError != null) {
      return Scaffold(
        backgroundColor: Colors.grey.shade50,
        appBar: AppBar(
          toolbarHeight: 50,
          backgroundColor: Colors.white,
          elevation: 0,
          centerTitle: true,
          title: const Text(
            'Edit Purchase Entry',
            style: TextStyle(fontSize: 16, fontWeight: FontWeight.w600),
          ),
        ),
        body: Center(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(Icons.error_outline, size: 48, color: Colors.red.shade400),
              const SizedBox(height: 12),
              Text(_loadError!, style: TextStyle(color: Colors.grey.shade700)),
              const SizedBox(height: 16),
              ElevatedButton(
                onPressed: () => Navigator.pop(context),
                child: const Text('Go Back'),
              ),
            ],
          ),
        ),
      );
    }

    return Scaffold(
      backgroundColor: Colors.grey.shade50,
      appBar: AppBar(
        toolbarHeight: 50,
        automaticallyImplyLeading: false,
        backgroundColor: Colors.white,
        scrolledUnderElevation: 0,
        elevation: 0,
        centerTitle: true,
        title: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            InkWell(
              onTap: () {
                context.read<EditPurchaseEntryProvider>().reset();
                Navigator.pop(context);
              },
              child: Container(
                height: 40,
                width: 40,
                decoration: BoxDecoration(
                  color: Colors.white,
                  boxShadow: [
                    BoxShadow(color: Colors.grey.shade300, blurRadius: 4),
                  ],
                  borderRadius: BorderRadius.circular(100),
                ),
                child: const Icon(Icons.keyboard_arrow_left_rounded, size: 28),
              ),
            ),
            const Text(
              'Edit Purchase Entry',
              style: TextStyle(fontSize: 16, fontWeight: FontWeight.w600),
            ),
             Padding(
              padding: const EdgeInsets.only(bottom: 12),
              child: DropdownButtonHideUnderline(
                child: DropdownButton<String>(
                  value: _sortBy,
                  isDense: true,
                  items: const [
                    DropdownMenuItem(value: 'date_desc', child: Text('Sort: Newest')),
                    DropdownMenuItem(value: 'date_asc', child: Text('Sort: Oldest')),
                    DropdownMenuItem(value: 'supplier_asc', child: Text('Sort: Supplier A-Z')),
                    DropdownMenuItem(value: 'supplier_desc', child: Text('Sort: Supplier Z-A')),
                    DropdownMenuItem(value: 'amount_desc', child: Text('Sort: Amount High-Low')),
                    DropdownMenuItem(value: 'amount_asc', child: Text('Sort: Amount Low-High')),
                  ],
                  onChanged: (value) {
                    if (value == null) return;
                    setState(() {
                      _sortBy = value;
                    });
                  },
                ),
              ),
            ),
            Container(
              padding: const EdgeInsets.symmetric(
                horizontal: 10,
                vertical: 4,
              ),
              decoration: BoxDecoration(
                color: Colors.orange.shade100,
                borderRadius: BorderRadius.circular(20),
              ),
              child: Text(
                'Editing',
                style: TextStyle(
                  fontSize: 11,
                  color: Colors.orange.shade800,
                  fontWeight: FontWeight.w600,
                ),
              ),
            ),
            Row(
              children: [
                SizedBox(
                  width: 200,
                  child: ElevatedButton(
                    onPressed: 
                     _isSaving ? null : 
                    _saveInvoice,
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.blue.shade900,
                      foregroundColor: Colors.white,
                      disabledBackgroundColor: Colors.grey,
                      minimumSize: const Size(double.infinity, 50),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(10),
                      ),
                    ),
                    child: const Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Icon(Icons.update_rounded),
                              SizedBox(width: 8),
                              Text(
                                'Update Invoice',
                                style: TextStyle(fontSize: 16),
                              ),
                            ],
                          ),
                  ),
                ),
                GestureDetector(onTap: (){setState(() {
                  _isSaving=false;
                });
                }, child: Icon(Icons.refresh)),
              ],
            )
          ],
        ),
      ),
      body: Form(
        key: _formKey,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Expanded(
              child: Row(
                children: [
                  // ── Entries table ────────────────────────────────────────
                  Expanded(
                    child: Row(
                      children: [
                        Padding(
                          padding: const EdgeInsets.only(
                            left: 16.0,
                            right: 16,
                            top: 16,
                          ),
                          child: _buildTotalsSummary(),
                        ),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              _buildSectionHeader('Purchase Entries'),
                              const SizedBox(height: 10),
                              Expanded(
                                child: SingleChildScrollView(
                                  child: _buildEntriesTable(),
                                ),
                              ),

                              const SizedBox(height: 16),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(width: 16),
                  Container(
                    margin: EdgeInsets.only(left: 16, right: 16, top: 16),
                    padding: EdgeInsets.all(16),
                    width: 400,
                    decoration: BoxDecoration(
                      color: Colors.white,
                      boxShadow: [
                        BoxShadow(
                          color: Colors.black.withOpacity(0.1),
                          blurRadius: 10,
                          spreadRadius: 1,
                          offset: Offset(0, 0),
                        ),
                      ],

                      borderRadius: BorderRadius.circular(14),
                    ),
                    child: Column(
                      children: [
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              _buildFieldLabel('Period Section'),
                              _periodsLoading
                                  ? Container(
                                      height: 50,
                                      decoration: BoxDecoration(
                                        border: Border.all(
                                          color: Colors.grey.shade300,
                                        ),
                                        borderRadius: BorderRadius.circular(8),
                                      ),
                                      child: const Center(
                                        child: SizedBox(
                                          width: 18,
                                          height: 18,
                                          child: CircularProgressIndicator(
                                            strokeWidth: 2,
                                          ),
                                        ),
                                      ),
                                    )
                                  : _periods.isEmpty
                                  ? Container(
                                      padding: const EdgeInsets.symmetric(
                                        horizontal: 12,
                                        vertical: 14,
                                      ),
                                      decoration: BoxDecoration(
                                        color: Colors.orange.shade50,
                                        border: Border.all(
                                          color: Colors.orange.shade200,
                                        ),
                                        borderRadius: BorderRadius.circular(8),
                                      ),
                                      child: Row(
                                        children: [
                                          Icon(
                                            Icons.info_outline,
                                            size: 16,
                                            color: Colors.orange.shade700,
                                          ),
                                          const SizedBox(width: 8),
                                          Text(
                                            'No period sections created yet',
                                            style: TextStyle(
                                              fontSize: 13,
                                              color: Colors.orange.shade800,
                                            ),
                                          ),
                                        ],
                                      ),
                                    )
                                  : DropdownButtonFormField<_Period>(
                                      initialValue: _selectedPeriod,
                                      isExpanded: true,
                                      decoration: InputDecoration(
                                        hintText: 'Select period section',
                                        border: OutlineInputBorder(
                                          borderRadius: BorderRadius.circular(
                                            8,
                                          ),
                                        ),
                                        contentPadding:
                                            const EdgeInsets.symmetric(
                                              horizontal: 12,
                                              vertical: 0,
                                            ),
                                        prefixIcon: const Icon(
                                          Icons.date_range_outlined,
                                          size: 18,
                                        ),
                                        // Clear button
                                        suffixIcon: _selectedPeriod != null
                                            ? IconButton(
                                                icon: const Icon(
                                                  Icons.close,
                                                  size: 18,
                                                ),
                                                onPressed: () => setState(
                                                  () => _selectedPeriod = null,
                                                ),
                                              )
                                            : null,
                                      ),
                                      items: _periods.map((period) {
                                        return DropdownMenuItem<_Period>(
                                          value: period,
                                          child: Row(
                                            children: [
                                              Container(
                                                width: 8,
                                                height: 8,
                                                margin: const EdgeInsets.only(
                                                  right: 8,
                                                ),
                                                decoration: const BoxDecoration(
                                                  color: Color(0xFF4F8EF7),
                                                  shape: BoxShape.circle,
                                                ),
                                              ),
                                              Expanded(
                                                child: Column(
                                                  mainAxisAlignment:
                                                      MainAxisAlignment.center,
                                                  crossAxisAlignment:
                                                      CrossAxisAlignment.start,
                                                  mainAxisSize:
                                                      MainAxisSize.min,
                                                  children: [
                                                    Text(
                                                      period.name,
                                                      style: const TextStyle(
                                                        fontSize: 14,
                                                        fontWeight:
                                                            FontWeight.w600,
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                            ],
                                          ),
                                        );
                                      }).toList(),
                                      onChanged: (value) => setState(
                                        () => _selectedPeriod = value,
                                      ),
                                    ),

                              // Show selected period badge
                              if (_selectedPeriod != null) ...[
                                const SizedBox(height: 6),
                                Container(
                                  padding: const EdgeInsets.symmetric(
                                    horizontal: 10,
                                    vertical: 6,
                                  ),
                                  decoration: BoxDecoration(
                                    color: const Color(
                                      0xFF4F8EF7,
                                    ).withOpacity(0.08),
                                    borderRadius: BorderRadius.circular(8),
                                    border: Border.all(
                                      color: const Color(
                                        0xFF4F8EF7,
                                      ).withOpacity(0.3),
                                    ),
                                  ),
                                  child: Row(
                                    children: [
                                      const Icon(
                                        Icons.check_circle_outline,
                                        size: 14,
                                        color: Color(0xFF4F8EF7),
                                      ),
                                      const SizedBox(width: 6),
                                      Text(
                                        '${_selectedPeriod!.name}  ·  ${_selectedPeriod!.range}',
                                        style: const TextStyle(
                                          fontSize: 12,
                                          color: Color(0xFF4F8EF7),
                                          fontWeight: FontWeight.w500,
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ],
                              const SizedBox(height: 8),
                              // ── Customer ───────────────────────────────────────────────
                              _buildSectionHeader('Select Customer'),
                              const SizedBox(height: 10),
                              if (_selectedCustomer != null)
                                _buildSelectedCard(
                                  title: _selectedCustomer!.name,
                                  subtitle: _selectedCustomer!.phone,
                                  color: Colors.blue.shade50,
                                  accentColor: Colors.blue.shade700,
                                  icon: Icons.person_outline,
                                  onClear: () => setState(() {
                                    _selectedCustomer = null;
                                    _selectedSupplier = null;
                                  }),
                                )
                              else
                                _buildSearchField(
                                  controller: _customerSearchController,
                                  hintText: 'Search customer...',
                                  onChanged: _filterCustomers,
                                  showDropdown: _showCustomerDropdown,
                                  items: _filteredCustomers
                                      .map(
                                        (c) => ListTile(
                                          leading: CircleAvatar(
                                            backgroundColor:
                                                Colors.blue.shade100,
                                            child: Text(
                                              c.name[0].toUpperCase(),
                                              style: TextStyle(
                                                color: Colors.blue.shade700,
                                              ),
                                            ),
                                          ),
                                          title: Text(c.name),
                                          subtitle: Text(c.phone),
                                          onTap: () => _selectCustomer(c),
                                        ),
                                      )
                                      .toList(),
                                  onTap: () {
                                    showDialog(
                                      context: context,
                                      builder: (context) => AlertDialog(
                                        contentPadding: EdgeInsets.zero,
                                        insetPadding: EdgeInsets.all(16),
                                        content: Container(
                                          width: 600,
                                          decoration: BoxDecoration(
                                            borderRadius: BorderRadius.circular(
                                              8,
                                            ),
                                          ),
                                          child: CreateCustomerScreen(),
                                        ),
                                      ),
                                    );
                                  },
                                ),

                              const SizedBox(height: 8),

                              // ── Supplier ───────────────────────────────────────────────
                              Row(
                                mainAxisAlignment:
                                    MainAxisAlignment.spaceBetween,
                                children: [
                                  _buildSectionHeader('Select Supplier'),
                                  TextButton.icon(
                                    onPressed: _scanQr,
                                    icon: const Icon(
                                      Icons.qr_code_scanner,
                                      size: 18,
                                    ),
                                    label: const Text(
                                      'Scan QR',
                                      style: TextStyle(fontSize: 13),
                                    ),
                                    style: TextButton.styleFrom(
                                      foregroundColor: Colors.blue.shade700,
                                      padding: const EdgeInsets.symmetric(
                                        horizontal: 10,
                                        vertical: 6,
                                      ),
                                      backgroundColor: Colors.blue.shade50,
                                      shape: RoundedRectangleBorder(
                                        borderRadius: BorderRadius.circular(20),
                                      ),
                                    ),
                                  ),
                                ],
                              ),

                              const SizedBox(height: 10),
                              if (_selectedSupplier != null)
                                _buildSelectedCard(
                                  title: _selectedSupplier!.name,
                                  subtitle:
                                      'VAT: ${_selectedSupplier!.vatNumber}',
                                  color: Colors.green.shade50,
                                  accentColor: Colors.green.shade700,
                                  icon: Icons.store_outlined,
                                  onClear: () =>
                                      setState(() => _selectedSupplier = null),
                                )
                              else
                                _buildSearchField(
                                  controller: _supplierSearchController,
                                  hintText: 'Search supplier...',
                                  onChanged: _filterSuppliers,
                                  showDropdown: _showSupplierDropdown,
                                  items: _filteredSuppliers
                                      .map(
                                        (s) => ListTile(
                                          leading: CircleAvatar(
                                            backgroundColor:
                                                Colors.green.shade100,
                                            child: Text(
                                              s.name[0].toUpperCase(),
                                              style: TextStyle(
                                                color: Colors.green.shade700,
                                              ),
                                            ),
                                          ),
                                          title: Text(s.name),
                                          subtitle: Text('VAT: ${s.vatNumber}'),
                                          onTap: () => _selectSupplier(s),
                                        ),
                                      )
                                      .toList(),
                                  onTap: () {showDialog(
                                      context: context,
                                      builder: (context) => AlertDialog(
                                        contentPadding: EdgeInsets.zero,
                                        insetPadding: EdgeInsets.all(16),
                                        content: Container(
                                          width: 500,
                                          decoration: BoxDecoration(
                                            borderRadius: BorderRadius.circular(
                                              8,
                                            ),
                                          ),
                                          child: CreateSupplierScreen(),
                                        ),
                                      ),
                                    );},
                                ),

                              const SizedBox(height: 8),
                              // ── Invoice details ────────────────────────────────────────
                              _buildSectionHeader('Invoice Details'),
                              const SizedBox(height: 8),

                              // Invoice No + Date
                              Row(
                                children: [
                                  Expanded(
                                    child: Column(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                      children: [
                                        _buildFieldLabel('Invoice Number *'),
                                        TextFormField(
                                          controller: _invoiceNoController,
                                          decoration: InputDecoration(
                                            hintText: 'Invoice No',
                                            border: OutlineInputBorder(
                                              borderRadius:
                                                  BorderRadius.circular(8),
                                            ),
                                            contentPadding:
                                                const EdgeInsets.symmetric(
                                                  horizontal: 12,
                                                  vertical: 12,
                                                ),
                                          ),
                                          validator: (v) =>
                                              (v == null || v.trim().isEmpty)
                                              ? 'Required'
                                              : null,
                                        ),
                                      ],
                                    ),
                                  ),
                                  const SizedBox(width: 12),
                                  Expanded(
                                    child: Column(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                      children: [
                                        _buildFieldLabel('Purchase Date *'),
                                        GestureDetector(
                                          onTap: _pickInvoiceDate,
                                          child: InputDecorator(
                                            decoration: InputDecoration(
                                              border: OutlineInputBorder(
                                                borderRadius:
                                                    BorderRadius.circular(8),
                                              ),
                                              prefixIcon: const Icon(
                                                Icons.calendar_today,
                                                size: 18,
                                              ),
                                              contentPadding:
                                                  const EdgeInsets.symmetric(
                                                    horizontal: 12,
                                                    vertical: 12,
                                                  ),
                                            ),
                                            child: Text(
                                              _invoiceDate != null
                                                  ? DateFormat(
                                                      'dd/MM/yyyy',
                                                    ).format(_invoiceDate!)
                                                  : 'Select date',
                                              style: TextStyle(
                                                color: _invoiceDate != null
                                                    ? Colors.black
                                                    : Colors.grey.shade500,
                                                fontSize: 14,
                                              ),
                                            ),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ],
                              ),

                              const SizedBox(height: 8),

                              // ── Amount fields ────────────────────────────────────────
                              Row(
                                children: [
                                  Expanded(
                                    flex: 2,
                                    child: Column(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                      children: [
                                        _buildFieldLabel(
                                          'Amount (Excl. VAT) *',
                                        ),
                                        TextFormField(
                                          controller: _amountExVatController,
                                          keyboardType:
                                              const TextInputType.numberWithOptions(
                                                decimal: true,
                                              ),
                                          onChanged: (_) =>
                                              _calculateFromAmountExVat(),
                                          decoration: InputDecoration(
                                            hintText: '0.00',
                                            border: OutlineInputBorder(
                                              borderRadius:
                                                  BorderRadius.circular(8),
                                            ),
                                            contentPadding:
                                                const EdgeInsets.symmetric(
                                                  horizontal: 12,
                                                  vertical: 12,
                                                ),
                                          ),
                                          validator: (v) {
                                            if (v == null || v.isEmpty) {
                                              return 'Required';
                                            }
                                            if (double.tryParse(v) == null) {
                                              return 'Invalid';
                                            }
                                            return null;
                                          },
                                        ),
                                      ],
                                    ),
                                  ),
                                  const SizedBox(width: 12),
                                  Expanded(
                                    child: Column(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                      children: [
                                        _buildFieldLabel('VAT Rate (%)'),
                                        TextFormField(
                                          controller: _vatRateController,
                                          keyboardType:
                                              const TextInputType.numberWithOptions(
                                                decimal: true,
                                              ),
                                          onChanged: (_) =>
                                              _calculateFromAmountExVat(),
                                          decoration: InputDecoration(
                                            prefixIcon: const Icon(
                                              Icons.percent_outlined,
                                              size: 18,
                                            ),
                                            border: OutlineInputBorder(
                                              borderRadius:
                                                  BorderRadius.circular(8),
                                            ),
                                            contentPadding:
                                                const EdgeInsets.symmetric(
                                                  horizontal: 12,
                                                  vertical: 12,
                                                ),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ],
                              ),
                              const SizedBox(height: 8),

                              Row(
                                children: [
                                  Expanded(
                                    child: Column(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                      children: [
                                        _buildFieldLabel('VAT Amount'),
                                        TextFormField(
                                          controller: _vatAmountController,
                                          keyboardType:
                                              const TextInputType.numberWithOptions(
                                                decimal: true,
                                              ),
                                          onChanged: (_) =>
                                              _calculateFromVatAmount(),
                                          decoration: InputDecoration(
                                            hintText: '0.00',
                                            border: OutlineInputBorder(
                                              borderRadius:
                                                  BorderRadius.circular(8),
                                            ),
                                            contentPadding:
                                                const EdgeInsets.symmetric(
                                                  horizontal: 12,
                                                  vertical: 12,
                                                ),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                  const SizedBox(width: 12),
                                  Expanded(
                                    child: Column(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                      children: [
                                        _buildFieldLabel('Total (Incl. VAT)'),
                                        TextFormField(
                                          controller: _totalIncVatController,
                                          keyboardType:
                                              const TextInputType.numberWithOptions(
                                                decimal: true,
                                              ),
                                          onChanged: (_) =>
                                              _calculateFromTotal(),
                                          decoration: InputDecoration(
                                            hintText: '0.00',
                                            border: OutlineInputBorder(
                                              borderRadius:
                                                  BorderRadius.circular(8),
                                            ),
                                            contentPadding:
                                                const EdgeInsets.symmetric(
                                                  horizontal: 12,
                                                  vertical: 12,
                                                ),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ],
                              ),

                              const SizedBox(height: 16),

                              // ── Add Entry button ─────────────────────────────────────
                            ],
                          ),
                        ),
                        GestureDetector(
                          onTap: () => _addEntry(),
                          child: Container(
                            padding: const EdgeInsets.symmetric(vertical: 12),
                            decoration: BoxDecoration(
                              color: Colors.white,
                              borderRadius: BorderRadius.circular(8),
                              boxShadow: [
                                BoxShadow(
                                  color: Colors.black.withOpacity(0.12),
                                  blurRadius: 6,
                                ),
                              ],
                            ),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Icon(_editingIndex != null ? Icons.update : Icons.add, size: 20),
                                const SizedBox(width: 6),
                                Text(
                                  _editingIndex != null ? 'Update Entry' : 'Add Entry',
                                  style: const TextStyle(
                                    fontSize: 15,
                                    fontWeight: FontWeight.w600,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 16),
          ],
        ),
      ),
    );
  }

  // ── Entries table ─────────────────────────────────────────────────────────
  Widget _buildEntriesTable() {
    return Consumer<EditPurchaseEntryProvider>(
      builder: (context, provider, _) {
        if (provider.items.isEmpty) {
          return Container(
            padding: const EdgeInsets.all(24),
            decoration: BoxDecoration(
              border: Border.all(color: Colors.grey.shade300),
              borderRadius: BorderRadius.circular(8),
            ),
            child: Center(
              child: Text(
                'No entries added yet',
                style: TextStyle(color: Colors.grey.shade600, fontSize: 14),
              ),
            ),
          );
        }

        final sortedItems = _getSortedItems(provider.items);

        return DataTable(
          columnSpacing: 16,
          border: TableBorder.all(
            color: Colors.grey.shade300,
            borderRadius: BorderRadius.circular(8),
          ),
          headingRowColor: WidgetStateProperty.all(Colors.grey.shade100),
          columns: const [
              DataColumn(
                label: Text(
        'SL',
        style: TextStyle(fontWeight: FontWeight.bold, fontSize: 12),
                ),
              ),
              DataColumn(
                label: Text(
        'Invoice Date',
        style: TextStyle(fontWeight: FontWeight.bold, fontSize: 12),
                ),
              ),
              DataColumn(
                label: Text(
        'Invoice No',
        style: TextStyle(fontWeight: FontWeight.bold, fontSize: 12),
                ),
              ),
              DataColumn(
                label: Text(
        'Supplier',
        style: TextStyle(fontWeight: FontWeight.bold, fontSize: 12),
                ),
              ),
              DataColumn(
                label: Text(
        'VAT NO',
        style: TextStyle(fontWeight: FontWeight.bold, fontSize: 12),
                ),
              ),
            
              DataColumn(
                label: Text(
        'Amount (Excl.VAT)',
        style: TextStyle(fontWeight: FontWeight.bold, fontSize: 12),
                ),
                numeric: true,
              ),
              DataColumn(
                label: Text(
        'VAT',
        style: TextStyle(fontWeight: FontWeight.bold, fontSize: 12),
                ),
                numeric: true,
              ),
              DataColumn(
                label: Text(
        'Total (Incl.VAT)',
        style: TextStyle(fontWeight: FontWeight.bold, fontSize: 12),
                ),
                numeric: true,
              ),
              DataColumn(
                label: Text(
        'Action',
        style: TextStyle(fontWeight: FontWeight.bold, fontSize: 12),
                ),
              ),
              ],
          rows: List.generate(sortedItems.length, (index) {
            final item = sortedItems[index];
            // Find original index in provider for edit/delete operations
            final originalIndex = provider.items.indexWhere((i) => i.id == item.id);
            return DataRow(
                color: WidgetStateProperty.all(
        index.isEven ? Colors.grey.shade50 : Colors.white,
                ),
                cells: [
        DataCell(
          Text('${index + 1}', style: const TextStyle(fontSize: 12)),
        ),
        DataCell(
          Text(
            DateFormat('dd/MM/yyyy').format(item.date),
            style: const TextStyle(fontSize: 12),
          ),
        ),
        DataCell(
          SizedBox(
            width: 150,
            child: Text(
              item.invoiceNo,
              style: const TextStyle(fontSize: 12),
            ),
          ),
        ),
        
        DataCell(
          SizedBox(
            width: 250,
            child: Text(
              item.supplierName,
              overflow: TextOverflow.ellipsis,
              maxLines: 2,
              style: const TextStyle(fontSize: 12),
            ),
          ),
        ),
        DataCell(
          Text(item.vatNumber, style: const TextStyle(fontSize: 12)),
        ),
        DataCell(
          Align(
            alignment: Alignment.centerRight,
            child: Text(
              item.amountExVat.toStringAsFixed(2),
              style: const TextStyle(fontSize: 12),
            ),
          ),
        ),
        DataCell(
          Align(
            alignment: Alignment.centerRight,
            child: Text(
              item.vatAmount.toStringAsFixed(2),
              style: const TextStyle(fontSize: 12, color: Colors.green),
            ),
          ),
        ),
        DataCell(
          Align(
            alignment: Alignment.centerRight,
            child: Text(
              item.totalIncVat.toStringAsFixed(2),
              style: const TextStyle(
                fontSize: 12,
                fontWeight: FontWeight.bold,
                color: Colors.purple,
              ),
            ),
          ),
        ),
        DataCell(
          Row(
            children: [
              IconButton(
                icon: const Icon(
                  Icons.edit_outlined,
                  color: Colors.blue,
                  size: 18,
                ),
                onPressed: () {
                  _startEditEntry(originalIndex);
                },
                padding: EdgeInsets.zero,
                constraints: const BoxConstraints(),
              ),
              const SizedBox(width: 8),
              IconButton(
                icon: const Icon(
                  Icons.delete_outline,
                  color: Colors.red,
                  size: 18,
                ),
                onPressed: () {
                  provider.removeItem(originalIndex);
                  // If we were editing this entry, clear the edit state
                  if (_editingIndex != null && _editingIndex == originalIndex) {
                    setState(() {
                      _clearEntryFields();
                    });
                  }
                  _showMsg('Entry removed', Colors.red);
                },
                padding: EdgeInsets.zero,
                constraints: const BoxConstraints(),
              ),
            ],
          ),
        ),
                ],
              );
              }),
        );
      },
    );
  }

  // ── Totals summary ────────────────────────────────────────────────────────
  Widget _buildTotalsSummary() {
    return Consumer<EditPurchaseEntryProvider>(
      builder: (context, provider, _) => Container(
        width: 250,
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: Colors.blue.shade50,
          border: Border.all(color: Colors.blue.shade100),
          borderRadius: BorderRadius.circular(10),
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.start,
          children: [
            _totalItem(
              'Excl. VAT',
              provider.getTotalAmountExVat().toStringAsFixed(2),
              Colors.blue,
            ),
            Container(width: 1, height: 36, color: Colors.blue.shade100),
            _totalItem(
              'VAT',
              provider.getTotalVatAmount().toStringAsFixed(2),
              Colors.green,
            ),
            Container(width: 1, height: 36, color: Colors.blue.shade100),
            _totalItem(
              'Grand Total',
              provider.getTotalAmountIncVat().toStringAsFixed(2),
              Colors.purple,
            ),
            Expanded(
              child: Container(
                width: 1,
                height: 36,
                color: Colors.blue.shade100,
              ),
            ),
            _totalItem(
              'Number of Bills',
              provider.getTotalBills().toString(),
              Colors.grey,
            ),
          ],
        ),
      ),
    );
  }

  Widget _totalItem(String label, String value, Color color) => Container(
    padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 8),
    decoration: BoxDecoration(
      border: Border.all(color: color.withOpacity(0.3)),
      color: color.withOpacity(0.15),
      borderRadius: BorderRadius.circular(8),
    ),
    child: Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Text(
          "$label : ",
          style: TextStyle(
            fontSize: 14,
            fontWeight: FontWeight.w600,
            color: Colors.grey.shade600,
          ),
        ),
        const SizedBox(height: 4),
        Text(
          value,
          style: TextStyle(
            fontSize: 16,
            fontWeight: FontWeight.bold,
            color: Colors.black,
          ),
        ),
      ],
    ),
  );

  // ── Helpers ───────────────────────────────────────────────────────────────
  Widget _buildSectionHeader(String title) => Text(
    title,
    style: const TextStyle(
      fontSize: 15,
      fontWeight: FontWeight.bold,
      color: Colors.black87,
    ),
  );

  Widget _buildFieldLabel(String label) => Padding(
    padding: const EdgeInsets.only(bottom: 6),
    child: Text(
      label,
      style: const TextStyle(
        fontSize: 12,
        fontWeight: FontWeight.w600,
        color: Colors.black87,
      ),
    ),
  );

  Widget _buildSelectedCard({
    required String title,
    required String subtitle,
    required Color color,
    required Color accentColor,
    required IconData icon,
    required VoidCallback onClear,
  }) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
      decoration: BoxDecoration(
        color: color,
        border: Border.all(color: accentColor.withOpacity(0.3)),
        borderRadius: BorderRadius.circular(10),
      ),
      child: Row(
        children: [
          Icon(icon, size: 20, color: accentColor),
          const SizedBox(width: 10),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  style: const TextStyle(
                    fontWeight: FontWeight.w600,
                    fontSize: 14,
                  ),
                  overflow: TextOverflow.ellipsis,
                ),
                Text(
                  subtitle,
                  style: TextStyle(fontSize: 12, color: Colors.grey.shade600),
                  overflow: TextOverflow.ellipsis,
                ),
              ],
            ),
          ),
          IconButton(
            onPressed: onClear,
            icon: const Icon(Icons.close, size: 18),
            padding: EdgeInsets.zero,
            constraints: const BoxConstraints(),
          ),
        ],
      ),
    );
  }

  Widget _buildSearchField({
    required TextEditingController controller,
    required String hintText,
    required Function(String) onChanged,
    required bool showDropdown,
    required List<Widget> items,
    required VoidCallback onTap,
  }) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        SizedBox(
          height: 45,
          child: Row(
            children: [
              Expanded(
                child: TextField(
                  controller: controller,
                  onChanged: onChanged,
                  decoration: InputDecoration(
                    hintText: hintText,

                    focusedBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(8),
                      borderSide: BorderSide(color: Colors.grey.shade300),
                    ),
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(8),
                      borderSide: BorderSide(color: Colors.grey.shade300),
                    ),
                    prefixIcon: const Icon(Icons.search),
                    contentPadding: const EdgeInsets.symmetric(
                      horizontal: 12,
                      vertical: 12,
                    ),
                  ),
                ),
              ),

              GestureDetector(
                onTap: onTap,
                child: Container(
                  margin: const EdgeInsets.only(left: 8),
                  padding: const EdgeInsets.symmetric(
                    horizontal: 10,
                    vertical: 10,
                  ),
                  decoration: BoxDecoration(
                    color: Colors.grey.shade100,
                    borderRadius: BorderRadius.circular(8),
                    border: Border.all(color: Colors.grey.shade300),
                  ),
                  child: Center(
                    child: Icon(
                      Icons.add,
                      size: 20,
                      color: Colors.grey.shade600,
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),

        if (showDropdown && items.isNotEmpty)
          Container(
            margin: const EdgeInsets.only(top: 4),
            decoration: BoxDecoration(
              border: Border.all(color: Colors.grey.shade300),
              borderRadius: BorderRadius.circular(8),
              color: Colors.white,
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withOpacity(0.06),
                  blurRadius: 8,
                  offset: const Offset(0, 4),
                ),
              ],
            ),
            constraints: const BoxConstraints(maxHeight: 200),
            child: ListView(shrinkWrap: true, children: items),
          ),
      ],
    );
  }
}