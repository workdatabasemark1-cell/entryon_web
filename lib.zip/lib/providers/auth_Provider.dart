import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../models/user_model.dart';

class AuthProvider with ChangeNotifier {
  static const String _keyUsername = 'auth_username';
  static const String _keyPassword = 'auth_password';

  // Default credentials (used only the first time)
  static const String _defaultUsername = 'admin';
  static const String _defaultPassword = '123456';

  String _username = _defaultUsername;
  String _password = _defaultPassword;
String masterPassword="ItCom@mlp09okn";
  AppUser? _user;
  bool _isLoading = false;
  String? _errorMessage;

  AppUser? get user => _user;
  bool get isLoading => _isLoading;
  String? get errorMessage => _errorMessage;
  bool get isLoggedIn => _user != null;

  String get currentUsername => _username;

  /// Call this once when the app starts
  Future<void> loadCredentials() async {
    final prefs = await SharedPreferences.getInstance();
    _username = prefs.getString(_keyUsername) ?? _defaultUsername;
    _password = prefs.getString(_keyPassword) ?? _defaultPassword;
    notifyListeners();
  }

  Future<bool> login({
    required String username,
    required String password,
  }) async {
    _isLoading = true;
    _errorMessage = null;
    notifyListeners();

    await Future.delayed(const Duration(milliseconds: 600));

    if (username.trim() == _username && password == _password) {
      _user = AppUser(
        username: _username,
        name: 'Administrator',
      );
      _isLoading = false;
      notifyListeners();
      return true;
    } else {
      _errorMessage = 'Invalid username or password';
      _isLoading = false;
      notifyListeners();
      return false;
    }
  }

  /// Update username & password
  Future<bool> updateCredentials({
    required String currentPassword,
    required String newUsername,
    required String newPassword,
  }) async {
    _isLoading = true;
    _errorMessage = null;
    notifyListeners();

    await Future.delayed(const Duration(milliseconds: 400));

    // Verify current password
    if (currentPassword != _password) {
      _errorMessage = 'Current password is incorrect';
      _isLoading = false;
      notifyListeners();
      return false;
    }

    if (newUsername.trim().isEmpty) {
      _errorMessage = 'Username cannot be empty';
      _isLoading = false;
      notifyListeners();
      return false;
    }

    if (newPassword.length < 4) {
      _errorMessage = 'Password must be at least 4 characters';
      _isLoading = false;
      notifyListeners();
      return false;
    }

    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_keyUsername, newUsername.trim());
    await prefs.setString(_keyPassword, newPassword);

    _username = newUsername.trim();
    _password = newPassword;

    // Keep session if already logged in
    if (_user != null) {
      _user = AppUser(username: _username, name: 'Administrator');
    }

    _isLoading = false;
    notifyListeners();
    return true;
  }

  void logout() {
    _user = null;
    notifyListeners();
  }

  void clearError() {
    _errorMessage = null;
    notifyListeners();
  }
}