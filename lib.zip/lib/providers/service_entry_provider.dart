import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import '../models/service_model.dart';
import '../models/transaction_model.dart';

class ServiceEntryProvider with ChangeNotifier {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  final List<ServiceEntry> _services = [];
  bool _isLoading = false;
  String? _errorMessage;

  List<ServiceEntry> get services => _services;
  bool get isLoading => _isLoading;
  String? get errorMessage => _errorMessage;

  Future<void> fetchServices() async {
    try {
      _isLoading = true;
      _errorMessage = null;
      notifyListeners();

      final snapshot = await _firestore
          .collection('services')
          .orderBy('serviceDate', descending: true)
          .get();

      _services.clear();
      _services.addAll(snapshot.docs.map((doc) => ServiceEntry.fromMap(doc.data(), doc.id)).toList());
      _isLoading = false;
      notifyListeners();
    } catch (e) {
      _errorMessage = 'Error fetching services: $e';
      _isLoading = false;
      notifyListeners();
    }
  }

  Future<bool> addService({
    required String title,
    required String customerName,
    String? customerId,
    String? description,
    required DateTime serviceDate,
    required double amount,
    required double serviceFee,
    required double customerPaidAmount,
    required String paymentStatus,
    required String serviceStatus,
    required String paymentType,
    required DateTime? paymentExpiryDate,
    required List<ServicePurchaseLine> purchaseLines,
  }) async {
    try {
      _isLoading = true;
      _errorMessage = null;
      notifyListeners();

      final id = DateTime.now().millisecondsSinceEpoch.toString();
      final service = ServiceEntry(
        id: id,
        // serviceCode: serviceCode.trim(),
        title: title.trim(),
        customerName: customerName.trim(),
        customerId: customerId,
        description: description?.trim(),
        serviceDate: serviceDate,
        amount: amount,
        serviceFee: serviceFee,
        customerPaidAmount: customerPaidAmount,
        balanceAmount: amount - customerPaidAmount,
        paymentStatus: paymentStatus,
        serviceStatus: serviceStatus,
        paymentType: paymentType,
        paymentExpiryDate: paymentExpiryDate,
        purchaseLines: purchaseLines,
        createdAt: DateTime.now(),
        updatedAt: DateTime.now(),
      );

      await _firestore.collection('services').doc(id).set(service.toMap());

      if (customerPaidAmount > 0) {
        final txn = TransactionModel(
          id: '$id',
          serviceId: id,
          customerId: customerId,
          customerName: customerName.trim(),
          amount: customerPaidAmount,
          balanceAmount: amount - customerPaidAmount,
          paymentType: paymentType,
          paymentDetails: paymentType == 'Card' ? {'note': 'Initial payment during service creation'} : {},
          createdAt: DateTime.now(),
        );
        await _firestore.collection('transactions').doc(txn.id).set(txn.toMap());
      }

      _services.insert(0, service);
      _isLoading = false;
      notifyListeners();
      return true;
    } catch (e) {
      _errorMessage = 'Error saving service: $e';
      _isLoading = false;
      notifyListeners();
      return false;
    }
  }

  Future<bool> updateService({
    required String id,
    required String title,
    required String customerName,
    String? customerId,
    String? description,
    required DateTime serviceDate,
    required double amount,
    required double serviceFee,
    required double customerPaidAmount,
    required String paymentStatus,
    required String serviceStatus,
    required String paymentType,
    required DateTime? paymentExpiryDate,
    required List<ServicePurchaseLine> purchaseLines,
  }) async {
    try {
      _isLoading = true;
      _errorMessage = null;
      notifyListeners();

      final updated = ServiceEntry(
        id: id,
        title: title.trim(),
        customerName: customerName.trim(),
        customerId: customerId,
        description: description?.trim(),
        serviceDate: serviceDate,
        amount: amount,
        serviceFee: serviceFee,
        customerPaidAmount: customerPaidAmount,
        balanceAmount: amount - customerPaidAmount,
        paymentStatus: paymentStatus,
        serviceStatus: serviceStatus,
        paymentType: paymentType,
        paymentExpiryDate: paymentExpiryDate,
        purchaseLines: purchaseLines,
        createdAt: DateTime.now(),
        updatedAt: DateTime.now(),
      );

      await _firestore.collection('services').doc(id).update(updated.toMap());

      final index = _services.indexWhere((s) => s.id == id);
      if (index >= 0) {
        _services[index] = updated;
      }

      _isLoading = false;
      notifyListeners();
      return true;
    } catch (e) {
      _errorMessage = 'Error updating service: $e';
      _isLoading = false;
      notifyListeners();
      return false;
    }
  }

  Future<bool> deleteService(String id) async {
    try {
      _isLoading = true;
      _errorMessage = null;
      notifyListeners();

      await _firestore.collection('services').doc(id).delete();
      _services.removeWhere((service) => service.id == id);
      _isLoading = false;
      notifyListeners();
      return true;
    } catch (e) {
      _errorMessage = 'Error deleting service: $e';
      _isLoading = false;
      notifyListeners();
      return false;
    }
  }
}
