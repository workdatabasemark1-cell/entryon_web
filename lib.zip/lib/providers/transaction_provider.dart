import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import '../models/transaction_model.dart';

class TransactionProvider with ChangeNotifier {
  FirebaseFirestore get _firestore => FirebaseFirestore.instance;

  final List<TransactionModel> _transactions = [];
  bool _isLoading = false;
  String? _errorMessage;

  List<TransactionModel> get transactions => _transactions;
  bool get isLoading => _isLoading;
  String? get errorMessage => _errorMessage;

  Future<bool> addTransaction(TransactionModel txn) async {
    try {
      _isLoading = true;
      _errorMessage = null;
      notifyListeners();

      await _firestore.collection('transactions').doc(txn.id).set(txn.toMap());
      _transactions.insert(0, txn);

      _isLoading = false;
      notifyListeners();
      return true;
    } catch (e) {
      _errorMessage = 'Error saving transaction: $e';
      _isLoading = false;
      notifyListeners();
      return false;
    }
  }

  Future<void> fetchTransactions() async {
    try {
      _isLoading = true;
      _errorMessage = null;
      notifyListeners();

      final snapshot = await _firestore.collection('transactions').orderBy('createdAt', descending: true).get();
      _transactions.clear();
      _transactions.addAll(snapshot.docs.map((d) => TransactionModel.fromMap(d.data(), d.id)).toList());

      _isLoading = false;
      notifyListeners();
    } catch (e) {
      _errorMessage = 'Error fetching transactions: $e';
      _isLoading = false;
      notifyListeners();
    }
  }
}
