class Customer {
  // Basic information
  final String id;
  final String name;
  
  // Contact information
  final String phone;
  final String? phone2;
  final String? email;
  
  // Organization details
  final String? organizationName;
  final String? organizationUnitName;
  final String? commonName;
  final String? businessCategory;
  
  // Address information
  final String address;
  final String? registeredAddress;
  final String? buildingNo;
  final String? streetName;
  final String? districtName;
  final String? cityName;
  final String? zipCode;
  final String? additionalNo;
  final String? unitNo;
  final String? country;
  
  // Tax and registration information
  final String taxNumber; // VAT Number
  final String? crNumber; // Commercial Registration
  final bool? zatcaEnabled; // ZATCA integration enabled or not
  
  // Zatca credentials
  final String? zatcaUsername;
  final String? zatcaPassword;
  
// Period section (optional)
  final String? periodSectionId;
  final String? periodSectionName;


  // Financial Period
  final String? financialPeriodStartDate;
  final String? financialPeriodEndDate;

  // Audit fields
  final String? createdById;
  final String? createdByName;
  final String? editedById;
  final String? editedByName;
  final DateTime? editedDate;
  final DateTime? createdAt;

  // Software information
  final List<String> usedSoftwares;                    // Simple list of software names
  final List<Map<String, dynamic>> softwareActivations; // Detailed activation info

  Customer({
    required this.id,
    required this.name,
    required this.phone,
    required this.address,
    required this.taxNumber,
    this.zatcaEnabled,
    this.phone2,
    this.email,
    this.organizationName,
    this.organizationUnitName,
    this.commonName,
    this.businessCategory,
    this.registeredAddress,
    this.buildingNo,
    this.streetName,
    this.districtName,
    this.cityName,
    this.zipCode,
    this.additionalNo,
    this.unitNo,
    this.country,
    this.crNumber,
    this.zatcaUsername,
    this.zatcaPassword,
    this.periodSectionId,
    this.periodSectionName,
    this.financialPeriodStartDate,
    this.financialPeriodEndDate,
    this.createdById,
    this.createdByName,
    this.editedById,
    this.editedByName,
    this.editedDate,
    this.createdAt,
    this.usedSoftwares = const [],
    this.softwareActivations = const [],
  });

  // Convert Customer object to JSON
  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'name': name,
      'phone': phone,
      'phone2': phone2,
      'email': email,
      'organizationName': organizationName,
      'organizationUnitName': organizationUnitName,
      'commonName': commonName,
      'businessCategory': businessCategory,
      'address': address,
      'registeredAddress': registeredAddress,
      'buildingNo': buildingNo,
      'streetName': streetName,
      'districtName': districtName,
      'cityName': cityName,
      'zipCode': zipCode,
      'additionalNo': additionalNo,
      'unitNo': unitNo,
      'country': country,
      'taxNumber': taxNumber,
      'crNumber': crNumber,
      'zatcaEnabled': zatcaEnabled,
      'zatcaUsername': zatcaUsername,
      'zatcaPassword': zatcaPassword,
      'periodSectionId': periodSectionId,
      'periodSectionName': periodSectionName,
      'financialPeriodStartDate': financialPeriodStartDate,
      'financialPeriodEndDate': financialPeriodEndDate,
      'createdById': createdById,
      'createdByName': createdByName,
      'editedById': editedById,
      'editedByName': editedByName,
      'editedDate': editedDate?.toIso8601String(),
      'createdAt': createdAt?.toIso8601String() ?? DateTime.now().toIso8601String(),
      'usedSoftwares': usedSoftwares,
      'softwareActivations': softwareActivations,
    };
  }

  // Create Customer object from JSON
  factory Customer.fromMap(Map<String, dynamic> map, String documentId) {
    return Customer(
      id: documentId,
      name: map['name'] ?? '',
      phone: map['phone'] ?? '',
      address: map['address'] ?? '',
      taxNumber: map['taxNumber'] ?? '',
      zatcaEnabled: map['zatcaEnabled'] ?? false,
      
      phone2: map['phone2'],
      email: map['email'],
      organizationName: map['organizationName'],
      organizationUnitName: map['organizationUnitName'],
      commonName: map['commonName'],
      businessCategory: map['businessCategory'],
      registeredAddress: map['registeredAddress'],
      buildingNo: map['buildingNo'],
      streetName: map['streetName'],
      districtName: map['districtName'],
      cityName: map['cityName'],
      zipCode: map['zipCode'],
      additionalNo: map['additionalNo'],
      unitNo: map['unitNo'],
      country: map['country'],
      crNumber: map['crNumber'],
      zatcaUsername: map['zatcaUsername'],
      zatcaPassword: map['zatcaPassword'],
      periodSectionId: map['periodSectionId'],
      periodSectionName: map['periodSectionName'],
      financialPeriodStartDate: map['financialPeriodStartDate'],
      financialPeriodEndDate: map['financialPeriodEndDate'],
      
      createdById: map['createdById'],
      createdByName: map['createdByName'],
      editedById: map['editedById'],
      editedByName: map['editedByName'],
      editedDate: map['editedDate'] != null ? DateTime.parse(map['editedDate']) : null,
      createdAt: map['createdAt'] != null 
          ? DateTime.parse(map['createdAt'].toString()) 
          : null,

      usedSoftwares: List<String>.from(map['usedSoftwares'] ?? []),
      softwareActivations: List<Map<String, dynamic>>.from(map['softwareActivations'] ?? []),
    );
  }

  // Copy with method
  Customer copyWith({
    String? id,
    String? name,
    String? phone,
    String? phone2,
    String? email,
    String? organizationName,
    String? organizationUnitName,
    String? commonName,
    String? businessCategory,
    String? address,
    String? registeredAddress,
    String? buildingNo,
    String? streetName,
    String? districtName,
    String? cityName,
    String? zipCode,
    String? additionalNo,
    String? unitNo,
    String? country,
    String? taxNumber,
    String? crNumber,
    bool? zatcaEnabled,
    String? zatcaUsername,
    String? zatcaPassword,
    
    String? periodSectionId,
    String? periodSectionName,
   
    String? financialPeriodStartDate,
    String? financialPeriodEndDate,
    String? createdById,
    String? createdByName,
    String? editedById,
    String? editedByName,
    DateTime? editedDate,
    DateTime? createdAt,
    List<String>? usedSoftwares,
    List<Map<String, dynamic>>? softwareActivations,
  }) {
    return Customer(
      id: id ?? this.id,
      name: name ?? this.name,
      phone: phone ?? this.phone,
      address: address ?? this.address,
      taxNumber: taxNumber ?? this.taxNumber,
      zatcaEnabled: zatcaEnabled ?? this.zatcaEnabled,
      
      phone2: phone2 ?? this.phone2,
      email: email ?? this.email,
      organizationName: organizationName ?? this.organizationName,
      organizationUnitName: organizationUnitName ?? this.organizationUnitName,
      commonName: commonName ?? this.commonName,
      businessCategory: businessCategory ?? this.businessCategory,
      registeredAddress: registeredAddress ?? this.registeredAddress,
      buildingNo: buildingNo ?? this.buildingNo,
      streetName: streetName ?? this.streetName,
      districtName: districtName ?? this.districtName,
      cityName: cityName ?? this.cityName,
      zipCode: zipCode ?? this.zipCode,
      additionalNo: additionalNo ?? this.additionalNo,
      unitNo: unitNo ?? this.unitNo,
      country: country ?? this.country,
      crNumber: crNumber ?? this.crNumber,
      zatcaUsername: zatcaUsername ?? this.zatcaUsername,
      zatcaPassword: zatcaPassword ?? this.zatcaPassword,
      periodSectionId: periodSectionId ?? this.periodSectionId,
      periodSectionName: periodSectionName ?? this.periodSectionName,
      
      financialPeriodStartDate: financialPeriodStartDate ?? this.financialPeriodStartDate,
      financialPeriodEndDate: financialPeriodEndDate ?? this.financialPeriodEndDate,
      
      createdById: createdById ?? this.createdById,
      createdByName: createdByName ?? this.createdByName,
      editedById: editedById ?? this.editedById,
      editedByName: editedByName ?? this.editedByName,
      editedDate: editedDate ?? this.editedDate,
      createdAt: createdAt ?? this.createdAt,
      
      usedSoftwares: usedSoftwares ?? this.usedSoftwares,
      softwareActivations: softwareActivations ?? this.softwareActivations,
    );
  }
}