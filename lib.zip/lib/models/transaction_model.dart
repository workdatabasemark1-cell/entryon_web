class TransactionModel {
  final String id;
  final String serviceId;
  final String? customerId;
  final String customerName;
  final double amount;
  final double balanceAmount;

  final String paymentType; // 'Cash' or 'Card'
  final Map<String, dynamic>? paymentDetails;
  final DateTime createdAt;

  TransactionModel({
    required this.id,
    required this.serviceId,
    this.customerId,
    required this.customerName,
    required this.amount,
    required this.balanceAmount,

    required this.paymentType,
    this.paymentDetails,
    required this.createdAt,
  });

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'serviceId': serviceId,
      'customerId': customerId,
      'customerName': customerName,
      'amount': amount,
      'balanceAmount': balanceAmount,
      'paymentType': paymentType,
      'paymentDetails': paymentDetails ?? {},
      'createdAt': createdAt.toIso8601String(),
    };
  }

  factory TransactionModel.fromMap(Map<String, dynamic> map, String documentId) {
    return TransactionModel(
      id: documentId,
      serviceId: map['serviceId'] ?? '',
      customerId: map['customerId'],
      customerName: map['customerName'] ?? '',
      amount: (map['amount'] is num) ? (map['amount'] as num).toDouble() : 0.0,
      balanceAmount: (map['balanceAmount'] is num) ? (map['balanceAmount'] as num).toDouble() : 0.0,
      paymentType: map['paymentType'] ?? 'Cash',
      paymentDetails: Map<String, dynamic>.from(map['paymentDetails'] ?? {}),
      createdAt: map['createdAt'] != null ? DateTime.parse(map['createdAt']) : DateTime.now(),
    );
  }
}
