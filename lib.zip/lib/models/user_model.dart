class AppUser {
  final String username;
  final String name;

  AppUser({
    required this.username,
    required this.name,
  });
}